# JEE to Quarkus Migration Agent

Sistema de agentes basado en MCP (Model Context Protocol) para migrar automáticamente proyectos Jakarta EE (EJB) a Quarkus con arquitectura hexagonal.

## 🎯 Objetivo

Automatizar la migración de facades EJB legacy hacia microservicios Quarkus reactivos, generando:

- Documentación funcional completa
- Código con arquitectura hexagonal (puertos y adaptadores)
- Capa anticorrupción para integración con EJBs existentes
- Especificaciones OpenAPI
- Tests unitarios

## 🏗️ Arquitectura

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        JEE Codegen Orchestrator (MCP Server)                │
│                                                                             │
│  ┌─────────┐    ┌──────────┐    ┌──────────┐    ┌─────────┐    ┌─────────┐ │
│  │  Scan   │───▶│ Document │───▶│ Generate │───▶│ Compile │───▶│   Fix   │ │
│  └─────────┘    └──────────┘    └──────────┘    └─────────┘    └─────────┘ │
└───────┬─────────────┬─────────────────┬────────────────────────────────────┘
        │             │                 │
        ▼             ▼                 ▼
┌───────────────┐ ┌───────────────┐ ┌───────────────────┐
│  Interpreter  │ │  JEE Doc      │ │  Quarkus Codegen  │
│  JEE MCP      │ │  Agent        │ │  Agent            │
└───────────────┘ └───────────────┘ └───────────────────┘
```

## 📦 Componentes

| Componente | Descripción |
|------------|-------------|
| [intepreter-jee-mcp-server](intepreter-jee-mcp-server/) | Servidor MCP que escanea proyectos JEE y extrae contratos EJB |
| [jee-doc-agent](jee-doc-agent/) | Agente que genera documentación funcional usando LLM |
| [quarkus-codegen-agent](quarkus-codegen-agent/) | Agente que genera código Quarkus hexagonal |
| [jee-codegen-orchestrator](jee-codegen-orchestrator/) | Orquestador LangGraph que coordina el flujo completo |

## 🚀 Inicio Rápido

### Prerrequisitos

- Python 3.11+
- Docker (opcional, para despliegue containerizado)
- API Key de OpenAI o Anthropic

### Instalación Local

```bash
# Clonar repositorio
git clone <repo-url>
cd agente

# Crear entorno virtual
python -m venv .venv
source .venv/bin/activate

# Instalar todos los componentes
pip install -e ./intepreter-jee-mcp-server
pip install -e ./jee-doc-agent
pip install -e ./quarkus-codegen-agent
pip install -e ./jee-codegen-orchestrator
```

### Configuración

Crear archivo `.env` en la raíz:

```env
# LLM Provider: openai | anthropic
LLM_PROVIDER=anthropic
ANTHROPIC_API_KEY=sk-ant-your-key
ANTHROPIC_MODEL=claude-sonnet-4-20250514

# Alternativa OpenAI
OPENAI_API_KEY=sk-your-key
OPENAI_MODEL=gpt-4o-mini

# MCP Server (stdio - para agentes)
MCP_SERVER_COMMAND=python
MCP_SERVER_ARGS=-m,src.main
MCP_SERVER_CWD=/data/agente/intepreter-jee-mcp-server

# Configuración de migración
OUTPUT_BASE_DIR=/data/agente/output
MAX_FIX_ATTEMPTS=3
```

## 📖 Uso

### Opción 1: MCP Server (Recomendado para GitHub Copilot)

El orquestador expone un servidor MCP que puede ser consumido por GitHub Copilot u otros clientes MCP:

```bash
# Iniciar servidor MCP con SSE
jee-orchestrate-mcp --transport sse --host 0.0.0.0 --port 8080
```

**Herramientas MCP disponibles:**

| Herramienta | Descripción |
|-------------|-------------|
| `list_facades` | Lista todas las facades EJB de un proyecto |
| `migrate_facade_method` | Migra un método completo (scan → doc → gen → compile → fix) |
| `get_migration_status` | Obtiene el estado de una migración activa |
| `validate_mapping_csv` | Valida archivo CSV de mapeo de campos |

### Opción 2: CLI Directo

```bash
# Migrar un método específico
jee-orchestrate method /path/to/jee-project \
    -i AdministracionPropuestaFacade \
    -m consultarPropuesta \
    -o ./output \
    --max-retries 3

# Migrar toda una facade
jee-orchestrate method /path/to/jee-project \
    -i AdministracionPropuestaFacade \
    -o ./output

# Verificar compilación
jee-orchestrate verify ./output
```

### Opción 3: Docker

```bash
# Construir imagen
docker build -t jee-mcp-server .

# Ejecutar con docker-compose
docker-compose up -d

# Ver logs
docker-compose logs -f
```

## 🐳 Despliegue con Docker

```bash
# Variables de entorno requeridas
export ANTHROPIC_API_KEY=sk-ant-your-key
export JEE_PROJECTS_MOUNT=/path/to/jee-projects
export OUTPUT_MOUNT=/path/to/output

# Iniciar
docker-compose up -d
```

El servidor estará disponible en `http://localhost:8080`.

## 📁 Estructura del Proyecto

```
agente/
├── README.md                      # Este archivo
├── Dockerfile                     # Imagen Docker multi-proyecto
├── docker-compose.yml             # Orquestación de contenedores
├── .env                           # Variables de entorno (no versionado)
│
├── intepreter-jee-mcp-server/     # Servidor MCP - Escaneo de contratos EJB
│   ├── src/
│   │   ├── main.py                # Entry point MCP
│   │   ├── core/                  # Lógica de escaneo Java
│   │   ├── models/                # Modelos Pydantic (contratos)
│   │   ├── services/              # Clientes LLM, prompts
│   │   └── prompts/               # Templates de prompts
│   └── tests/
│
├── jee-doc-agent/                 # Agente documentador funcional
│   ├── src/jee_doc_agent/
│   │   ├── cli.py                 # CLI Typer
│   │   ├── doc_generator.py       # Generador Markdown
│   │   └── llm_analyzer.py        # Análisis con LLM
│   └── tests/
│
├── quarkus-codegen-agent/         # Agente generador de código
│   ├── src/quarkus_codegen_agent/
│   │   ├── cli.py                 # CLI Typer
│   │   ├── code_generator.py      # Generación hexagonal
│   │   └── code_merger.py         # Merge incremental
│   └── tests/
│
└── jee-codegen-orchestrator/      # Orquestador LangGraph
    ├── src/jee_codegen_orchestrator/
    │   ├── mcp_server.py          # Servidor MCP principal
    │   ├── graph.py               # Grafo LangGraph
    │   ├── cli.py                 # CLI Typer
    │   └── nodes/                 # Nodos del grafo
    │       ├── scanner.py
    │       ├── documenter.py
    │       ├── generator.py
    │       ├── compiler.py
    │       └── fixer.py
    └── tests/
```

## 🔄 Flujo de Migración

1. **Scan**: El `intepreter-jee-mcp-server` escanea el proyecto JEE y extrae:
   - Interfaces con `@Remote`/`@Local`
   - Métodos y sus firmas
   - DTOs y sus campos
   - Lógica de negocio de Managers (opcional)

2. **Document**: El `jee-doc-agent` genera documentación funcional:
   - Descripción del propósito del método
   - Tablas de atributos entrada/salida
   - Mapeo de errores y excepciones
   - Tips de consumo

3. **Generate**: El `quarkus-codegen-agent` genera código:
   - Domain: DTOs, Ports (UseCase, RmiPort)
   - Application: Services
   - Infrastructure: Resources REST, Adapters RMI, Mappers
   - Tests unitarios
   - Specs OpenAPI

4. **Compile**: Ejecuta `mvn compile` y parsea errores

5. **Fix**: Si hay errores, el LLM los analiza y corrige (hasta 3 intentos)

## 🧪 Tests

```bash
# Activar entorno
source .venv/bin/activate

# Tests de todos los componentes
pytest

# Con cobertura
pytest --cov=. --cov-report=html

# Tests de un componente específico
pytest jee-codegen-orchestrator/tests/
```

## 🔧 Configuración Avanzada

### Proveedores LLM

El sistema soporta múltiples proveedores:

```env
# OpenAI
LLM_PROVIDER=openai
OPENAI_API_KEY=sk-your-key
OPENAI_MODEL=gpt-4o-mini
OPENAI_MAX_TOKENS=50000

# Anthropic (recomendado)
LLM_PROVIDER=anthropic
ANTHROPIC_API_KEY=sk-ant-your-key
ANTHROPIC_MODEL=claude-sonnet-4-20250514
```

### Mapeo de Campos Personalizado

Para migraciones complejas, se puede proporcionar un CSV con mapeos:

```csv
ObjetoOrigen,ObjetoDestino,campoOrigen,campoDestino
PropuestaDTO,PropuestaRequest,idPropuesta,id
PropuestaDTO,PropuestaRequest,fechaCreacion,createdAt
```

```bash
jee-orchestrate method /path/to/project \
    -i MyFacade \
    -m myMethod \
    -o ./output \
    --mapping-csv ./mappings.csv
```

### Instrucciones de Generación Personalizadas

Puedes proporcionar instrucciones específicas para guiar la generación de código:

```python
# Desde GitHub Copilot (MCP)
@workspace migra el método con estas instrucciones:
"Usar nombres de campos exactos del EJB sin traducir.
Los campos Calendar deben mapearse a LocalDateTime."
```

Ver [Guía de Generation Hints](docs/generation-hints-usage.md) para más detalles y ejemplos.

## 📚 Documentación Adicional

- [Diagramas de Arquitectura](docs/architecture-diagram.md) - Diagramas Mermaid del sistema
- [Guía de Generation Hints](docs/generation-hints-usage.md) - Instrucciones personalizadas para generación
- [Interpreter JEE MCP Server](intepreter-jee-mcp-server/README.md)
- [JEE Doc Agent](jee-doc-agent/README.md)
- [Quarkus Codegen Agent](quarkus-codegen-agent/README.md)
- [JEE Codegen Orchestrator](jee-codegen-orchestrator/README.md)

## 📄 Licencia

MIT
