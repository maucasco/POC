"""Entrypoint for running the FastMCP server."""
from __future__ import annotations

import sys

from agent import build_mcp
from config import get_settings


def main() -> None:
    """Bootstrap the FastMCP server (stdio or HTTP based on args)."""

    settings = get_settings()
    server = build_mcp()
    
    # Use stdio if --stdio flag is passed, otherwise HTTP
    if "--stdio" in sys.argv or len(sys.argv) == 1:
        server.run(transport="stdio")
    else:
        server.run(transport="streamable-http")


if __name__ == "__main__":
    main()
