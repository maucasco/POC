"""Agent wiring for the FastMCP server."""

from .ejb_agent import build_mcp

__all__ = ["build_mcp"]
