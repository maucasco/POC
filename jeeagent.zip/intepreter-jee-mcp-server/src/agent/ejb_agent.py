"""FastMCP wiring for the EJB contract interpreter."""
from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Iterable

from mcp.server.fastmcp import Context, FastMCP
from mcp.server.session import ServerSession

from config import get_settings
from core import ProjectScanner
from models import EjbContract, ProjectScanRequest, ProjectScanResponse
from services import LLMClient, PromptRepository

LOGGER = logging.getLogger(__name__)

settings = get_settings()
prompts = PromptRepository()
llm_client = LLMClient(settings, prompts)
mcp = FastMCP(
    settings.agent_name,
    instructions=settings.agent_description,
    host=settings.http_host,
    port=settings.http_port,
    log_level=settings.log_level.upper(),
    stateless_http=True,
    json_response=True,
)


def build_mcp() -> FastMCP:
    """Expose the configured FastMCP instance."""

    return mcp


def _normalize_path(path_str: str) -> Path:
    path = Path(path_str).expanduser().resolve()
    LOGGER.info("Validating project path: %s", path)
    if not path.exists():
        LOGGER.error("Invalid project path supplied: %s", path)
        raise FileNotFoundError(f"Provided project path does not exist: {path}")
    return path


async def _execute_scan(
    request: ProjectScanRequest,
    ctx: Context[ServerSession, None] | None,
) -> ProjectScanResponse:
    LOGGER.info(
        "Starting EJB scan | path=%s | detailed_scan=%s",
        request.project_path,
        request.detailed_scan,
    )
    if ctx:
        await ctx.info(
            f"Scanning project at {request.project_path} (detailed={request.detailed_scan})"
        )
    scanner = ProjectScanner(request.project_path)
    try:
        contracts = scanner.scan()
    except Exception as exc:
        LOGGER.exception("Scan failure for %s", request.project_path)
        if ctx:
            await ctx.error(f"Scan failed: {exc}")
        raise
    if request.detailed_scan and ctx is not None:
        await _summarize_manager_logic(contracts, ctx)
    markdown = _to_markdown(contracts, request)
    LOGGER.info("Completed EJB scan | contracts=%d", len(contracts))
    return ProjectScanResponse(
        agent_id=settings.metadata.agent_id,
        contracts=contracts,
        markdown=markdown,
    )


async def _summarize_manager_logic(
    contracts: Iterable[EjbContract],
    ctx: Context[ServerSession, None],
) -> None:
    tasks = []
    managers = 0
    for contract in contracts:
        if not contract.related_manager_path:
            continue
        tasks.append(
            llm_client.summarize_manager_logic(contract.related_manager_path, ctx)
        )
        managers += 1
    if managers == 0:
        LOGGER.info("No manager classes detected for detailed scan")
        return
    LOGGER.info("Summarizing %d manager classes", managers)
    await ctx.info(f"Summarizing {managers} manager classes")
    summaries = await asyncio.gather(*tasks) if tasks else []
    summary_iter = iter(summaries)
    for contract in contracts:
        if not contract.related_manager_path:
            continue
        summary = next(summary_iter, None)
        for method in contract.methods:
            method.manager_summary = summary


def _to_markdown(contracts: Iterable[EjbContract], request: ProjectScanRequest) -> str:
    contract_list = list(contracts)
    sections: list[str] = []
    LOGGER.debug("Generating Markdown for %d contracts", len(contract_list))
    for contract in contract_list:
        lines = [
            f"## {contract.interface_name} ({contract.annotation})",
            f"Source: `{contract.file_path}`",
        ]
        if contract.related_manager_path:
            impl_name = contract.related_manager_path.stem  # e.g., "SomeServiceBean"
            impl_type = "Implementation"
            if impl_name.endswith("Manager"):
                impl_type = "Manager"
            elif impl_name.endswith("Mngr"):
                impl_type = "Manager"
            elif impl_name.endswith("Bean"):
                impl_type = "Bean"
            lines.append(f"{impl_type}: `{contract.related_manager_path}`")
        for method in contract.methods:
            params = ", ".join(
                f"{param.type_hint} {param.name}" for param in method.parameters
            )
            lines.append(f"- `{method.return_type}` **{method.name}**({params})")
            if method.manager_summary:
                lines.append(f"  - Manager insight: {method.manager_summary}")
        sections.append("\n".join(lines))
    if not sections:
        sections.append("No EJB interfaces detected.")
    template = prompts.load("contract_markdown_template.md")
    return template.format(
        agent_name=settings.agent_name,
        project_path=request.project_path,
        contracts_section="\n\n".join(sections),
    )


@mcp.tool()
async def scan_ejb_contracts(
    project_path: str,
    detailed_scan: bool = False,
    ctx: Context[ServerSession, None] | None = None,
) -> ProjectScanResponse:
    """Scan a project path and return structured EJB contract data."""

    LOGGER.info(
        "scan_ejb_contracts invoked | path=%s | detailed=%s",
        project_path,
        detailed_scan,
    )
    normalized_path = _normalize_path(project_path)
    request = ProjectScanRequest(
        project_path=normalized_path,
        detailed_scan=detailed_scan,
    )
    return await _execute_scan(request, ctx)


@mcp.resource("ejb-report://{project_path}")
async def ejb_report_resource(
    project_path: str,
    ctx: Context[ServerSession, None] | None = None,
) -> str:
    """Return Markdown documentation for the requested project."""

    LOGGER.info("ejb_report_resource invoked | path=%s", project_path)
    normalized_path = _normalize_path(project_path)
    request = ProjectScanRequest(project_path=normalized_path, detailed_scan=False)
    response = await _execute_scan(request, ctx)
    return response.markdown or ""
