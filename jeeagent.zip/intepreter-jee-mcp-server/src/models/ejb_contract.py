"""Structured models used by the MCP tools."""
from __future__ import annotations

from pathlib import Path
from typing import List, Optional

from pydantic import BaseModel, Field


class DataField(BaseModel):
    """Describe a DTO field referenced by an EJB contract."""

    name: str = Field(..., description="Field name declared in the DTO")
    type_hint: str = Field(..., description="Type declared for the field")
    description: str | None = Field(
        default=None, description="Optional description, when documented"
    )
    nested_dto: Optional["DtoDefinition"] = Field(
        default=None, description="Nested DTO definition for complex types"
    )


class DtoDefinition(BaseModel):
    """Pydantic model describing a DTO and its fields."""

    name: str
    file_path: Path | None = Field(
        default=None, description="Path to the file containing the DTO"
    )
    fields: List[DataField] = Field(default_factory=list)


# Rebuild models to resolve forward references
DataField.model_rebuild()
DtoDefinition.model_rebuild()


class MethodParameter(BaseModel):
    """Describe a method parameter inside an EJB interface."""

    name: str
    type_hint: str
    dto: DtoDefinition | None = Field(
        default=None, description="Resolved DTO definition when available"
    )


class MethodSignature(BaseModel):
    """Describe a single EJB method signature."""

    name: str
    return_type: str
    parameters: List[MethodParameter] = Field(default_factory=list)
    documentation: Optional[str] = Field(
        default=None, description="JavaDoc snippet when available"
    )
    manager_summary: Optional[str] = Field(
        default=None,
        description="Optional summary extracted from Manager/Mngr classes",
    )


class EjbContract(BaseModel):
    """Aggregate information for one EJB interface."""

    interface_name: str
    annotation: str
    file_path: Path
    methods: List[MethodSignature] = Field(default_factory=list)
    related_manager_path: Path | None = Field(
        default=None, description="Path to business logic implementation (Manager/Mngr/Bean) when found"
    )


class ProjectScanRequest(BaseModel):
    """Input parameters for the scan tool."""

    project_path: Path = Field(..., description="Absolute path to the source tree")
    detailed_scan: bool = Field(
        default=False,
        description="If true, include summaries from Manager/Mngr classes",
    )


class ProjectScanResponse(BaseModel):
    """Output payload returned to MCP clients."""

    agent_id: str
    contracts: List[EjbContract]
    markdown: Optional[str] = Field(
        default=None,
        description="Optional Markdown documentation generated for the contracts",
    )
