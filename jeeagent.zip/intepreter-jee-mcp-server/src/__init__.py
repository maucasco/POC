"""EJB Contract Interpreter MCP package."""
