# EJB Contract Report

Agent: {agent_name}
Generated for project: {project_path}

{contracts_section}
