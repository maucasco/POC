"""Centralized settings handling for the MCP server."""
from __future__ import annotations

import logging
import os
from functools import lru_cache
from pathlib import Path
from typing import Literal

from dotenv import load_dotenv
from pydantic import BaseModel, Field, ValidationError

# Load environment variables early so every module sees the same values.
ENV_PATH = Path(__file__).resolve().parents[2] / ".env"
if ENV_PATH.exists():
    load_dotenv(ENV_PATH)
else:
    load_dotenv()


class AgentMetadata(BaseModel):
    """Metadata required by the MCP agent registration."""

    agent_id: str = Field(..., description="Unique identifier for the MCP agent")
    name: str = Field(..., description="Human-readable name for the agent")
    description: str = Field(..., description="Short summary of the agent purpose")
    policies: str = Field(
        ..., description="Policies or usage guidelines that clients must follow"
    )


class Settings(BaseModel):
    """Application-wide configuration loaded from the environment."""

    metadata: AgentMetadata
    http_host: str = Field(
        default="127.0.0.1", description="Address where the HTTP server listens"
    )
    http_port: int = Field(default=8080, description="Port for HTTP transport")
    llm_provider: Literal["openai", "anthropic", "mock"] = Field(
        default="mock", description="Provider used for LLM-based summaries"
    )
    openai_model: str = Field(
        default="gpt-4o-mini", description="Default OpenAI model identifier"
    )
    anthropic_model: str = Field(
        default="claude-3-5-sonnet", description="Default Anthropic model"
    )
    openai_api_key: str | None = Field(
        default=None, description="Credential for OpenAI requests"
    )
    anthropic_api_key: str | None = Field(
        default=None, description="Credential for Anthropic requests"
    )
    log_level: str = Field(default="INFO", description="Application log level")
    max_tokens: int = Field(
        default=2048, description="Maximum tokens requested from the LLM"
    )
    implementation_suffixes: list[str] = Field(
        default=["Manager", "Mngr", "Bean"],
        description="Suffixes to search for business logic implementation classes"
    )

    @property
    def agent_name(self) -> str:
        """Convenience accessor for the human-readable agent name."""

        return self.metadata.name

    @property
    def agent_description(self) -> str:
        """Return the agent description expected by the MCP registry."""

        return self.metadata.description

    def resolved_model(self) -> str:
        """Resolve the concrete model name based on the selected provider."""

        if self.llm_provider == "openai":
            return self.openai_model
        if self.llm_provider == "anthropic":
            return self.anthropic_model
        return "mock"

    @classmethod
    def from_env(cls) -> "Settings":
        """Instantiate settings from environment variables with validation."""

        metadata = AgentMetadata(
            agent_id=os.getenv("AGENT_ID", "ejb-interpreter-agent"),
            name=os.getenv("AGENT_NAME", "EJB Contract Interpreter"),
            description=os.getenv(
                "AGENT_DESCRIPTION",
                "MCP server that documents Jakarta EJB contracts.",
            ),
            policies=os.getenv(
                "AGENT_POLICIES",
                "Avoid sensitive data, optimize LLM usage, respect rate limits.",
            ),
        )

        try:
            return cls(
                metadata=metadata,
                http_host=os.getenv("HTTP_HOST", "127.0.0.1"),
                http_port=int(os.getenv("HTTP_PORT", "8080")),
                llm_provider=os.getenv("LLM_PROVIDER", "mock"),
                openai_model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
                anthropic_model=os.getenv(
                    "ANTHROPIC_MODEL", "claude-3-5-sonnet"
                ),
                openai_api_key=os.getenv("OPENAI_API_KEY"),
                anthropic_api_key=os.getenv("ANTHROPIC_API_KEY"),
                log_level=os.getenv("LOG_LEVEL", "INFO"),
                max_tokens=int(os.getenv("MAX_TOKENS", "2048")),
                implementation_suffixes=os.getenv(
                    "IMPLEMENTATION_SUFFIXES", "Manager,Mngr,Bean"
                ).split(","),
            )
        except ValidationError as exc:  # pragma: no cover - defensive logging
            logging.getLogger(__name__).error("Invalid settings: %s", exc)
            raise


def configure_logging(settings: Settings) -> None:
    """Configure basic logging according to the loaded settings."""

    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return cached settings instance."""

    settings = Settings.from_env()
    configure_logging(settings)
    return settings
