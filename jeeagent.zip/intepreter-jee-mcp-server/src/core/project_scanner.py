"""Filesystem scanner that extracts EJB contracts from a Java project."""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Iterable

from models import (
    DataField,
    DtoDefinition,
    EjbContract,
    MethodParameter,
    MethodSignature,
)

LOGGER = logging.getLogger(__name__)
EJB_SUFFIXES = ("Remote.java", "Facade.java", "Local.java")
ANNOTATIONS = ("@Remote", "@Local")
# Method pattern for interface methods:
# - Optional 'public' modifier (interfaces)
# - Return type (may include generics with spaces like Map<String, String>)
# - Method name
# - Parameters
# - Optional throws clause
METHOD_PATTERN = re.compile(
    r"(?:public\s+)?(?P<return>[\w<>\[\],\s]+?)\s+(?P<name>\w+)\s*\((?P<params>[^)]*)\)\s*(?:throws\s+[\w,\s]+)?;"
)
PARAM_PATTERN = re.compile(r"(?P<type>[\w<>\[\],\s]+?)\s+(?P<name>\w+)")
# Improved pattern to capture:
# - Simple types: String, int, BigDecimal
# - Arrays: String[], LiquidacionConsolidadoTO[]
# - Generics: ArrayList<String>, HashMap<BigDecimal, ConfiguracionTRMTO>
# - Initialized fields: private boolean asignar = false;
FIELD_PATTERN = re.compile(
    r"private\s+(?P<type>[\w]+(?:<[\w<>,\s]+>)?(?:\[\])?)\s+(?P<name>\w+)\s*(?:=\s*[^;]+)?;"
)


class ProjectScanner:
    """Walk a source tree to locate EJB interfaces and derive contracts."""

    def __init__(self, project_path: Path, dto_depth: int = 3) -> None:
        if not project_path.exists():
            raise FileNotFoundError(f"Project path does not exist: {project_path}")
        self.project_path = project_path
        self.dto_depth = dto_depth
        self._dto_cache: dict[str, DtoDefinition | None] = {}

    def scan(self) -> list[EjbContract]:
        """Scan the project path and return discovered contracts."""

        contracts: list[EjbContract] = []
        for file_path in self._iter_interface_files():
            try:
                contract = self._parse_interface(file_path)
            except Exception as exc:  # pragma: no cover - defensive log
                LOGGER.exception("Failed to parse %s: %s", file_path, exc)
                continue
            if contract:
                contracts.append(contract)
        return contracts

    def _iter_interface_files(self) -> Iterable[Path]:
        """Yield candidate Java files that likely represent EJB interfaces."""

        for file_path in self.project_path.rglob("*.java"):
            if file_path.name.endswith(EJB_SUFFIXES):
                yield file_path

    def _parse_interface(self, file_path: Path) -> EjbContract | None:
        """Parse a Java interface file and build an `EjbContract`."""

        content = file_path.read_text(encoding="utf-8", errors="ignore")
        annotation = next((a for a in ANNOTATIONS if a in content), None)
        if annotation is None:
            return None

        interface_match = re.search(r"interface\s+(?P<name>\w+)", content)
        if not interface_match:
            LOGGER.debug("File %s lacks interface declaration", file_path)
            return None

        interface_name = interface_match.group("name")
        methods = self._extract_methods(content)
        manager_path = self._find_manager_path(interface_name)
        return EjbContract(
            interface_name=interface_name,
            annotation=annotation,
            file_path=file_path,
            methods=methods,
            related_manager_path=manager_path,
        )

    def _extract_methods(self, content: str) -> list[MethodSignature]:
        """Extract method signatures using lightweight regex parsing."""

        # Normalize whitespace for better regex matching
        normalized = re.sub(r'\s+', ' ', content)
        signatures: list[MethodSignature] = []
        for match in METHOD_PATTERN.finditer(normalized):
            params_text = match.group("params").strip()
            parameters = self._parse_parameters(params_text)
            return_type = match.group("return").strip()
            signatures.append(
                MethodSignature(
                    name=match.group("name"),
                    return_type=return_type,
                    parameters=parameters,
                )
            )
        return signatures

    def _parse_parameters(self, params_text: str) -> list[MethodParameter]:
        """Parse the parameter list for a method."""

        if not params_text:
            return []
        parameters: list[MethodParameter] = []
        for chunk in params_text.split(","):
            chunk = chunk.strip()
            if not chunk:
                continue
            match = PARAM_PATTERN.match(chunk)
            if not match:
                LOGGER.debug("Unable to parse parameter chunk: %s", chunk)
                continue
            type_hint = match.group("type")
            dto = self._resolve_dto(type_hint)
            parameters.append(
                MethodParameter(
                    name=match.group("name"),
                    type_hint=type_hint,
                    dto=dto,
                )
            )
        return parameters

    def _resolve_dto(self, type_name: str, depth: int = 0) -> DtoDefinition | None:
        """Best-effort resolution of a DTO by scanning matching Java classes.
        
        Args:
            type_name: The type name to resolve (may include generics)
            depth: Current recursion depth for nested DTOs
            
        Returns:
            DtoDefinition with fields (including nested DTO fields) or None
        """
        if depth > self.dto_depth:
            return None
            
        simple_name = type_name.split("<", 1)[0].replace("[]", "")
        if not simple_name[0].isupper():
            return None
        if simple_name in self._dto_cache:
            return self._dto_cache[simple_name]

        dto_file = next(
            (path for path in self.project_path.rglob(f"{simple_name}.java")),
            None,
        )
        if dto_file is None:
            self._dto_cache[simple_name] = None
            return None

        fields = self._extract_fields(dto_file, depth)
        dto = DtoDefinition(name=simple_name, file_path=dto_file, fields=fields)
        self._dto_cache[simple_name] = dto
        return dto

    def _extract_fields(self, dto_file: Path, depth: int = 0) -> list[DataField]:
        """Extract private field declarations from a Java class file.
        
        Also resolves nested DTOs recursively up to max_depth.
        """
        content = dto_file.read_text(encoding="utf-8", errors="ignore")
        fields: list[DataField] = []
        for match in FIELD_PATTERN.finditer(content):
            field_type = match.group("type")
            field_name = match.group("name")
            
            # Try to resolve nested DTO if it's a complex type
            nested_dto = None
            if depth < self.dto_depth:
                nested_dto = self._resolve_dto(field_type, depth + 1)
            
            fields.append(
                DataField(
                    name=field_name, 
                    type_hint=field_type,
                    nested_dto=nested_dto,
                )
            )
        return fields

    def _find_manager_path(self, interface_name: str) -> Path | None:
        """Locate implementation (Manager/Mngr/Bean) that matches the interface.
        
        Strips interface suffixes (Remote, Local, Facade) and tries all
        implementation suffixes (Manager, Mngr, Bean).
        
        Examples:
            - ParametrosPortalServiceLocal -> ParametrosPortalServiceBean
            - AdministracionPropuestaFacade -> AdministracionPropuestaMngr
            - MyServiceRemote -> MyServiceManager
        """
        base = interface_name
        interface_suffixes = ["Remote", "Local", "Facade"]
        impl_suffixes = ["Manager", "Mngr", "Bean"]
        
        candidates = []
        # Try with full interface name
        for impl_suffix in impl_suffixes:
            candidates.append(f"{base}{impl_suffix}.java")
        
        # Try stripping each interface suffix
        for iface_suffix in interface_suffixes:
            if base.endswith(iface_suffix):
                stripped = base.replace(iface_suffix, "")
                for impl_suffix in impl_suffixes:
                    candidates.append(f"{stripped}{impl_suffix}.java")
        
        for candidate in candidates:
            impl_path = next((
                path for path in self.project_path.rglob(candidate)
                if path.is_file()
            ), None)
            if impl_path:
                LOGGER.debug("Found implementation: %s for %s", impl_path, interface_name)
                return impl_path
        
        LOGGER.debug("No implementation found for %s", interface_name)
        return None
