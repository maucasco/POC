"""LLM client abstraction with provider-aware behavior."""
from __future__ import annotations

import logging
from pathlib import Path

from mcp.server.fastmcp import Context
from mcp.server.session import ServerSession
from mcp.types import SamplingMessage, TextContent

from config import Settings
from services.prompt_loader import PromptRepository

LOGGER = logging.getLogger(__name__)


class LLMClient:
    """Wrapper that coordinates LLM usage and fallbacks."""

    def __init__(self, settings: Settings, prompts: PromptRepository) -> None:
        self.settings = settings
        self.prompts = prompts

    async def summarize_manager_logic(
        self,
        manager_path: Path,
        ctx: Context[ServerSession, None] | None = None,
    ) -> str | None:
        """Summarize a Manager/Mngr class when detailed_scan is enabled."""

        snippet = self._read_snippet(manager_path)
        if not snippet:
            return None

        if self.settings.llm_provider == "mock" or ctx is None:
            LOGGER.debug("Skipping remote LLM usage for %s", manager_path)
            return self._fallback_summary(manager_path)

        prompt_template = self.prompts.load("manager_summary.prompt")
        prompt = prompt_template.format(
            manager_name=manager_path.stem,
            code_snippet=snippet,
        )
        messages = [
            SamplingMessage(
                role="user",
                content=TextContent(type="text", text=prompt),
            )
        ]
        try:
            result = await ctx.session.create_message(
                messages=messages,
                max_tokens=self.settings.max_tokens,
            )
        except Exception as exc:  # pragma: no cover - network variability
            LOGGER.warning("LLM request failed: %s", exc)
            return self._fallback_summary(manager_path)

        return self._extract_text(result)

    def _read_snippet(self, manager_path: Path) -> str:
        """Read a bounded portion of the manager source file."""

        try:
            content = manager_path.read_text(encoding="utf-8", errors="ignore")
        except OSError as exc:  # pragma: no cover - filesystem errors
            LOGGER.warning("Unable to read manager file %s: %s", manager_path, exc)
            return ""
        # Limit to the first 4000 characters to control token usage.
        return content[:4000]

    def _fallback_summary(self, manager_path: Path) -> str:
        """Provide a deterministic summary when no LLM provider is configured."""

        return (
            f"Review the manager class located at {manager_path} for business logic "
            "details; remote LLM summarization is disabled."
        )

    @staticmethod
    def _extract_text(result: object) -> str:
        """Extract text content defensively from an MCP sampling result."""

        content = getattr(result, "content", None)
        if isinstance(content, list):
            texts = [
                getattr(item, "text", "")
                for item in content
                if getattr(item, "type", None) == "text"
            ]
            return "\n".join(filter(None, texts)) or ""
        if content and hasattr(content, "text"):
            return getattr(content, "text", "")
        return ""
