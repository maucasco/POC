"""Utility to load prompt templates from disk."""
from __future__ import annotations

from pathlib import Path
from typing import Dict


class PromptRepository:
    """Loads prompt templates stored under the `src/prompts` directory."""

    def __init__(self, base_path: Path | None = None) -> None:
        project_root = Path(__file__).resolve().parents[2]
        prompts_dir = base_path or project_root / "src" / "prompts"
        self.prompts_dir = prompts_dir
        self._cache: Dict[str, str] = {}

    def load(self, name: str) -> str:
        """Load a prompt by name without re-reading disk multiple times."""

        if name in self._cache:
            return self._cache[name]
        file_path = self.prompts_dir / name
        if not file_path.exists():
            raise FileNotFoundError(f"Prompt file not found: {file_path}")
        content = file_path.read_text(encoding="utf-8")
        self._cache[name] = content
        return content
