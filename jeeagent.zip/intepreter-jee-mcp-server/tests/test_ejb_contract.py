"""Tests for the MCP server models."""
import pytest
from pathlib import Path
from pydantic import ValidationError

import sys
sys.path.insert(0, "/data/agente/intepreter-jee-mcp-server/src")

from models.ejb_contract import (
    DataField,
    DtoDefinition,
    MethodParameter,
    MethodSignature,
    EjbContract,
    ProjectScanRequest,
    ProjectScanResponse,
)


class TestDataField:
    """Tests for DataField model."""

    def test_basic_field(self):
        """Should create field with name and type."""
        field = DataField(name="cantidad", type_hint="int")
        assert field.name == "cantidad"
        assert field.type_hint == "int"
        assert field.description is None
        assert field.nested_dto is None

    def test_field_with_description(self):
        """Should accept optional description."""
        field = DataField(
            name="nombre",
            type_hint="String",
            description="Nombre del cliente",
        )
        assert field.description == "Nombre del cliente"

    def test_field_with_nested_dto(self):
        """Should support nested DTO reference."""
        nested = DtoDefinition(name="DireccionTO", fields=[])
        field = DataField(
            name="direccion",
            type_hint="DireccionTO",
            nested_dto=nested,
        )
        assert field.nested_dto is not None
        assert field.nested_dto.name == "DireccionTO"

    def test_missing_required_raises_error(self):
        """Should raise error for missing required fields."""
        with pytest.raises(ValidationError):
            DataField(name="test")  # missing type_hint


class TestDtoDefinition:
    """Tests for DtoDefinition model."""

    def test_minimal_dto(self):
        """Should create DTO with just name."""
        dto = DtoDefinition(name="ConsultaVO")
        assert dto.name == "ConsultaVO"
        assert dto.file_path is None
        assert dto.fields == []

    def test_dto_with_file_path(self):
        """Should accept file path."""
        dto = DtoDefinition(
            name="PersonaTO",
            file_path=Path("/src/model/PersonaTO.java"),
        )
        assert dto.file_path == Path("/src/model/PersonaTO.java")

    def test_dto_with_fields(self):
        """Should create DTO with fields list."""
        fields = [
            DataField(name="id", type_hint="Long"),
            DataField(name="nombre", type_hint="String"),
        ]
        dto = DtoDefinition(
            name="ClienteTO",
            fields=fields,
        )
        assert len(dto.fields) == 2
        assert dto.fields[0].name == "id"


class TestMethodParameter:
    """Tests for MethodParameter model."""

    def test_simple_parameter(self):
        """Should create parameter with name and type."""
        param = MethodParameter(name="valor", type_hint="String")
        assert param.name == "valor"
        assert param.type_hint == "String"
        assert param.dto is None

    def test_parameter_with_dto(self):
        """Should resolve DTO when provided."""
        dto = DtoDefinition(name="FiltroVO")
        param = MethodParameter(
            name="filtro",
            type_hint="FiltroVO",
            dto=dto,
        )
        assert param.dto is not None
        assert param.dto.name == "FiltroVO"


class TestMethodSignature:
    """Tests for MethodSignature model."""

    def test_void_method(self):
        """Should create void method with no params."""
        method = MethodSignature(name="init", return_type="void")
        assert method.name == "init"
        assert method.return_type == "void"
        assert method.parameters == []
        assert method.documentation is None

    def test_method_with_params(self):
        """Should create method with parameters."""
        params = [
            MethodParameter(name="id", type_hint="Long"),
        ]
        method = MethodSignature(
            name="buscar",
            return_type="ItemTO",
            parameters=params,
        )
        assert len(method.parameters) == 1

    def test_method_with_documentation(self):
        """Should accept documentation fields."""
        method = MethodSignature(
            name="calcular",
            return_type="BigDecimal",
            documentation="Calcula el total",
            manager_summary="Suma todos los items",
        )
        assert method.documentation == "Calcula el total"
        assert method.manager_summary == "Suma todos los items"


class TestEjbContract:
    """Tests for EjbContract model."""

    def test_minimal_contract(self):
        """Should create contract with required fields."""
        contract = EjbContract(
            interface_name="MiServicioFacade",
            annotation="@Remote",
            file_path=Path("/src/MiServicioFacade.java"),
        )
        assert contract.interface_name == "MiServicioFacade"
        assert contract.annotation == "@Remote"
        assert contract.methods == []
        assert contract.related_manager_path is None

    def test_contract_with_methods(self):
        """Should include methods and manager path."""
        methods = [
            MethodSignature(name="crear", return_type="Long"),
            MethodSignature(name="eliminar", return_type="void"),
        ]
        contract = EjbContract(
            interface_name="CrudFacade",
            annotation="@Local",
            file_path=Path("/src/CrudFacade.java"),
            methods=methods,
            related_manager_path=Path("/src/CrudManager.java"),
        )
        assert len(contract.methods) == 2
        assert contract.related_manager_path == Path("/src/CrudManager.java")


class TestProjectScanRequest:
    """Tests for ProjectScanRequest model."""

    def test_basic_request(self):
        """Should create scan request with path."""
        request = ProjectScanRequest(
            project_path=Path("/home/user/project"),
        )
        assert request.project_path == Path("/home/user/project")
        assert request.detailed_scan is False

    def test_detailed_scan(self):
        """Should accept detailed_scan flag."""
        request = ProjectScanRequest(
            project_path=Path("/project"),
            detailed_scan=True,
        )
        assert request.detailed_scan is True


class TestProjectScanResponse:
    """Tests for ProjectScanResponse model."""

    def test_empty_response(self):
        """Should create response with no contracts."""
        response = ProjectScanResponse(
            agent_id="scanner-001",
            contracts=[],
        )
        assert response.agent_id == "scanner-001"
        assert response.contracts == []
        assert response.markdown is None

    def test_response_with_contracts(self):
        """Should include contracts and markdown."""
        contracts = [
            EjbContract(
                interface_name="TestFacade",
                annotation="@Remote",
                file_path=Path("/TestFacade.java"),
            ),
        ]
        response = ProjectScanResponse(
            agent_id="agent-123",
            contracts=contracts,
            markdown="# Summary\n...",
        )
        assert len(response.contracts) == 1
        assert response.markdown == "# Summary\n..."
