"""Tests for configuration loading."""
from __future__ import annotations

import os
from importlib import reload

from config import settings as settings_module


def test_settings_from_env(monkeypatch) -> None:
    """Settings should honor environment overrides."""

    monkeypatch.setenv("AGENT_NAME", "Test Agent")
    monkeypatch.setenv("LLM_PROVIDER", "mock")
    reload(settings_module)
    settings = settings_module.get_settings()
    assert settings.agent_name == "Test Agent"
    assert settings.llm_provider == "mock"
