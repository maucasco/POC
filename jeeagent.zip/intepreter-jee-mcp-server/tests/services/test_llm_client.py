"""Tests for the LLM client abstraction."""
from __future__ import annotations

import asyncio
from pathlib import Path

from config.settings import AgentMetadata, Settings
from services.llm_client import LLMClient
from services.prompt_loader import PromptRepository


async def _call_client(manager_file: Path) -> str | None:
    settings = Settings(
        metadata=AgentMetadata(
            agent_id="test",
            name="Test",
            description="",
            policies="",
        ),
        http_host="127.0.0.1",
        http_port=8000,
        llm_provider="mock",
        openai_model="model",
        anthropic_model="model",
        log_level="INFO",
        max_tokens=256,
    )
    prompts = PromptRepository(base_path=manager_file.parent)
    client = LLMClient(settings, prompts)
    return await client.summarize_manager_logic(manager_file, ctx=None)


def test_llm_client_mock_fallback(tmp_path: Path) -> None:
    """Client should avoid LLM usage when provider is mock."""

    prompt_file = tmp_path / "manager_summary.prompt"
    prompt_file.write_text("Summary for {manager_name}")
    manager_file = tmp_path / "SampleManager.java"
    manager_file.write_text("public class SampleManager {}")

    summary = asyncio.run(_call_client(manager_file))
    assert "manager class" in summary
