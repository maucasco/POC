"""Tests for prompt loading utility."""
from __future__ import annotations

from pathlib import Path

from services.prompt_loader import PromptRepository


def test_prompt_repository_loads_file(tmp_path: Path) -> None:
    """Repository should cache prompt content after first read."""

    prompt_path = tmp_path / "test.prompt"
    prompt_path.write_text("Hello {name}")
    repo = PromptRepository(base_path=tmp_path)

    first = repo.load("test.prompt")
    second = repo.load("test.prompt")

    assert first == "Hello {name}"
    assert second == first
