"""Extended tests for ProjectScanner class."""
import pytest
from pathlib import Path
from tempfile import TemporaryDirectory

import sys
sys.path.insert(0, "/data/agente/intepreter-jee-mcp-server/src")

from core.project_scanner import ProjectScanner


@pytest.fixture
def rich_project():
    """Create a temporary project with complex Java files."""
    with TemporaryDirectory() as tmpdir:
        base = Path(tmpdir)
        
        # Create EJB interface file with multiple methods
        ejb_dir = base / "src" / "main" / "java" / "com" / "example" / "ejb"
        ejb_dir.mkdir(parents=True)
        
        facade_content = '''package com.example.ejb;

import javax.ejb.Remote;

@Remote
public interface RichFacade {
    
    public ResultadoTO consultarDatos(FiltroVO filtro) throws ServiceException;
    
    void procesarItem(Long id, ItemTO item);
    
    List<ResultadoTO> buscarTodos();
    
    HashMap<String, ValorTO> obtenerMapa(String clave, int limite);
    
    ResultadoTO[] buscarArray(String[] codigos);
}
'''
        (ejb_dir / "RichFacade.java").write_text(facade_content)
        
        # Create Local interface
        local_content = '''package com.example.ejb;

import javax.ejb.Local;

@Local
public interface LocalFacade {
    void ejecutarLocal();
}
'''
        (ejb_dir / "LocalFacade.java").write_text(local_content)
        
        # Create DTO files with various field types
        dto_dir = base / "src" / "main" / "java" / "com" / "example" / "model"
        dto_dir.mkdir(parents=True)
        
        filtro_content = '''package com.example.model;

public class FiltroVO {
    private String nombre;
    private Long clienteId;
    private boolean activo = true;
    private ArrayList<String> codigos;
    private NestedTO nested;
}
'''
        (dto_dir / "FiltroVO.java").write_text(filtro_content)
        
        nested_content = '''package com.example.model;

public class NestedTO {
    private String valor;
    private DeepTO deep;
}
'''
        (dto_dir / "NestedTO.java").write_text(nested_content)
        
        deep_content = '''package com.example.model;

public class DeepTO {
    private String deepField;
}
'''
        (dto_dir / "DeepTO.java").write_text(deep_content)
        
        # Create Manager file
        manager_dir = base / "src" / "main" / "java" / "com" / "example" / "manager"
        manager_dir.mkdir(parents=True)
        
        manager_content = '''package com.example.manager;

public class RichFacadeManager {
    public void doWork() {}
}
'''
        (manager_dir / "RichFacadeManager.java").write_text(manager_content)
        
        yield base


class TestProjectScannerExtended:
    """Extended tests for ProjectScanner."""

    def test_scan_finds_multiple_contracts(self, rich_project):
        """Should find all EJB contracts."""
        scanner = ProjectScanner(rich_project)
        contracts = scanner.scan()
        
        names = {c.interface_name for c in contracts}
        assert "RichFacade" in names
        assert "LocalFacade" in names
        assert len(contracts) == 2

    def test_detects_local_annotation(self, rich_project):
        """Should detect @Local annotation."""
        scanner = ProjectScanner(rich_project)
        contracts = scanner.scan()
        
        local = next(c for c in contracts if c.interface_name == "LocalFacade")
        assert local.annotation == "@Local"


class TestMethodParsing:
    """Tests for method parsing edge cases."""

    def test_parses_generic_return_types(self, rich_project):
        """Should parse generic return types."""
        scanner = ProjectScanner(rich_project)
        contracts = scanner.scan()
        rich = next(c for c in contracts if c.interface_name == "RichFacade")
        
        buscar = next(m for m in rich.methods if m.name == "buscarTodos")
        assert "List<ResultadoTO>" in buscar.return_type

    def test_parses_hashmap_return(self, rich_project):
        """Should parse HashMap return types."""
        scanner = ProjectScanner(rich_project)
        contracts = scanner.scan()
        rich = next(c for c in contracts if c.interface_name == "RichFacade")
        
        mapa = next((m for m in rich.methods if m.name == "obtenerMapa"), None)
        if mapa:
            assert "HashMap" in mapa.return_type or "Map" in mapa.return_type

    def test_parses_map_with_spaces_in_generics(self, tmp_path):
        """Should parse Map<String, String> with spaces after comma."""
        facade_content = '''
@Remote
public interface ConfigFacade {
    Map<String, String> getParameters(String config);
    HashMap<Integer, List<String>> getComplexMap();
}
'''
        (tmp_path / "ConfigFacade.java").write_text(facade_content)
        
        scanner = ProjectScanner(tmp_path)
        contracts = scanner.scan()
        
        assert len(contracts) == 1
        config = contracts[0]
        assert config.interface_name == "ConfigFacade"
        
        # Test Map<String, String>
        get_params = next(m for m in config.methods if m.name == "getParameters")
        assert "Map" in get_params.return_type
        assert "String" in get_params.return_type
        # Should capture the full type with spaces
        assert "Map<String, String>" in get_params.return_type.replace(" ", "") or "Map<String,String>" in get_params.return_type.replace(" ", "")
        
        # Test HashMap<Integer, List<String>>
        get_complex = next(m for m in config.methods if m.name == "getComplexMap")
        assert "HashMap" in get_complex.return_type or "Map" in get_complex.return_type
        assert "Integer" in get_complex.return_type

    def test_parses_array_return(self, rich_project):
        """Should parse array return types."""
        scanner = ProjectScanner(rich_project)
        contracts = scanner.scan()
        rich = next(c for c in contracts if c.interface_name == "RichFacade")
        
        buscar_array = next((m for m in rich.methods if m.name == "buscarArray"), None)
        if buscar_array:
            assert "ResultadoTO[]" in buscar_array.return_type or "ResultadoTO" in buscar_array.return_type


class TestNestedDtoResolution:
    """Tests for nested DTO resolution."""

    def test_resolves_depth_one(self, rich_project):
        """Should resolve first level nested DTO."""
        scanner = ProjectScanner(rich_project, dto_depth=3)
        dto = scanner._resolve_dto("FiltroVO")
        
        assert dto is not None
        nested_field = next((f for f in dto.fields if f.name == "nested"), None)
        assert nested_field is not None
        assert nested_field.nested_dto is not None
        assert nested_field.nested_dto.name == "NestedTO"

    def test_resolves_depth_two(self, rich_project):
        """Should resolve second level nested DTO."""
        scanner = ProjectScanner(rich_project, dto_depth=3)
        dto = scanner._resolve_dto("FiltroVO")
        
        nested_field = next(f for f in dto.fields if f.name == "nested")
        nested_dto = nested_field.nested_dto
        
        deep_field = next((f for f in nested_dto.fields if f.name == "deep"), None)
        assert deep_field is not None
        assert deep_field.nested_dto is not None
        assert deep_field.nested_dto.name == "DeepTO"

    def test_respects_depth_limit(self, rich_project):
        """Should stop at depth limit."""
        scanner = ProjectScanner(rich_project, dto_depth=1)
        dto = scanner._resolve_dto("FiltroVO")
        
        # First level should be resolved
        nested_field = next((f for f in dto.fields if f.name == "nested"), None)
        # But second level might not have its nested resolved due to depth limit
        if nested_field and nested_field.nested_dto:
            deep_field = next((f for f in nested_field.nested_dto.fields if f.name == "deep"), None)
            if deep_field:
                # At depth 1, the deep DTO should not be resolved
                assert deep_field.nested_dto is None


class TestCaching:
    """Tests for DTO caching behavior."""

    def test_cache_prevents_duplicate_resolution(self, rich_project):
        """Should use cache for repeated resolutions."""
        scanner = ProjectScanner(rich_project)
        
        # Clear cache
        scanner._dto_cache.clear()
        
        # First resolution
        dto1 = scanner._resolve_dto("FiltroVO")
        cache_size_after_first = len(scanner._dto_cache)
        
        # Second resolution
        dto2 = scanner._resolve_dto("FiltroVO")
        cache_size_after_second = len(scanner._dto_cache)
        
        # Should use cached version
        assert dto1 is dto2
        assert cache_size_after_first == cache_size_after_second

    def test_cache_stores_none_for_missing(self, rich_project):
        """Should cache None for non-existent DTOs."""
        scanner = ProjectScanner(rich_project)
        scanner._dto_cache.clear()
        
        result = scanner._resolve_dto("NonExistentDTO")
        
        assert result is None
        assert "NonExistentDTO" in scanner._dto_cache
        assert scanner._dto_cache["NonExistentDTO"] is None


class TestManagerDiscoveryExtended:
    """Extended tests for manager discovery."""

    def test_tries_multiple_naming_patterns(self, tmp_path):
        """Should try different manager naming patterns."""
        # Create interface
        facade_content = '''
@Remote
public interface TestFacade {
    void test();
}
'''
        (tmp_path / "TestFacade.java").write_text(facade_content)
        
        # Create manager with Mngr suffix
        mngr_content = '''
public class TestMngr {
    void handle() {}
}
'''
        (tmp_path / "TestMngr.java").write_text(mngr_content)
        
        scanner = ProjectScanner(tmp_path)
        manager = scanner._find_manager_path("Test")
        
        assert manager is not None
        assert "TestMngr.java" in str(manager)

    def test_finds_facade_stripped_manager(self, tmp_path):
        """Should find manager when Facade is stripped from name."""
        # Create interface
        facade_content = '''
@Remote
public interface PropuestaFacade {
    void test();
}
'''
        (tmp_path / "PropuestaFacade.java").write_text(facade_content)
        
        # Create manager without Facade in name
        manager_content = '''
public class PropuestaManager {
    void handle() {}
}
'''
        (tmp_path / "PropuestaManager.java").write_text(manager_content)
        
        scanner = ProjectScanner(tmp_path)
        manager = scanner._find_manager_path("PropuestaFacade")
        
        assert manager is not None
        assert "PropuestaManager.java" in str(manager)

    def test_finds_local_interface_with_bean_impl(self, tmp_path):
        """Should find Bean implementation for Local interface."""
        # Create Local interface
        local_content = '''
@Local
public interface ParametrosPortalServiceLocal {
    void getParametros();
}
'''
        (tmp_path / "ParametrosPortalServiceLocal.java").write_text(local_content)
        
        # Create Bean implementation
        bean_content = '''
public class ParametrosPortalServiceBean {
    void handle() {}
}
'''
        (tmp_path / "ParametrosPortalServiceBean.java").write_text(bean_content)
        
        scanner = ProjectScanner(tmp_path)
        contracts = scanner.scan()
        
        assert len(contracts) == 1
        assert contracts[0].interface_name == "ParametrosPortalServiceLocal"
        assert contracts[0].related_manager_path is not None
        assert "ParametrosPortalServiceBean.java" in str(contracts[0].related_manager_path)

    def test_finds_remote_interface_with_bean_impl(self, tmp_path):
        """Should find Bean implementation for Remote interface."""
        # Create Remote interface
        remote_content = '''
@Remote
public interface ConfigurationServiceRemote {
    void configure();
}
'''
        (tmp_path / "ConfigurationServiceRemote.java").write_text(remote_content)
        
        # Create Bean implementation (without Remote suffix)
        bean_content = '''
public class ConfigurationServiceBean {
    void handle() {}
}
'''
        (tmp_path / "ConfigurationServiceBean.java").write_text(bean_content)
        
        scanner = ProjectScanner(tmp_path)
        contracts = scanner.scan()
        
        assert len(contracts) == 1
        assert contracts[0].interface_name == "ConfigurationServiceRemote"
        assert contracts[0].related_manager_path is not None
        assert "ConfigurationServiceBean.java" in str(contracts[0].related_manager_path)

    def test_finds_facade_with_mngr_impl(self, tmp_path):
        """Should find Mngr implementation for Facade interface."""
        # Create Facade interface
        facade_content = '''
@Remote
public interface AdministracionPropuestaFacade {
    void administrar();
}
'''
        (tmp_path / "AdministracionPropuestaFacade.java").write_text(facade_content)
        
        # Create Mngr implementation (without Facade suffix)
        mngr_content = '''
public class AdministracionPropuestaMngr {
    void handle() {}
}
'''
        (tmp_path / "AdministracionPropuestaMngr.java").write_text(mngr_content)
        
        scanner = ProjectScanner(tmp_path)
        contracts = scanner.scan()
        
        assert len(contracts) == 1
        assert contracts[0].interface_name == "AdministracionPropuestaFacade"
        assert contracts[0].related_manager_path is not None
        assert "AdministracionPropuestaMngr.java" in str(contracts[0].related_manager_path)


class TestErrorHandling:
    """Tests for error handling."""

    def test_handles_malformed_java_file(self, tmp_path):
        """Should handle malformed Java files gracefully."""
        malformed = '''
@Remote
public interface Broken {
    // Missing closing brace
'''
        (tmp_path / "BrokenFacade.java").write_text(malformed)
        
        scanner = ProjectScanner(tmp_path)
        # Should not raise exception
        contracts = scanner.scan()
        # May or may not find the broken interface, but shouldn't crash
        assert isinstance(contracts, list)

    def test_handles_binary_file(self, tmp_path):
        """Should handle binary content gracefully."""
        # Write some binary content
        (tmp_path / "BinaryFacade.java").write_bytes(b'\x00\x01\x02\x03\xff\xfe')
        
        scanner = ProjectScanner(tmp_path)
        # Should not raise exception due to errors='ignore'
        contracts = scanner.scan()
        assert isinstance(contracts, list)
