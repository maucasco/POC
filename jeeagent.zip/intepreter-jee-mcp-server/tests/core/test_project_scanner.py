"""Tests for the `ProjectScanner`."""
from __future__ import annotations

from pathlib import Path

from core import ProjectScanner


def test_scanner_detects_interfaces(tmp_path: Path) -> None:
    """Scanner should capture interface metadata and DTO fields."""

    interface_content = """@Remote
public interface SampleFacade {
    ResponseDto fetchData(RequestDto request);
}
"""
    dto_content = """public class RequestDto {
    private String customerId;
}
"""
    manager_content = """public class SampleFacadeManager {
    public void handle() {}
}
"""
    (tmp_path / "SampleFacade.java").write_text(interface_content)
    (tmp_path / "RequestDto.java").write_text(dto_content)
    (tmp_path / "SampleFacadeManager.java").write_text(manager_content)

    scanner = ProjectScanner(tmp_path)
    contracts = scanner.scan()

    assert len(contracts) == 1
    contract = contracts[0]
    assert contract.interface_name == "SampleFacade"
    assert contract.related_manager_path is not None
    assert contract.methods[0].parameters[0].dto is not None
