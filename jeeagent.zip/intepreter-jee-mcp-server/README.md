# JEE Interpreter MCP Server

Servidor MCP (Model Context Protocol) que escanea proyectos Jakarta EE para localizar interfaces EJB, extraer contratos de métodos y opcionalmente resumir la lógica de negocio de las clases Manager.

## Características

- 🔍 **Escaneo de proyectos**: Detecta interfaces con `@Remote`/`@Local` y sufijos `Remote`, `Facade`, `Local`
- 🏗️ **Descubrimiento de implementaciones**: Encuentra automáticamente clases de lógica de negocio con sufijos `Manager`, `Mngr` o `Bean`
- 📋 **Extracción de contratos**: Métodos, parámetros, tipos de retorno (incluyendo genéricos complejos como `Map<String, String>`) y campos de DTOs
- 🤖 **Resumen con LLM**: Análisis opcional de clases de implementación usando OpenAI o Claude
- 📄 **Salida estructurada**: JSON y Markdown para documentación
- 🔌 **Transporte stdio**: Comunicación eficiente via subprocess (JSON-RPC)

## Instalación

### Opción A: Usando venv (recomendado)

```bash
cd intepreter-jee-mcp-server
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

### Opción B: Usando uv

```bash
uv init
uv add "mcp[cli]" pydantic python-dotenv anyio
uv add --group dev pytest pytest-asyncio pytest-cov
```

## Configuración

Crear archivo `.env`:

```env
# Agent Metadata
AGENT_NAME=jee-interpreter
AGENT_VERSION=0.1.0

# LLM Provider (para detailed_scan): openai | anthropic
LLM_PROVIDER=openai
OPENAI_API_KEY=sk-your-key
OPENAI_MODEL=gpt-4o-mini

# Alternativa Anthropic
ANTHROPIC_API_KEY=sk-ant-your-key
ANTHROPIC_MODEL=claude-3-5-sonnet-20241022

# Implementation Discovery (opcional)
# Sufijos para buscar clases de implementación (separados por coma)
IMPLEMENTATION_SUFFIXES=Manager,Mngr,Bean
```

## Ejecución

### Modo stdio (recomendado para agentes)

```bash
cd /data/agente/intepreter-jee-mcp-server
PYTHONPATH=src python -m src.main
```

El servidor escucha en stdin y responde en stdout usando JSON-RPC 2.0.

### Modo HTTP (legacy)

```bash
# Agregar a .env
HTTP_HOST=127.0.0.1
HTTP_PORT=8090
TRANSPORT=http

# Ejecutar
python -m src.main
```

## Uso desde agentes

Los agentes `quarkus-codegen-agent` y `jee-doc-agent` lanzan este servidor automáticamente como subprocess. Configurar en `.env` del agente:

```env
MCP_SERVER_COMMAND=/data/agente/.venv/bin/python
MCP_SERVER_ARGS=-m,src.main
MCP_SERVER_CWD=/data/agente/intepreter-jee-mcp-server
```

## Herramientas MCP Disponibles

### `scan_ejb_contracts`

Escanea un proyecto JEE y extrae contratos EJB.

**Parámetros:**
| Parámetro | Tipo | Descripción |
|-----------|------|-------------|
| `project_path` | string | Ruta absoluta al proyecto Java EE |
| `detailed_scan` | boolean | Si `true`, analiza Managers con LLM |

**Ejemplo JSON-RPC:**
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "scan_ejb_contracts",
    "arguments": {
      "project_path": "/path/to/java/project",
      "detailed_scan": false
    }
  }
}
```

**Respuesta:**
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "content": [{
      "type": "text",
      "text": "{\"contracts\": [...], \"markdown\": \"...\"}"
    }]
  }
}
```

## Estructura del Proyecto

```
intepreter-jee-mcp-server/
├── src/
│   ├── main.py           # Entry point y registro MCP
│   ├── config/
│   │   └── settings.py   # Configuración desde .env
│   ├── core/
│   │   └── project_scanner.py  # Lógica de escaneo Java
│   ├── models/
│   │   └── ejb_contract.py     # Modelos Pydantic
│   ├── services/
│   │   ├── llm_client.py       # Cliente LLM abstracto
│   │   └── prompt_loader.py    # Carga de prompts
│   ├── prompts/
│   │   ├── contract_markdown_template.md
│   │   └── manager_summary.prompt
│   └── agent/
│       └── ejb_agent.py  # Registro de herramientas MCP
└── tests/                # Tests pytest
```

## Tests

```bash
# Activar entorno
source .venv/bin/activate

# Ejecutar tests
pytest

# Con cobertura
pytest --cov=src --cov-report=html
```

## Notas

- El análisis detallado (`detailed_scan=true`) requiere API key configurada
- Los prompts están en `src/prompts/` para fácil personalización
- El logging está estandarizado para debugging

## Licencia

MIT
