#!/bin/bash
# =============================================================================
# JEE MCP Server - Build and Deploy Script
# =============================================================================
# This script builds the Docker image and runs the MCP server container
#
# Usage:
#   ./build-docker.sh                           # Build and run with defaults
#   ./build-docker.sh --port 9000               # Custom port
#   ./build-docker.sh --jee-path /path/to/jee   # Custom JEE projects path
#   ./build-docker.sh --output-path /path/out   # Custom output path
#   ./build-docker.sh --build-only              # Only build, don't run
#   ./build-docker.sh --run-only                # Only run (image must exist)
#   ./build-docker.sh --stop                    # Stop running container
#   ./build-docker.sh --logs                    # View container logs
# =============================================================================

set -e

# Default values
MCP_PORT="${MCP_PORT:-8080}"
CACHE_TTL_MINUTES="${CACHE_TTL_MINUTES:-30}"
JEE_PROJECTS_MOUNT="${JEE_PROJECTS_MOUNT:-./jee-projects}"
OUTPUT_MOUNT="${OUTPUT_MOUNT:-./output}"
IMAGE_NAME="jee-mcp-server:latest"
CONTAINER_NAME="jee-mcp-server"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Functions
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

show_help() {
    echo "JEE MCP Server - Build and Deploy Script"
    echo ""
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  --port PORT           MCP server port (default: 8080)"
    echo "  --cache-ttl MINUTES   Cache TTL in minutes (default: 30)"
    echo "  --jee-mount PATH      Host path to mount at /data/jee-projects (default: ./jee-projects)"
    echo "  --output-mount PATH   Host path to mount at /data/output (default: ./output)"
    echo "  --build-only          Only build the Docker image"
    echo "  --run-only            Only run the container (image must exist)"
    echo "  --stop                Stop the running container"
    echo "  --logs                View container logs (follow mode)"
    echo "  --status              Show container status"
    echo "  --clean               Remove container and image"
    echo "  -h, --help            Show this help message"
    echo ""
    echo "Environment Variables:"
    echo "  MCP_PORT              MCP server port"
    echo "  CACHE_TTL_MINUTES     Cache TTL in minutes"
    echo "  LLM_PROVIDER          LLM provider (openai/anthropic)"
    echo "  OPENAI_API_KEY        OpenAI API key"
    echo "  ANTHROPIC_API_KEY     Anthropic API key"
    echo ""
    echo "Note: Paths are provided by the client (GitHub Copilot) in each tool call."
    echo "      Mount directories to make them accessible from the container."
    echo ""
    echo "Examples:"
    echo "  $0                                    # Build and run with defaults"
    echo "  $0 --port 9000                        # Custom port"
    echo "  $0 --jee-mount /my/jee/projects       # Mount custom directory"
    echo "  $0 --build-only                       # Only build image"
    echo "  $0 --logs                             # View logs"
}

check_docker() {
    if ! command -v docker &> /dev/null; then
        print_error "Docker is not installed. Please install Docker first."
        exit 1
    fi
    
    if ! docker info &> /dev/null; then
        print_error "Docker daemon is not running. Please start Docker."
        exit 1
    fi
}

check_env_file() {
    if [[ ! -f ".env" ]]; then
        if [[ -f ".env.example" ]]; then
            print_warning "No .env file found. Creating from .env.example..."
            cp .env.example .env
            print_warning "Please edit .env and set your API keys before running."
        else
            print_warning "No .env file found. Using environment variables or defaults."
        fi
    fi
}

create_directories() {
    # Create mount directories if they don't exist
    if [[ ! -d "$JEE_PROJECTS_MOUNT" ]]; then
        print_info "Creating JEE projects mount directory: $JEE_PROJECTS_MOUNT"
        mkdir -p "$JEE_PROJECTS_MOUNT"
    fi
    
    if [[ ! -d "$OUTPUT_MOUNT" ]]; then
        print_info "Creating output mount directory: $OUTPUT_MOUNT"
        mkdir -p "$OUTPUT_MOUNT"
    fi
}

build_image() {
    print_info "Building Docker image: $IMAGE_NAME"
    print_info "MCP Port: $MCP_PORT"
    
    docker build \
        --build-arg MCP_PORT="$MCP_PORT" \
        -t "$IMAGE_NAME" \
        -f Dockerfile \
        .
    
    print_success "Docker image built successfully: $IMAGE_NAME"
}

run_container() {
    print_info "Starting MCP server container..."
    print_info "Port: $MCP_PORT"
    print_info "Cache TTL: $CACHE_TTL_MINUTES minutes"
    print_info "JEE Mount: $JEE_PROJECTS_MOUNT -> /data/jee-projects"
    print_info "Output Mount: $OUTPUT_MOUNT -> /data/output"
    print_info ""
    print_info "Path translation enabled:"
    print_info "  Client sends: $JEE_PROJECTS_MOUNT/... -> Container uses: /data/jee-projects/..."
    print_info "  Client sends: $OUTPUT_MOUNT/... -> Container uses: /data/output/..."
    
    # Export variables for docker-compose
    export MCP_PORT
    export CACHE_TTL_MINUTES
    export JEE_PROJECTS_MOUNT
    export OUTPUT_MOUNT
    
    # Stop existing container if running
    if docker ps -q -f name="$CONTAINER_NAME" | grep -q .; then
        print_info "Stopping existing container..."
        docker-compose down
    fi
    
    # Start with docker-compose
    docker-compose up -d
    
    print_success "MCP server started!"
    echo ""
    print_info "Server URL: http://localhost:$MCP_PORT"
    print_info "Health check: http://localhost:$MCP_PORT/health"
    echo ""
    print_info "View logs: $0 --logs"
    print_info "Stop server: $0 --stop"
}

stop_container() {
    print_info "Stopping MCP server container..."
    docker-compose down
    print_success "Container stopped."
}

show_logs() {
    print_info "Showing container logs (Ctrl+C to exit)..."
    docker-compose logs -f
}

show_status() {
    echo ""
    print_info "Container Status:"
    docker-compose ps
    echo ""
    
    if docker ps -q -f name="$CONTAINER_NAME" | grep -q .; then
        print_info "Server URL: http://localhost:$MCP_PORT"
        print_info "Health check: http://localhost:$MCP_PORT/health"
    fi
}

clean_all() {
    print_warning "This will remove the container and image. Continue? (y/N)"
    read -r response
    if [[ "$response" =~ ^[Yy]$ ]]; then
        print_info "Stopping container..."
        docker-compose down 2>/dev/null || true
        
        print_info "Removing image..."
        docker rmi "$IMAGE_NAME" 2>/dev/null || true
        
        print_success "Cleanup complete."
    else
        print_info "Cleanup cancelled."
    fi
}

# Parse arguments
BUILD_ONLY=false
RUN_ONLY=false
SHOW_LOGS=false
STOP=false
STATUS=false
CLEAN=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --port)
            MCP_PORT="$2"
            shift 2
            ;;
        --cache-ttl)
            CACHE_TTL_MINUTES="$2"
            shift 2
            ;;
        --jee-mount)
            JEE_PROJECTS_MOUNT="$2"
            shift 2
            ;;
        --output-mount)
            OUTPUT_MOUNT="$2"
            shift 2
            ;;
        --build-only)
            BUILD_ONLY=true
            shift
            ;;
        --run-only)
            RUN_ONLY=true
            shift
            ;;
        --logs)
            SHOW_LOGS=true
            shift
            ;;
        --stop)
            STOP=true
            shift
            ;;
        --status)
            STATUS=true
            shift
            ;;
        --clean)
            CLEAN=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            print_error "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
done

# Main execution
check_docker

if [[ "$SHOW_LOGS" == true ]]; then
    show_logs
    exit 0
fi

if [[ "$STOP" == true ]]; then
    stop_container
    exit 0
fi

if [[ "$STATUS" == true ]]; then
    show_status
    exit 0
fi

if [[ "$CLEAN" == true ]]; then
    clean_all
    exit 0
fi

check_env_file
create_directories

if [[ "$RUN_ONLY" == true ]]; then
    run_container
elif [[ "$BUILD_ONLY" == true ]]; then
    build_image
else
    build_image
    run_container
fi
