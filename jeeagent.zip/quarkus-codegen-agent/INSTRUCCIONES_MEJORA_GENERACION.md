# 🎯 Instrucciones para Mejorar la Generación del MCP JEE-to-Quarkus

> **Objetivo:** Pasar de 65% → 90%+ de código generado correcto sin intervención manual
> **Fecha:** Febrero 2026
> **Contexto:** Análisis post-migración de ParametrosPortalServiceLocal

---

## 📊 Estado Actual vs Objetivo

| Componente | Actual | Objetivo | Gap |
|------------|--------|----------|-----|
| **Generación inicial (nuevo)** | 85% ✓ | 95% | 10% |
| **Generación incremental** | **45% ⚠️** | **90%** | **45%** |
| **Tipos correctos** | 60% | 95% | 35% |
| **Imports correctos** | 70% | 98% | 28% |
| **Compilación directa** | 0% (requiere fixes) | 85% | 85% |

---

## 🔴 PROBLEMAS CRÍTICOS IDENTIFICADOS

### 1. Tipos Incorrectos en RmiAdapter (CRÍTICO)

#### ❌ Problema Actual:
```java
// Generado por MCP - INCORRECTO
Object ejbResponse = facade.consultarParametrosValoresConfiguracion(request.nombreConfiguracion());
```

#### ✅ Solución:
```java
// Correcto - tipo específico
java.util.Map<String, String> ejbResponse = facade.consultarParametrosValoresConfiguracion(
    request.nombreConfiguracion()
);
```

#### 📝 Instrucción Específica para `rmi_adapter_method.prompt`:

**AGREGAR ANTES DE LA SECCIÓN "Formato de salida":**

```markdown
## ⚠️ INFERENCIA DE TIPOS CRÍTICA:

**Recibirás en el contexto:**
- `method_signature` con el tipo de retorno del EJB
- `ejb_interface_code` con la firma completa del método en la interfaz EJB

**REGLA OBLIGATORIA - ANALIZAR EL TIPO DE RETORNO:**

1. **Busca en ejb_interface_code la firma del método:**
   ```java
   // Ejemplo en el contexto:
   Map<String, String> consultarParametrosValoresConfiguracion(String nombreConfiguracion);
   ```

2. **Extrae el tipo de retorno EXACTO:**
   - Si es `Map<String, String>` → usa `java.util.Map<String, String>`
   - Si es `ParametrosPortalDTO` → usa el DTO del paquete model
   - Si es `List<AlgoVO>` → usa `java.util.List<AlgoVO>`
   - Si es `ArrayList<AlgoVO>` → usa `java.util.ArrayList<AlgoVO>` (NO cambiar a List)

3. **NUNCA usar Object:**
   ```java
   // ❌ PROHIBIDO:
   Object ejbResponse = facade.metodo(...);
   
   // ✅ CORRECTO:
   java.util.Map<String, String> ejbResponse = facade.metodo(...);
   // o
   ParametrosPortalDTO ejbResponse = facade.metodo(...);
   ```

**PATRÓN OBLIGATORIO:**
```java
// 1. Declarar variable con tipo explícito del EJB
TipoRetornoExactoDelEJB ejbResponse = facade.{methodName}(...);

// 2. Convertir a Response de API con el Mapper
return {MetodoPascalCase}Mapper.toApiResponse(ejbResponse);
```
```

---

### 2. Imports Incorrectos (CRÍTICO)

#### ❌ Problema Actual:
```java
// Generado por MCP - INCORRECTO
import com.davivienda.infrastructure.adapter.out.rmi.model.ConsultarParametrosValoresConfiguracionRequest;
import com.davivienda.infrastructure.adapter.out.rmi.model.ConsultarParametrosValoresConfiguracionResponse;
```

#### ✅ Solución:
```java
// Correcto
import com.davivienda.domain.model.ConsultarParametrosValoresConfiguracionRequest;
import com.davivienda.domain.model.ConsultarParametrosValoresConfiguracionResponse;
```

#### 📝 Instrucción Específica - APLICAR A TODOS LOS PROMPTS:

**AGREGAR AL INICIO DE CADA PROMPT (_method.prompt):**

```markdown
## 🚨 IMPORTS OBLIGATORIOS - VALIDACIÓN AUTOMÁTICA

**Antes de generar código, VALIDA estos imports en tu mente:**

| Tipo de Clase | Package CORRECTO | Package INCORRECTO |
|---------------|------------------|----------------------|
| {MetodoPascalCase}Request | ✅ {base_package}.domain.model | ❌ .infrastructure.adapter... |
| {MetodoPascalCase}Response | ✅ {base_package}.domain.model | ❌ .infrastructure.adapter... |
| {MetodoPascalCase}Mapper | ✅ {base_package}.infrastructure.mapper | ❌ .domain... |
| ParametrosPortalDTO (TOs/VOs) | ✅ {base_package}.infrastructure.adapter.out.rmi.model | ❌ .domain... |

**MNEMOTÉCNICA:**
- **Request/Response** → `domain.model` (son del DOMINIO)
- **Mapper** → `infrastructure.mapper` (es infraestructura)
- **TO/VO/DTO del EJB** → `infrastructure.adapter.out.rmi.model` (modelos legacy)

**AUTOVALIDACIÓN (mental antes de generar):**
```
¿Este import tiene "infrastructure" antes de "Request" o "Response"? 
  → SI = ❌ ERROR
  → NO = ✅ CORRECTO
```
```

---

### 3. Generación Incompleta en Facades (CRÍTICO)

#### ❌ Problema Actual:
Cuando se agrega un segundo método, el `ejb_facade_method.prompt` genera el método pero con tipo `Object` o incompleto.

#### 📝 Instrucción Específica para `ejb_facade_method.prompt`:

**REEMPLAZAR LA SECCIÓN "TIPOS DE RETORNO COMUNES EN EJB":**

```markdown
## 🎯 DETECCIÓN AUTOMÁTICA DEL TIPO DE RETORNO

**Recibirás en el contexto `ejb_method_signature` con información como:**
```
consultarParametrosValoresConfiguracion(String nombreConfiguracion) : Map<String,String>
```

**PASOS OBLIGATORIOS:**

1. **Parsear la signature:**
   - Todo lo que está DESPUÉS de `:` es el tipo de retorno
   - Ejemplo: `Map<String,String>` → tipo completo con genéricos

2. **Preservar EXACTAMENTE el tipo:**
   ```java
   // ❌ PROHIBIDO simplificar:
   Map consultarParametros(...);  // Falta <String, String>
   
   // ✅ CORRECTO preservar genéricos:
   Map<String, String> consultarParametros(...);
   ```

3. **Colecciones - NO cambiar implementación:**
   ```java
   // Si el EJB retorna ArrayList:
   ArrayList<ParametroDTO> getParametros();  // ✅ PRESERVAR ArrayList
   
   // ❌ NO cambiar a:
   List<ParametroDTO> getParametros();  // ❌ MAL
   ```

4. **Tipos wrapper vs primitivos:**
   - Si signature dice `int` → usar `int` (NO Integer)
   - Si signature dice `Integer` → usar `Integer`
   - PRESERVAR el tipo original SIEMPRE

**TEMPLATE OBLIGATORIO:**
```java
/**
 * {Descripción del javadoc del método original del EJB}.
 *
 * @param {nombre} {descripción del parámetro}
 * @return {descripción basada en el tipo de retorno}
 */
{TipoRetornoExacto} {methodName}(...parametros...);
```
```

---

## 🟡 MEJORAS PARA GENERACIÓN INCREMENTAL

### 4. Validación Pre-Generación

#### 📝 Instrucción para `code_generator.py`:

**AGREGAR MÉTODO DE VALIDACIÓN ANTES DE LLAMAR AL LLM:**

```python
def _validate_method_context(self, method: MethodSignature, existing_class_code: str | None) -> dict[str, Any]:
    """Valida y enriquece el contexto antes de generar código incremental.
    
    Returns:
        dict con validaciones y tipos inferidos
    """
    validation = {
        "has_existing_class": existing_class_code is not None,
        "return_type_explicit": None,
        "param_types_explicit": [],
        "warnings": []
    }
    
    # Si existe clase, extraer tipos de otros métodos para contexto
    if existing_class_code:
        # Buscar patrones de tipos usados en otros métodos
        type_patterns = re.findall(r'(\w+(?:<[^>]+>)?)\s+(\w+)\s*=\s*facade\.(\w+)\(', existing_class_code)
        if type_patterns:
            validation["existing_patterns"] = type_patterns
            LOGGER.info(f"Found {len(type_patterns)} existing type patterns for context")
    
    # Validar que el tipo de retorno no sea Object
    if method.return_type_java and "Object" in method.return_type_java:
        validation["warnings"].append("⚠️ Return type contains 'Object' - should be specific type")
    
    # Extraer tipo de retorno explícito si está en la signature
    if hasattr(method, 'signature_str'):
        match = re.search(r':\s*([^:]+)$', method.signature_str)
        if match:
            validation["return_type_explicit"] = match.group(1).strip()
            LOGGER.info(f"Extracted explicit return type: {validation['return_type_explicit']}")
    
    return validation
```

**USO EN generate_for_method():**

```python
# Antes de generar código incremental
if existing_code:
    validation = self._validate_method_context(method, existing_code)
    # Agregar validaciones al contexto del prompt
    context_vars["type_validation"] = validation
    context_vars["explicit_return_type"] = validation.get("return_type_explicit")
```

---

### 5. Post-Validación de Código Generado

#### 📝 Instrucción para `code_generator.py`:

**AGREGAR MÉTODO DE VALIDACIÓN POST-GENERACIÓN:**

```python
def _validate_generated_code(self, code: str, component_type: str, method_name: str) -> tuple[bool, list[str]]:
    """Valida código generado antes de devolverlo.
    
    Returns:
        (is_valid, list_of_errors)
    """
    errors = []
    
    # 1. Verificar imports incorrectos
    wrong_imports = [
        r'import\s+\w+\.infrastructure\.adapter\.out\.rmi\.model\.\w+(?:Request|Response)',
        r'import\s+\w+\.domain\.model\.\w+(?:VO|TO|DTO)(?!\w*(Request|Response))',
    ]
    
    for pattern in wrong_imports:
        if re.search(pattern, code):
            errors.append(f"❌ Import incorrecto detectado: Request/Response debe estar en domain.model")
    
    # 2. Verificar uso de Object en lugar de tipos específicos
    if component_type == "rmi_adapter":
        object_usage = re.search(r'Object\s+ejbResponse\s*=', code)
        if object_usage:
            errors.append(f"❌ Uso de 'Object' en lugar de tipo específico en RmiAdapter")
    
    # 3. Verificar que métodos @Override existan
    if '@Override' in code and component_type in ['service', 'rmi_adapter']:
        # Debe tener al menos una llamada al método correspondiente
        if f'.{method_name}(' not in code:
            errors.append(f"⚠️ Método @Override no parece llamar a {method_name}")
    
    # 4. Para RmiAdapter, verificar uso del Mapper correcto
    if component_type == "rmi_adapter":
        method_pascal = self._to_pascal_case(method_name)
        expected_mapper = f"{method_pascal}Mapper"
        if expected_mapper not in code and "Mapper.toApiResponse" in code:
            errors.append(f"⚠️ Posible uso de Mapper incorrecto, esperado: {expected_mapper}")
    
    is_valid = len(errors) == 0
    return is_valid, errors

def _to_pascal_case(self, camel_str: str) -> str:
    """Convierte camelCase a PascalCase."""
    return camel_str[0].upper() + camel_str[1:] if camel_str else ""
```

**INTEGRAR EN generate_component():**

```python
async def _generate_component(self, prompt: str, context: dict) -> str:
    # ... código existente de generación ...
    
    # Validar antes de devolver
    component_type = context.get('component_type', 'unknown')
    method_name = context.get('methodName', '')
    
    is_valid, errors = self._validate_generated_code(generated_code, component_type, method_name)
    
    if not is_valid:
        LOGGER.warning(f"Validación falló para {component_type}.{method_name}:")
        for error in errors:
            LOGGER.warning(f"  {error}")
        
        # Si hay errores críticos (imports incorrectos), podríamos regenerar
        if any("❌" in e for e in errors):
            LOGGER.error("Errores críticos detectados - considerar regeneración")
            # Opcional: re-intentar con prompt mejorado
    
    return generated_code
```

---

## 🟢 MEJORAS PARA CONTEXTO Y HINTS

### 6. Enriquecer Contexto de Generación

#### 📝 Instrucción para `code_generator.py`:

**EN `generate_for_method()`, ANTES DE GENERAR COMPONENTES:**

```python
# Enriquecer contexto con información del Request para RmiAdapter
if method.params and len(method.params) > 0:
    # Intentar leer el código del Request si ya existe
    request_name = f"{self._to_pascal_case(method.name)}Request"
    request_path = output_dir / "src" / "main" / "java" / self.package_path / "domain" / "model" / f"{request_name}.java"
    
    if request_path.exists():
        request_code = request_path.read_text()
        context_vars["request_code"] = request_code
        LOGGER.info(f"Added request_code to context for {method.name}")
        
        # Extraer campos del Request record
        fields_match = re.search(r'record\s+\w+\s*\((.*?)\)', request_code, re.DOTALL)
        if fields_match:
            fields_str = fields_match.group(1)
            # Parsear campos: "String campo1, Integer campo2"
            context_vars["request_fields_parsed"] = fields_str
            LOGGER.info(f"Parsed request fields: {fields_str}")
```

---

### 7. Mejorar Hints de Mapeo

#### 📝 Instrucción para procesar `mapping_hints`:

**EN `code_generator.py`, MEJORAR `_format_mapping_hints()`:**

```python
def _format_mapping_hints(self, mapping_hints: list[dict] | None) -> str:
    """Formatea los hints de mapeo para el prompt con more detail."""
    if not mapping_hints:
        return "No hay hints de mapeo disponibles."
    
    formatted = ["## 📋 MAPPING HINTS - Mapeo de Campos:\n"]
    
    # Agrupar por objeto origen y destino
    grouped = {}
    for hint in mapping_hints:
        key = (hint.get("ObjetoOrigen", ""), hint.get("ObjetoDestino", ""))
        if key not in grouped:
            grouped[key] = []
        grouped[key].append(hint)
    formatted.append(f"**Total mappings: {len(mapping_hints)}**\n")
    
    for (origen, destino), hints in grouped.items():
        formatted.append(f"### {origen} → {destino}\n")
        formatted.append("| Campo Origen | Campo Destino | Comentario |")
        formatted.append("|--------------|---------------|------------|")
        
        for h in hints:
            origen_field = h.get("campoOrigen", "")
            destino_field = h.get("campoDestino", "")
            comentario = h.get("comentario", "-")
            formatted.append(f"| `{origen_field}` | `{destino_field}` | {comentario} |")
        
        formatted.append("")  # Línea en blanco entre grupos
    
    # CRÍTICO: Agregar instrucción de uso
    formatted.append("\n**CÓMO USAR ESTOS HINTS:**")
    formatted.append("1. En el Mapper, usa `campoDestino` para el objeto de la API")
    formatted.append("2. Extrae de `campoOrigen` del objeto EJB/Request")
    formatted.append("3. Si hay comentario, presta atención a conversiones especiales")
    formatted.append("4. NO inventes nombres de campos que no estén en los hints")
    
    return "\n".join(formatted)
```

---

## 🎯 CHECKLIST PARA APLICAR MEJORAS

### Fase 1: Mejoras Críticas (Impacto Inmediato)

- [ ] **Actualizar `rmi_adapter_method.prompt`**
  - [ ] Agregar sección "INFERENCIA DE TIPOS CRÍTICA"
  - [ ] Agregar validación de imports al inicio
  - [ ] Agregar ejemplos de tipos incorrectos vs correctos

- [ ] **Actualizar `ejb_facade_method.prompt`**
  - [ ] Agregar sección "DETECCIÓN AUTOMÁTICA DEL TIPO DE RETORNO"
  - [ ] Mejorar instrucciones sobre preservación de genéricos
  - [ ] Agregar ejemplos de ArrayList vs List

- [ ] **Actualizar todos los `*_method.prompt`**
  - [ ] Agregar tabla de "IMPORTS OBLIGATORIOS" al inicio
  - [ ] Agregar mnemotécnica para recordar packages
  - [ ] Agregar sección de autovalidación

### Fase 2: Validación y Contexto

- [ ] **Agregar a `code_generator.py`**
  - [ ] Implementar `_validate_method_context()`
  - [ ] Implementar `_validate_generated_code()`
  - [ ] Implementar `_to_pascal_case()` helper
  - [ ] Integrar validaciones en generate_for_method()

- [ ] **Enriquecer contexto**
  - [ ] Leer request_code cuando existe
  - [ ] Parsear campos del Request
  - [ ] Agregar al contexto de generación

### Fase 3: Mejoras de Calidad

- [ ] **Mejorar `_format_mapping_hints()`**
  - [ ] Agrupar por objeto origen/destino
  - [ ] Tabla markdown formateada
  - [ ] Instrucciones de uso claras

- [ ] **Logging y Debugging**
  - [ ] Log cuando se detectan tipos incorrectos
  - [ ] Log cuando imports están mal
  - [ ] Guardar errores de validación para análisis

---

## 📈 MÉTRICAS DE ÉXITO

### Objetivo: Medir Mejora

Después de aplicar las mejoras, medir en próxima migración:

| Métrica | Actual | Objetivo | Medición |
|---------|--------|----------|----------|
| **Compilación directa** | 0/2 métodos | 2/2 métodos | ¿Compila sin errores al 1er intento? |
| **Tipos correctos** | 50% | 95% | ¿Usa tipos específicos, NO Object? |
| **Imports correctos** | 60% | 95% | ¿Imports en packages correctos? |
| **Tiempo de corrección** | ~20min | <5min | Tiempo de intervención manual |
| **Implementaciones completas** | 45% | 90% | ¿Genera todos los métodos en clases existentes? |

### Test Case de Validación:

**Próxima migración de método, verificar:**

1. ✅ RmiAdapter usa tipo específico (NO Object)
2. ✅ Imports de Request/Response en `domain.model`
3. ✅ Facade tiene tipo de retorno con genéricos completos
4. ✅ Compila sin errores
5. ✅ Tests pasan sin modificación

---

## 🚀 SCRIPTS DE VALIDACIÓN

### Script para Validar Mejoras Post-Generación

```bash
#!/bin/bash
# validate_generated_code.sh

echo "🔍 Validando código generado..."

ERRORS=0

# 1. Buscar imports incorrectos
echo "Checking imports..."
BAD_IMPORTS=$(grep -r "import.*infrastructure.*Request\|import.*infrastructure.*Response" src/main/java/*/infrastructure/adapter/ 2>/dev/null)
if [ ! -z "$BAD_IMPORTS" ]; then
    echo "❌ Imports incorrectos encontrados:"
    echo "$BAD_IMPORTS"
    ERRORS=$((ERRORS + 1))
fi

# 2. Buscar uso de Object en RmiAdapter
echo "Checking Object usage in RmiAdapter..."
OBJECT_USAGE=$(grep -r "Object.*ejbResponse.*=.*facade\." src/main/java/*/infrastructure/adapter/out/rmi/*Adapter.java 2>/dev/null)
if [ ! -z "$OBJECT_USAGE" ]; then
    echo "❌ Uso de Object encontrado en RmiAdapter:"
    echo "$OBJECT_USAGE"
    ERRORS=$((ERRORS + 1))
fi

# 3. Intentar compilar
echo "Compiling..."
mvn clean compile -q
if [ $? -ne 0 ]; then
    echo "❌ Compilación falló"
    ERRORS=$((ERRORS + 1))
else
    echo "✅ Compilación exitosa"
fi

# 4. Ejecutar tests
echo "Running tests..."
mvn test -q
if [ $? -ne 0 ]; then
    echo "❌ Tests fallaron"
    ERRORS=$((ERRORS + 1))
else
    echo "✅ Tests pasaron"
fi

if [ $ERRORS -eq 0 ]; then
    echo "✅ ¡Todas las validaciones pasaron!"
    exit 0
else
    echo "❌ Encontrados $ERRORS errores"
    exit 1
fi
```

---

## 📚 REFERENCIAS

- **Análisis de problemas:** Ver resumen al final de la migración de ParametrosPortalServiceLocal
- **Código del MCP:** `/data/agente/quarkus-codegen-agent/src/quarkus_codegen_agent/`
- **Prompts actuales:** `/data/agente/quarkus-codegen-agent/src/quarkus_codegen_agent/prompts/`

---

## 💡 PRÓXIMOS PASOS

1. **Aplicar mejoras a prompts** según checklist Fase 1
2. **Implementar validaciones** según checklist Fase 2
3. **Probar en nuevo método** (ej: tercer método de la misma facade)
4. **Medir métricas** y comparar con baseline
5. **Iterar** basándose en resultados

---

**Fecha de creación:** Febrero 3, 2026  
**Versión:** 1.0  
**Autor:** Análisis post-migración ParametrosPortalServiceLocal
