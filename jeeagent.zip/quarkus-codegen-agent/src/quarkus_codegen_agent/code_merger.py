"""Code merger for incrementally adding methods to existing Java classes."""

import json
import logging
import re
from pathlib import Path
from dataclasses import dataclass, field

from .import_manager import get_import_manager

LOGGER = logging.getLogger(__name__)


@dataclass
class GenerationContext:
    """Holds scanned project structure for validation."""
    existing_packages: dict[str, set[str]] = field(default_factory=dict)  # type -> package paths
    existing_dtos: set[str] = field(default_factory=set)  # DTO class names
    existing_mappers: set[str] = field(default_factory=set)  # Mapper class names
    existing_vos: set[str] = field(default_factory=set)  # VO/TO class names
    package_locations: dict[str, str] = field(default_factory=dict)  # class_name -> full package
    scanned: bool = False


class ContextScanner:
    """Scans existing project structure to build generation context."""
    
    def __init__(self, output_dir: Path, base_package: str):
        self.output_dir = output_dir
        self.base_package = base_package
        self.package_path = base_package.replace(".", "/")
    
    def scan(self) -> GenerationContext:
        """Scan output directory for existing classes and packages."""
        context = GenerationContext()
        
        src_main_java = self.output_dir / "src" / "main" / "java" / self.package_path
        if not src_main_java.exists():
            LOGGER.info("No existing project structure found at %s", src_main_java)
            context.scanned = True
            return context
        
        # Scan for DTOs in domain.model
        domain_model_path = src_main_java / "domain" / "model"
        if domain_model_path.exists():
            for java_file in domain_model_path.glob("*.java"):
                class_name = java_file.stem
                context.existing_dtos.add(class_name)
                full_package = f"{self.base_package}.domain.model"
                context.package_locations[class_name] = full_package
                context.existing_packages.setdefault("DTO", set()).add(full_package)
                
                if class_name.endswith("Request"):
                    context.existing_packages.setdefault("Request", set()).add(full_package)
                elif class_name.endswith("Response"):
                    context.existing_packages.setdefault("Response", set()).add(full_package)
        
        # Scan for Mappers in infrastructure.mapper
        mapper_path = src_main_java / "infrastructure" / "mapper"
        if mapper_path.exists():
            for java_file in mapper_path.glob("*.java"):
                class_name = java_file.stem
                context.existing_mappers.add(class_name)
                full_package = f"{self.base_package}.infrastructure.mapper"
                context.package_locations[class_name] = full_package
                context.existing_packages.setdefault("Mapper", set()).add(full_package)
        
        # Scan for VOs/TOs in infrastructure.adapter.out.rmi.model
        rmi_model_path = src_main_java / "infrastructure" / "adapter" / "out" / "rmi" / "model"
        if rmi_model_path.exists():
            for java_file in rmi_model_path.glob("*.java"):
                class_name = java_file.stem
                context.existing_vos.add(class_name)
                full_package = f"{self.base_package}.infrastructure.adapter.out.rmi.model"
                context.package_locations[class_name] = full_package
                context.existing_packages.setdefault("VO", set()).add(full_package)
                context.existing_packages.setdefault("TO", set()).add(full_package)
        
        # Scan for Services, Resources, Adapters (for completeness)
        service_path = src_main_java / "application" / "service"
        if service_path.exists():
            for java_file in service_path.glob("*.java"):
                class_name = java_file.stem
                full_package = f"{self.base_package}.application.service"
                context.package_locations[class_name] = full_package
                context.existing_packages.setdefault("Service", set()).add(full_package)
        
        context.scanned = True
        LOGGER.info("Context scan complete: %d DTOs, %d Mappers, %d VOs, %d packages",
                    len(context.existing_dtos), len(context.existing_mappers),
                    len(context.existing_vos), len(context.package_locations))
        return context
    
    def get_package_for_type(self, context: GenerationContext, class_type: str) -> str | None:
        """Get the package location for a class type based on scanned context."""
        if not context.scanned or class_type not in context.existing_packages:
            return None
        packages = context.existing_packages[class_type]
        return list(packages)[0] if packages else None


@dataclass
class ParsedJavaClass:
    """Represents a parsed Java class structure."""
    package: str
    imports: set[str]
    class_declaration: str
    class_name: str
    class_body: str
    is_interface: bool


class CodeMerger:
    """Merges new methods into existing Java classes."""
    
    def __init__(self, output_dir: str, base_package: str):
        self.output_dir = Path(output_dir)
        self.base_package = base_package
        self.package_path = base_package.replace(".", "/")
    
    def get_class_path(self, facade_name: str, component_type: str, is_test: bool = False) -> Path | None:
        """Get the path for a class file based on facade and component type."""
        if is_test:
            base_path = self.output_dir / "src" / "test" / "java" / self.package_path
        else:
            base_path = self.output_dir / "src" / "main" / "java" / self.package_path
        
        paths = {
            "use_case": base_path / "domain" / "port" / "in" / f"{facade_name}UseCase.java",
            "rmi_port": base_path / "domain" / "port" / "out" / f"{facade_name}RmiPort.java",
            "service": base_path / "application" / "service" / f"{facade_name}Service.java",
            "resource": base_path / "infrastructure" / "adapter" / "in" / "rest" / f"{facade_name}Resource.java",
            "rmi_adapter": base_path / "infrastructure" / "adapter" / "out" / "rmi" / f"{facade_name}RmiAdapter.java",
            "service_test": base_path / "application" / "service" / f"{facade_name}ServiceTest.java",
            "resource_test": base_path / "infrastructure" / "adapter" / "in" / "rest" / f"{facade_name}ResourceTest.java",
        }
        return paths.get(component_type)
    
    def class_exists(self, facade_name: str, component_type: str, is_test: bool = False) -> bool:
        """Check if a class file already exists."""
        path = self.get_class_path(facade_name, component_type, is_test)
        return path.exists() if path else False
    
    def read_existing_class(self, facade_name: str, component_type: str, is_test: bool = False) -> str | None:
        """Read the content of an existing class file."""
        path = self.get_class_path(facade_name, component_type, is_test)
        if path and path.exists():
            return path.read_text(encoding="utf-8")
        return None
    
    def parse_java_class(self, content: str) -> ParsedJavaClass | None:
        """Parse a Java class/interface into its components."""
        try:
            package_match = re.search(r'^package\s+([\w.]+);', content, re.MULTILINE)
            package = package_match.group(1) if package_match else ""
            
            imports = set(re.findall(r'^import\s+([\w.*]+);', content, re.MULTILINE))
            is_interface = bool(re.search(r'\binterface\s+\w+', content))
            
            if is_interface:
                decl_match = re.search(r'((?:@\w+(?:\([^)]*\))?\s*)*public\s+interface\s+(\w+)[^{]*)\{', content, re.DOTALL)
            else:
                decl_match = re.search(r'((?:@\w+(?:\([^)]*\))?\s*)*public\s+class\s+(\w+)[^{]*)\{', content, re.DOTALL)
            
            if not decl_match:
                return None
            
            class_declaration = decl_match.group(1).strip()
            class_name = decl_match.group(2)
            
            start_pos = content.find('{', decl_match.end() - 1)
            if start_pos == -1:
                return None
            
            brace_count = 1
            end_pos = start_pos + 1
            while end_pos < len(content) and brace_count > 0:
                if content[end_pos] == '{':
                    brace_count += 1
                elif content[end_pos] == '}':
                    brace_count -= 1
                end_pos += 1
            
            class_body = content[start_pos + 1:end_pos - 1].strip()
            
            return ParsedJavaClass(
                package=package,
                imports=imports,
                class_declaration=class_declaration,
                class_name=class_name,
                class_body=class_body,
                is_interface=is_interface,
            )
        except Exception as e:
            LOGGER.error("Error parsing Java class: %s", e)
            return None
    
    def _get_essential_imports_for_class(self, package: str) -> set[str]:
        """Get essential imports that should be present based on class package.
        
        This ensures that TOs/VOs/DTOs and other common imports are always present
        when merging new methods into existing classes.
        
        Args:
            package: The package of the class being merged into
        
        Returns:
            Set of essential import statements to add
        """
        essential = set()
        
        # Extract base package (e.g., com.davivienda.npe from com.davivienda.npe.application.service)
        parts = package.split(".")
        # Find where the layer starts (domain, application, infrastructure, test)
        layer_markers = {"domain", "application", "infrastructure", "test"}
        base_parts = []
        for part in parts:
            if part in layer_markers:
                break
            base_parts.append(part)
        
        if base_parts:
            base_package = ".".join(base_parts)
            
            # Use ImportManager for essential imports
            import_mgr = get_import_manager()
            essential.update(import_mgr.add_essential_imports_for_package(package))
        
        return essential
    
    def extract_imports_from_snippet(self, snippet: str) -> set[str]:
        """Extract import statements from a code snippet."""
        return set(re.findall(r'^import\s+([\w.*]+);', snippet, re.MULTILINE))
    
    def extract_method_from_snippet(self, snippet: str, method_name: str = None, is_interface: bool = False) -> str:
        """Extract just the method code from a snippet.
        
        Handles cases where:
        1. Snippet is just the method code
        2. Snippet is a full class with the method inside
        3. Snippet has imports, package, annotations etc.
        4. Interface methods (no body, just declaration ending with ;)
        
        Args:
            snippet: The code snippet (may be full class or just method)
            method_name: Optional method name to search for specifically
            is_interface: If True, extract interface method declaration (no body)
        
        Returns:
            Just the method code with proper indentation
        """
        # First, try to detect if this is a full class/interface
        is_full_class = re.search(r'^\s*(?:@\w+.*\s+)*public\s+(?:class|interface)\s+\w+', snippet, re.MULTILINE)
        is_interface_snippet = is_interface or bool(re.search(r'^\s*(?:@\w+.*\s+)*public\s+interface\s+\w+', snippet, re.MULTILINE))
        
        if is_full_class:
            # It's a full class/interface, extract just the method(s)
            return self._extract_methods_from_class(snippet, method_name, is_interface_snippet)
        
        # Otherwise, extract method from snippet format
        lines = snippet.split('\n')
        method_lines = []
        in_method = False
        brace_count = 0
        
        for line in lines:
            stripped = line.strip()
            
            # Skip package, imports, class declarations
            if stripped.startswith('package ') or stripped.startswith('import '):
                continue
            if stripped.startswith('// ===') or stripped.startswith('/*'):
                continue
            if re.match(r'^(?:@\w+.*\s*)*public\s+(?:class|interface)\s+', stripped):
                continue
            
            # Detect method start
            if not in_method and not stripped:
                continue
            
            # Method annotations or signature
            if any(stripped.startswith(x) for x in ['/**', '@Override', '@', 'public', 'private', 'protected']):
                in_method = True
            
            # Also catch Uni<, void, etc. that might be method returns
            if not in_method and re.match(r'^(?:Uni<|void|String|int|long|boolean|List|Map|Set|\w+(?:<[^>]+>)?)\s+\w+\s*\(', stripped):
                in_method = True
            
            if in_method:
                method_lines.append(line)
                
                # For interface methods, check if line ends with semicolon (method declaration)
                if is_interface or is_interface_snippet:
                    if stripped.endswith(';'):
                        break
                else:
                    brace_count += stripped.count('{') - stripped.count('}')
                    # If we've closed all braces after opening some, method is complete
                    if brace_count == 0 and '{' in ''.join(method_lines):
                        break
        
        return '\n'.join(method_lines).strip()
    
    def _extract_methods_from_class(self, class_content: str, method_name: str = None, is_interface: bool = False) -> str:
        """Extract method(s) from a full class definition.
        
        Args:
            class_content: Full Java class source code
            method_name: If provided, extract only this method
            is_interface: If True, extract interface method declaration (no body)
        
        Returns:
            The method code(s) extracted from the class
        """
        # Parse the class to get its body
        parsed = self.parse_java_class(class_content)
        if not parsed:
            LOGGER.warning("Could not parse class to extract methods, returning raw snippet")
            return self.extract_method_from_snippet.__wrapped__(self, class_content) if hasattr(self.extract_method_from_snippet, '__wrapped__') else ""
        
        class_body = parsed.class_body
        is_interface = is_interface or parsed.is_interface
        
        # If we have a specific method name, find just that method
        if method_name:
            if is_interface:
                # For interfaces: look for method declaration ending with ;
                pattern = rf'((?:/\*\*[\s\S]*?\*/\s*)?(?:@\w+(?:\([^)]*\))?\s*)*[\w<>,\s]+\s+{re.escape(method_name)}\s*\([^)]*\)\s*(?:throws\s+[\w,\s]+)?;)'
                match = re.search(pattern, class_body)
                if match:
                    return match.group(1).strip()
            else:
                # For classes: look for method with body
                pattern = rf'((?:/\*\*[\s\S]*?\*/\s*)?(?:@\w+(?:\([^)]*\))?\s*)*(?:public|private|protected)\s+[\w<>,\s]+\s+{re.escape(method_name)}\s*\([^)]*\)[^{{]*\{{)'
                match = re.search(pattern, class_body)
                if match:
                    start = match.start()
                    # Find the end of the method by counting braces
                    brace_count = 0
                    end = match.end() - 1  # Start after the opening brace
                    found_open = False
                    for i in range(match.end() - 1, len(class_body)):
                        if class_body[i] == '{':
                            brace_count += 1
                            found_open = True
                        elif class_body[i] == '}':
                            brace_count -= 1
                        if found_open and brace_count == 0:
                            end = i + 1
                            break
                    
                    return class_body[start:end].strip()
        
        # Otherwise, find the first method
        if is_interface:
            # For interfaces: find first method declaration
            method_pattern = r'((?:/\*\*[\s\S]*?\*/\s*)?(?:@\w+(?:\([^)]*\))?\s*)*([\w<>,\s]+)\s+(\w+)\s*\([^)]*\)\s*(?:throws\s+[\w,\s]+)?;)'
            for match in re.finditer(method_pattern, class_body):
                name = match.group(3)
                # Skip common infrastructure methods
                if name in ['lookupFacade', 'getFacade', 'resetFacade', 'lookupEjb', 'ensureFacadeConnected']:
                    continue
                if name.startswith('get') or name.startswith('set') or name.startswith('is'):
                    continue
                return match.group(1).strip()
        else:
            # For classes: find first business method
            method_pattern = r'((?:/\*\*[\s\S]*?\*/\s*)?(?:@Override\s*)?(?:@\w+(?:\([^)]*\))?\s*)*(?:public|private|protected)\s+[\w<>,\s]+\s+(\w+)\s*\([^)]*\)[^{]*\{)'
            
            for match in re.finditer(method_pattern, class_body):
                method_sig = match.group(0)
                name = match.group(2)
                
                # Skip constructors, getters, setters, and infrastructure methods
                if name in ['lookupFacade', 'getFacade', 'resetFacade', 'lookupEjb', 'ensureFacadeConnected']:
                    continue
                if name.startswith('get') or name.startswith('set') or name.startswith('is'):
                    continue
                
                # Found a business method, extract it fully
                start = match.start()
                brace_count = 0
                end = match.end()
                found_open = False
                
                for i in range(match.end() - 1, len(class_body)):
                    if class_body[i] == '{':
                        brace_count += 1
                        found_open = True
                    elif class_body[i] == '}':
                        brace_count -= 1
                    if found_open and brace_count == 0:
                        end = i + 1
                        break
                
                return class_body[start:end].strip()
        
        LOGGER.warning("Could not find method in class body")
        return ""
    
    def merge_method_into_class(self, existing_content: str, new_method_snippet: str, method_name: str) -> str:
        """Merge a new method into an existing class or interface."""
        parsed = self.parse_java_class(existing_content)
        if not parsed:
            LOGGER.error("Could not parse existing class for merge")
            return existing_content
        
        # Check if method already exists (handle both class and interface patterns)
        if parsed.is_interface:
            # For interfaces, check for method declaration with semicolon
            if re.search(rf'\b{re.escape(method_name)}\s*\([^)]*\)\s*(?:throws\s+[\w,\s]+)?;', parsed.class_body):
                LOGGER.warning("Method %s already exists in interface, skipping", method_name)
                return existing_content
        else:
            # For classes, check for method with body
            if re.search(rf'\b{re.escape(method_name)}\s*\(', parsed.class_body):
                LOGGER.warning("Method %s already exists, skipping", method_name)
                return existing_content
        
        new_imports = self.extract_imports_from_snippet(new_method_snippet)
        new_method = self.extract_method_from_snippet(new_method_snippet, method_name, is_interface=parsed.is_interface)
        
        if not new_method:
            LOGGER.error("Could not extract method %s from snippet", method_name)
            return existing_content
        
        # Add essential imports that should always be present
        essential_imports = self._get_essential_imports_for_class(parsed.package)
        all_imports = parsed.imports.union(new_imports).union(essential_imports)
        
        lines = [f"package {parsed.package};", ""]
        for imp in sorted(all_imports):
            lines.append(f"import {imp};")
        lines.append("")
        lines.append(f"{parsed.class_declaration} {{")
        lines.append("")
        lines.append(parsed.class_body)
        lines.append("")
        
        # Indent method properly (ensure 4 spaces)
        method_lines = new_method.split('\n')
        indented_lines = []
        for ml in method_lines:
            # Remove existing indentation and add consistent 4 spaces
            stripped = ml.lstrip()
            if stripped:
                indented_lines.append("    " + stripped)
            else:
                indented_lines.append("")
        
        lines.extend(indented_lines)
        lines.append("")
        lines.append("}")
        
        return '\n'.join(lines)
    
    def write_merged_class(
        self,
        facade_name: str,
        component_type: str,
        content: str,
        method_name: str,
        is_test: bool = False,
    ) -> tuple[Path, bool]:
        """Write a class file, creating new or merging into existing.
        
        Returns:
            Tuple of (path, was_merged) - was_merged is True if merged into existing
        """
        path = self.get_class_path(facade_name, component_type, is_test)
        if not path:
            raise ValueError(f"Unknown component type: {component_type}")
        
        was_merged = False
        
        if path.exists():
            existing = path.read_text(encoding="utf-8")
            new_content = self.merge_method_into_class(existing, content, method_name)
            was_merged = True
            LOGGER.info("Merged method %s into %s", method_name, path)
        else:
            new_content = content
            path.parent.mkdir(parents=True, exist_ok=True)
            LOGGER.info("Created %s with method %s", path, method_name)
        
        path.write_text(new_content, encoding="utf-8")
        return path, was_merged
    
    def write_or_merge(
        self,
        facade_name: str,
        component_type: str,
        content: str,
        method_name: str,
        is_test: bool = False,
    ) -> str | None:
        """Write a class file, creating new or merging into existing.
        
        This is the main entry point for writing mergeable components.
        
        Args:
            facade_name: Name of the facade (without 'Facade' suffix)
            component_type: Type of component (use_case, service, etc.)
            content: Full class content or method snippet
            method_name: Name of the method being added
            is_test: Whether this is a test class
        
        Returns:
            Path to the written file, or None if failed
        """
        try:
            path, was_merged = self.write_merged_class(
                facade_name, component_type, content, method_name, is_test
            )
            action = "Merged into" if was_merged else "Created"
            LOGGER.info("%s %s: %s", action, component_type, path)
            return str(path)
        except Exception as e:
            LOGGER.error("Failed to write %s for %s: %s", component_type, facade_name, e)
            return None
    
    def write_dto_file(self, relative_path: str, content: str) -> tuple[Path, bool]:
        """Write a DTO file (always separate per method).
        
        Returns:
            Tuple of (path, was_created) - was_created is False if file already exists
        """
        full_path = self.output_dir / "src" / "main" / "java" / self.package_path / relative_path
        
        if full_path.exists():
            LOGGER.warning("DTO already exists, skipping: %s", full_path)
            return full_path, False
        
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content, encoding="utf-8")
        LOGGER.info("Created DTO: %s", full_path)
        return full_path, True
    
    def write_mapper_file(self, method_name: str, content: str) -> tuple[Path, bool]:
        """Write a Mapper file (separate per method).
        
        Returns:
            Tuple of (path, was_created)
        """
        mapper_name = self._to_pascal_case(method_name) + "Mapper.java"
        full_path = self.output_dir / "src" / "main" / "java" / self.package_path / "infrastructure" / "mapper" / mapper_name
        
        if full_path.exists():
            LOGGER.warning("Mapper already exists, skipping: %s", full_path)
            return full_path, False
        
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content, encoding="utf-8")
        LOGGER.info("Created Mapper: %s", full_path)
        return full_path, True
    
    def write_openapi_json(self, facade_name: str, method_name: str, content: str) -> tuple[Path, bool]:
        """Write or merge OpenAPI JSON spec into a consolidated file per facade.
        
        Instead of creating separate files per method (e.g., Facade_method1.json, Facade_method2.json),
        this consolidates all methods into a single Facade.json file.
        
        Args:
            facade_name: Name of the facade (e.g., PreliquidacionConsulta)
            method_name: Name of the method being added
            content: OpenAPI JSON content for the new method
        
        Returns:
            Tuple of (path, was_merged) - was_merged is True if merged into existing
        """
        openapi_dir = self.output_dir / "src" / "main" / "resources" / "openapi"
        openapi_dir.mkdir(parents=True, exist_ok=True)
        
        # Consolidated file per facade
        openapi_file = openapi_dir / f"{facade_name}.json"
        
        try:
            new_spec = self._parse_openapi_json(content)
            if not new_spec:
                LOGGER.warning("Could not parse new OpenAPI spec for %s.%s", facade_name, method_name)
                # Fallback: write as separate file
                fallback_file = openapi_dir / f"{facade_name}_{method_name}.json"
                fallback_file.write_text(content, encoding="utf-8")
                return fallback_file, False
            
            if openapi_file.exists():
                # Merge into existing spec
                existing_content = openapi_file.read_text(encoding="utf-8")
                existing_spec = self._parse_openapi_json(existing_content)
                
                if existing_spec:
                    merged_spec = self._merge_openapi_specs(existing_spec, new_spec)
                    openapi_file.write_text(
                        json.dumps(merged_spec, indent=2, ensure_ascii=False),
                        encoding="utf-8"
                    )
                    LOGGER.info("Merged OpenAPI path for %s into %s", method_name, openapi_file)
                    return openapi_file, True
            
            # Create new consolidated file
            openapi_file.write_text(
                json.dumps(new_spec, indent=2, ensure_ascii=False),
                encoding="utf-8"
            )
            LOGGER.info("Created OpenAPI spec: %s", openapi_file)
            return openapi_file, False
            
        except Exception as e:
            LOGGER.error("Error writing OpenAPI spec: %s", e)
            # Fallback: write as separate file
            fallback_file = openapi_dir / f"{facade_name}_{method_name}.json"
            fallback_file.write_text(content, encoding="utf-8")
            return fallback_file, False
    
    def _parse_openapi_json(self, content: str) -> dict | None:
        """Parse OpenAPI JSON content, handling common LLM output issues.
        
        Args:
            content: Raw JSON string (may have markdown markers or prefix text)
        
        Returns:
            Parsed dict or None if invalid
        """
        try:
            # Clean up common issues from LLM output
            clean_content = content.strip()
            
            # Remove markdown code block markers
            if clean_content.startswith("```json"):
                clean_content = clean_content[7:]
            elif clean_content.startswith("```"):
                clean_content = clean_content[3:]
            if clean_content.endswith("```"):
                clean_content = clean_content[:-3]
            
            # Remove any prefix text before the JSON (e.g., "json" prefix)
            clean_content = clean_content.strip()
            if clean_content.startswith("json"):
                clean_content = clean_content[4:].strip()
            
            # Find the start of JSON object
            start_idx = clean_content.find('{')
            if start_idx > 0:
                clean_content = clean_content[start_idx:]
            
            return json.loads(clean_content)
        except json.JSONDecodeError as e:
            LOGGER.warning("Could not parse OpenAPI JSON: %s", e)
            return None
    
    def _merge_openapi_specs(self, existing: dict, new: dict) -> dict:
        """Merge two OpenAPI specs, combining paths and schemas.
        
        Args:
            existing: Existing OpenAPI spec dict
            new: New OpenAPI spec dict to merge in
        
        Returns:
            Merged OpenAPI spec
        """
        # Keep existing base structure
        merged = existing.copy()
        
        # Merge paths
        existing_paths = merged.get("paths", {})
        new_paths = new.get("paths", {})
        for path, operations in new_paths.items():
            if path not in existing_paths:
                existing_paths[path] = operations
            else:
                # Merge operations (GET, POST, etc.) for same path
                for method, operation in operations.items():
                    if method not in existing_paths[path]:
                        existing_paths[path][method] = operation
        merged["paths"] = existing_paths
        
        # Merge schemas in components
        existing_components = merged.get("components", {})
        new_components = new.get("components", {})
        
        existing_schemas = existing_components.get("schemas", {})
        new_schemas = new_components.get("schemas", {})
        for schema_name, schema in new_schemas.items():
            if schema_name not in existing_schemas:
                existing_schemas[schema_name] = schema
        
        existing_components["schemas"] = existing_schemas
        merged["components"] = existing_components
        
        return merged
    
    def get_openapi_path(self, facade_name: str) -> Path:
        """Get the path to the consolidated OpenAPI file for a facade."""
        return self.output_dir / "src" / "main" / "resources" / "openapi" / f"{facade_name}.json"
    
    def openapi_exists(self, facade_name: str) -> bool:
        """Check if OpenAPI spec exists for a facade."""
        return self.get_openapi_path(facade_name).exists()
    
    # ============================================================================
    # DTO Management - Check for existing DTOs to avoid duplication
    # ============================================================================
    
    def get_dto_path(self, class_name: str) -> Path:
        """Get the full path for a DTO class."""
        return self.output_dir / "src" / "main" / "java" / self.package_path / "domain" / "model" / f"{class_name}.java"
    
    def dto_exists(self, class_name: str) -> bool:
        """Check if a DTO class already exists.
        
        Args:
            class_name: Name of the DTO class (e.g., ConsultarMapaTRMRequest)
        
        Returns:
            True if the DTO file already exists
        """
        return self.get_dto_path(class_name).exists()
    
    def get_existing_dtos(self) -> set[str]:
        """Get all existing DTO class names in the domain/model directory.
        
        Returns:
            Set of DTO class names (without .java extension)
        """
        model_dir = self.output_dir / "src" / "main" / "java" / self.package_path / "domain" / "model"
        if not model_dir.exists():
            return set()
        
        return {f.stem for f in model_dir.glob("*.java")}
    
    def find_matching_dto(self, parameters_signature: str, existing_dtos: set[str] = None) -> str | None:
        """Try to find an existing DTO that matches the same parameter signature.
        
        This is a basic implementation that checks if a DTO with similar fields exists.
        For more accurate matching, the DTOs would need to be parsed and compared.
        
        Args:
            parameters_signature: A string representation of the parameters
            existing_dtos: Set of existing DTO names (optional, will be computed if not provided)
        
        Returns:
            Name of matching DTO if found, None otherwise
        """
        # This is a simplified version - a full implementation would parse Java classes
        # For now, return None to always create new DTOs
        # TODO: Implement full DTO comparison logic
        return None
    
    def _to_pascal_case(self, name: str) -> str:
        """Convert camelCase to PascalCase."""
        if not name:
            return name
        return name[0].upper() + name[1:]
    
    def _to_kebab_case(self, name: str) -> str:
        """Convert PascalCase to kebab-case."""
        result = []
        for i, char in enumerate(name):
            if char.isupper() and i > 0:
                result.append('-')
            result.append(char.lower())
        return ''.join(result)
    
    # ============================================================================
    # EJB Model Management - TOs/VOs/DTOs from legacy EJB
    # ============================================================================
    
    def get_ejb_model_path(self, class_name: str) -> Path:
        """Get the full path for an EJB model class (TO/VO/DTO).
        
        Args:
            class_name: Name of the EJB model class (e.g., UserTO, PeriodoClienteVO)
        
        Returns:
            Full path to the model file
        """
        return (self.output_dir / "src" / "main" / "java" / self.package_path / 
                "infrastructure" / "adapter" / "out" / "rmi" / "model" / f"{class_name}.java")
    
    def ejb_model_exists(self, class_name: str) -> bool:
        """Check if an EJB model class already exists.
        
        Args:
            class_name: Name of the EJB model class
        
        Returns:
            True if the model file already exists
        """
        return self.get_ejb_model_path(class_name).exists()
    
    def get_existing_ejb_models(self) -> set[str]:
        """Get all existing EJB model class names.
        
        Returns:
            Set of EJB model class names (without .java extension)
        """
        model_dir = (self.output_dir / "src" / "main" / "java" / self.package_path / 
                    "infrastructure" / "adapter" / "out" / "rmi" / "model")
        if not model_dir.exists():
            return set()
        
        return {f.stem for f in model_dir.glob("*.java")}
    
    def write_ejb_model(self, class_name: str, content: str) -> tuple[Path, bool]:
        """Write an EJB model file.
        
        Args:
            class_name: Name of the model class
            content: Java source code content
        
        Returns:
            Tuple of (path, was_created) - was_created is False if file already exists
        """
        full_path = self.get_ejb_model_path(class_name)
        
        if full_path.exists():
            LOGGER.warning("EJB model already exists, skipping: %s", full_path)
            return full_path, False
        
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content, encoding="utf-8")
        LOGGER.info("Created EJB model: %s", full_path)
        return full_path, True
    
    def get_ejb_facade_path(self, facade_name: str) -> Path:
        """Get the full path for an EJB Facade interface.
        
        Args:
            facade_name: Name of the facade (without 'Facade' suffix)
        
        Returns:
            Full path to the facade interface file
        """
        return (self.output_dir / "src" / "main" / "java" / self.package_path / 
                "infrastructure" / "adapter" / "out" / "rmi" / "ejb" / f"{facade_name}Facade.java")
    
    def ejb_facade_exists(self, facade_name: str) -> bool:
        """Check if an EJB Facade interface already exists.
        
        Args:
            facade_name: Name of the facade (without 'Facade' suffix)
        
        Returns:
            True if the facade interface file already exists
        """
        return self.get_ejb_facade_path(facade_name).exists()
    
    def write_ejb_facade(self, facade_name: str, content: str) -> tuple[Path, bool]:
        """Write an EJB Facade interface file.
        
        Args:
            facade_name: Name of the facade (without 'Facade' suffix)
            content: Java source code content
        
        Returns:
            Tuple of (path, was_created) - was_created is False if file already exists
        """
        full_path = self.get_ejb_facade_path(facade_name)
        
        if full_path.exists():
            LOGGER.warning("EJB Facade interface already exists, skipping: %s", full_path)
            return full_path, False
        
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content, encoding="utf-8")
        LOGGER.info("Created EJB Facade interface: %s", full_path)
        return full_path, True
    
    def write_or_merge_ejb_facade(
        self,
        facade_name: str,
        content: str,
        method_name: str,
    ) -> str | None:
        """Write or merge EJB Facade interface file.
        
        If the interface already exists, merge the new method into it.
        Otherwise, create a new interface file.
        
        Args:
            facade_name: Name of the facade (without 'Facade' suffix)
            content: Full interface content or method snippet
            method_name: Name of the method being added
        
        Returns:
            Path to the written file, or None if failed
        """
        try:
            full_path = self.get_ejb_facade_path(facade_name)
            
            if full_path.exists():
                existing = full_path.read_text(encoding="utf-8")
                new_content = self.merge_method_into_class(existing, content, method_name)
                full_path.write_text(new_content, encoding="utf-8")
                LOGGER.info("Merged method %s into EJB Facade: %s", method_name, full_path)
            else:
                full_path.parent.mkdir(parents=True, exist_ok=True)
                full_path.write_text(content, encoding="utf-8")
                LOGGER.info("Created EJB Facade interface: %s", full_path)
            
            return str(full_path)
        except Exception as e:
            LOGGER.error("Failed to write EJB Facade for %s: %s", facade_name, e)
            return None
