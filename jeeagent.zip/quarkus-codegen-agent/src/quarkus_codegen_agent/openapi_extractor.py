"""OpenAPI schema extraction from running Quarkus application."""

import json
import logging
import subprocess
import time
from pathlib import Path
from typing import Any

import httpx

LOGGER = logging.getLogger(__name__)


class OpenApiExtractor:
    """Extracts OpenAPI schema from a running Quarkus application."""
    
    def __init__(self, output_dir: Path):
        """Initialize extractor.
        
        Args:
            output_dir: Output directory containing the Quarkus project
        """
        self.output_dir = Path(output_dir)
        self.openapi_endpoint = "http://localhost:8080/q/openapi"
        self.startup_timeout = 60  # seconds
        self.shutdown_timeout = 10  # seconds
    
    def extract_and_save_openapi(self) -> tuple[bool, str]:
        """Extract OpenAPI schema from running Quarkus and save to file.
        
        Returns:
            Tuple of (success: bool, message: str)
        """
        pom_file = self.output_dir / "pom.xml"
        if not pom_file.exists():
            return False, f"No pom.xml found in {self.output_dir}"
        
        LOGGER.info("Starting Quarkus dev mode to extract OpenAPI schema...")
        
        # Start Quarkus in dev mode
        process = None
        try:
            process = subprocess.Popen(
                ["mvn", "quarkus:dev", "-DskipTests", "-Ddebug=false"],
                cwd=self.output_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
            )
            
            # Wait for Quarkus to start (look for "Listening on:" in output)
            if not self._wait_for_startup(process):
                return False, "Quarkus startup timed out or failed"
            
            LOGGER.info("Quarkus started, fetching OpenAPI schema from %s", self.openapi_endpoint)
            
            # Fetch OpenAPI schema
            schema = self._fetch_openapi_schema()
            if not schema:
                return False, "Failed to fetch OpenAPI schema from endpoint"
            
            # Save schema to file
            openapi_path = self.output_dir / "src" / "main" / "resources" / "META-INF" / "openapi.json"
            openapi_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(openapi_path, "w", encoding="utf-8") as f:
                json.dump(schema, f, indent=2, ensure_ascii=False)
            
            LOGGER.info("OpenAPI schema saved to: %s", openapi_path)
            
            # Validate schema has content
            paths_count = len(schema.get("paths", {}))
            schemas_count = len(schema.get("components", {}).get("schemas", {}))
            
            return True, f"OpenAPI schema extracted successfully ({paths_count} paths, {schemas_count} schemas)"
        
        except subprocess.SubprocessError as e:
            LOGGER.error("Failed to start Quarkus: %s", e)
            return False, f"Failed to start Quarkus: {e}"
        
        except Exception as e:
            LOGGER.error("Error extracting OpenAPI schema: %s", e)
            return False, f"Error extracting OpenAPI schema: {e}"
        
        finally:
            # Always stop Quarkus
            if process:
                self._stop_quarkus(process)
    
    def _wait_for_startup(self, process: subprocess.Popen) -> bool:
        """Wait for Quarkus to finish startup.
        
        Args:
            process: The Quarkus process
        
        Returns:
            True if started successfully, False if timeout or error
        """
        start_time = time.time()
        startup_indicators = [
            "Listening on:",
            "Profile dev activated",
            "Installed features:",
        ]
        
        LOGGER.info("Waiting for Quarkus startup (timeout: %ds)...", self.startup_timeout)
        
        while time.time() - start_time < self.startup_timeout:
            # Check if process died
            if process.poll() is not None:
                LOGGER.error("Quarkus process terminated unexpectedly")
                return False
            
            # Try to connect to the OpenAPI endpoint
            try:
                with httpx.Client(timeout=2.0) as client:
                    response = client.get(self.openapi_endpoint)
                    if response.status_code == 200:
                        LOGGER.info("Quarkus is ready (OpenAPI endpoint responding)")
                        return True
            except (httpx.ConnectError, httpx.TimeoutException):
                # Expected during startup
                pass
            
            time.sleep(2)
        
        LOGGER.error("Quarkus startup timed out after %ds", self.startup_timeout)
        return False
    
    def _fetch_openapi_schema(self) -> dict[str, Any] | None:
        """Fetch OpenAPI schema from the endpoint.
        
        Returns:
            OpenAPI schema as dict, or None if failed
        """
        try:
            with httpx.Client(timeout=10.0) as client:
                response = client.get(self.openapi_endpoint)
                response.raise_for_status()
                
                # Parse JSON response
                schema = response.json()
                
                # Validate it's a valid OpenAPI schema
                if "openapi" not in schema:
                    LOGGER.error("Invalid OpenAPI schema: missing 'openapi' field")
                    return None
                
                LOGGER.info(
                    "Fetched OpenAPI %s schema with %d paths",
                    schema.get("openapi"),
                    len(schema.get("paths", {})),
                )
                
                return schema
        
        except httpx.HTTPStatusError as e:
            LOGGER.error("HTTP error fetching OpenAPI schema: %s", e)
            return None
        
        except httpx.RequestError as e:
            LOGGER.error("Request error fetching OpenAPI schema: %s", e)
            return None
        
        except json.JSONDecodeError as e:
            LOGGER.error("Invalid JSON in OpenAPI response: %s", e)
            return None
    
    def _stop_quarkus(self, process: subprocess.Popen) -> None:
        """Stop the Quarkus process gracefully.
        
        Args:
            process: The Quarkus process to stop
        """
        LOGGER.info("Stopping Quarkus...")
        
        try:
            # Try graceful termination first
            process.terminate()
            process.wait(timeout=self.shutdown_timeout)
            LOGGER.info("Quarkus stopped gracefully")
        
        except subprocess.TimeoutExpired:
            # Force kill if graceful shutdown times out
            LOGGER.warning("Quarkus did not stop gracefully, forcing kill")
            process.kill()
            process.wait(timeout=5)
        
        except Exception as e:
            LOGGER.error("Error stopping Quarkus: %s", e)


def extract_and_save_openapi(output_dir: Path | str) -> tuple[bool, str]:
    """Convenience function to extract and save OpenAPI schema.
    
    Args:
        output_dir: Path to the Quarkus project directory
    
    Returns:
        Tuple of (success: bool, message: str)
    """
    extractor = OpenApiExtractor(output_dir)
    return extractor.extract_and_save_openapi()
