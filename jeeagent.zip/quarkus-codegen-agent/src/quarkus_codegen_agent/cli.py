"""CLI for Quarkus Codegen Agent using Typer."""

import asyncio
import logging
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from .code_generator import CodeGenerator
from .code_merger import CodeMerger
from .config import get_settings, setup_logging
from .file_writer import FileWriter
from .mcp_client import McpClient
from .models import GeneratedFile, GenerationResult
from .openapi_extractor import extract_and_save_openapi

app = typer.Typer(
    name="quarkus-gen",
    help="Generate Quarkus hexagonal code from JEE EJB contracts",
    add_completion=False,
)
console = Console()
LOGGER = logging.getLogger(__name__)


@app.callback()
def main_callback() -> None:
    """Initialize logging on startup."""
    setup_logging()


@app.command("facade")
def generate_facade(
    project_path: str = typer.Argument(..., help="Path to the JEE project"),
    interface: str = typer.Option(..., "-i", "--interface", help="Facade interface name"),
    output_dir: str = typer.Option(..., "-o", "--output", help="Output directory"),
    base_package: str = typer.Option(
        None,
        "-p",
        "--base-package",
        help="Base Java package (default: com.example.anticorruption)",
    ),
    bian: bool = typer.Option(False, "--bian", help="Generate BIAN-compliant OpenAPI"),
) -> None:
    """Generate Quarkus hexagonal code for a single EJB facade."""
    settings = get_settings()
    pkg = base_package or settings.default_base_package

    console.print(f"\n[bold blue]Generating Quarkus code for:[/] {interface}")
    console.print(f"[dim]Project:[/] {project_path}")
    console.print(f"[dim]Output:[/] {output_dir}")
    console.print(f"[dim]Package:[/] {pkg}")
    console.print(f"[dim]BIAN:[/] {'Yes' if bian else 'No'}\n")

    result = asyncio.run(_generate_facade(project_path, interface, output_dir, pkg, bian))
    _print_result(result)


@app.command("all")
def generate_all(
    project_path: str = typer.Argument(..., help="Path to the JEE project"),
    output_dir: str = typer.Option(..., "-o", "--output", help="Output directory"),
    base_package: str = typer.Option(
        None,
        "-p",
        "--base-package",
        help="Base Java package (default: com.example.anticorruption)",
    ),
    bian: bool = typer.Option(False, "--bian", help="Generate BIAN-compliant OpenAPI"),
) -> None:
    """Generate Quarkus hexagonal code for all EJB facades in a project."""
    settings = get_settings()
    pkg = base_package or settings.default_base_package

    console.print(f"\n[bold blue]Generating Quarkus code for all facades[/]")
    console.print(f"[dim]Project:[/] {project_path}")
    console.print(f"[dim]Output:[/] {output_dir}")
    console.print(f"[dim]Package:[/] {pkg}")
    console.print(f"[dim]BIAN:[/] {'Yes' if bian else 'No'}\n")

    results = asyncio.run(_generate_all(project_path, output_dir, pkg, bian))

    for result in results:
        _print_result(result)

    # Summary
    total_created = sum(len(r.files_created) for r in results)
    total_skipped = sum(len(r.files_skipped) for r in results)
    console.print(f"\n[bold green]Total: {total_created} files created, {total_skipped} skipped[/]")


@app.command("init")
def init_project(
    output_dir: str = typer.Argument(..., help="Output directory for the Quarkus project"),
    base_package: str = typer.Option(
        None,
        "-p",
        "--base-package",
        help="Base Java package (default: com.example.anticorruption)",
    ),
) -> None:
    """Initialize a Quarkus project structure with pom.xml."""
    settings = get_settings()
    pkg = base_package or settings.default_base_package

    console.print(f"\n[bold blue]Initializing Quarkus project[/]")
    console.print(f"[dim]Output:[/] {output_dir}")
    console.print(f"[dim]Package:[/] {pkg}\n")

    writer = FileWriter(output_dir, pkg)
    pom_content = _get_pom_template(pkg, settings.default_quarkus_version)

    if writer.write_pom(pom_content):
        console.print("[green]✅ Created pom.xml[/]")
    else:
        console.print("[yellow]⏭️  pom.xml already exists, skipped[/]")

    # Write test application.properties
    if writer.write_test_application_properties():
        console.print("[green]✅ Created test application.properties[/]")
    else:
        console.print("[yellow]⏭️  test application.properties already exists, skipped[/]")

    # Create directory structure
    dirs = [
        "src/main/java",
        "src/main/resources/META-INF",
        "src/test/java",
        "src/test/resources",
    ]
    for d in dirs:
        path = Path(output_dir) / d
        path.mkdir(parents=True, exist_ok=True)

    console.print("[green]✅ Created directory structure[/]")


@app.command("list")
def list_facades(
    project_path: str = typer.Argument(..., help="Path to the JEE project"),
) -> None:
    """List all EJB facades found in a project."""
    console.print(f"\n[bold blue]Scanning project:[/] {project_path}\n")

    result = asyncio.run(_scan_project(project_path))

    if not result.contracts:
        console.print("[yellow]No EJB facades found[/]")
        return

    table = Table(title="EJB Facades Found")
    table.add_column("Interface", style="cyan")
    table.add_column("Methods", justify="right", style="green")
    table.add_column("Annotation", style="dim")

    for contract in result.contracts:
        table.add_row(
            contract.interface_name,
            str(len(contract.methods)),
            contract.annotation,
        )

    console.print(table)


@app.command("method")
def generate_method(
    project_path: str = typer.Argument(..., help="Path to the JEE project"),
    interface: str = typer.Option(..., "-i", "--interface", help="Facade interface name"),
    method_name: str = typer.Option(..., "-m", "--method", help="Method name to generate"),
    output_dir: str = typer.Option(..., "-o", "--output", help="Output directory"),
    base_package: str = typer.Option(
        None,
        "-p",
        "--base-package",
        help="Base Java package (default: com.example.anticorruption)",
    ),
    no_tests: bool = typer.Option(False, "--no-tests", help="Skip generating unit tests"),
    no_openapi: bool = typer.Option(False, "--no-openapi", help="Skip generating OpenAPI JSON"),
    separate_files: bool = typer.Option(
        False,
        "--separate-files",
        help="Generate separate files per method instead of merging into existing classes",
    ),
) -> None:
    """Generate Quarkus code for a single method across ALL hexagonal layers.
    
    By default, methods are merged into existing classes (incremental mode).
    Use --separate-files to create individual files per method (legacy mode).
    """
    settings = get_settings()
    pkg = base_package or settings.default_base_package

    console.print(f"\n[bold blue]Generating complete code for method:[/] {interface}.{method_name}")
    console.print(f"[dim]Project:[/] {project_path}")
    console.print(f"[dim]Output:[/] {output_dir}")
    console.print(f"[dim]Package:[/] {pkg}")
    console.print(f"[dim]Mode:[/] {'Separate files' if separate_files else 'Incremental (merge)'}")
    console.print(f"[dim]Tests:[/] {'No' if no_tests else 'Yes'}")
    console.print(f"[dim]OpenAPI:[/] {'No' if no_openapi else 'Yes'}\n")

    result = asyncio.run(_generate_method(
        project_path, interface, method_name, output_dir, pkg,
        generate_tests=not no_tests,
        generate_openapi=not no_openapi,
        separate_files=separate_files,
    ))
    _print_result(result)


@app.command("methods")
def list_methods(
    project_path: str = typer.Argument(..., help="Path to the JEE project"),
    interface: str = typer.Option(..., "-i", "--interface", help="Facade interface name"),
) -> None:
    """List all methods in an EJB facade."""
    console.print(f"\n[bold blue]Listing methods for:[/] {interface}\n")

    result = asyncio.run(_get_methods(project_path, interface))

    if not result:
        console.print("[yellow]No methods found or facade not found[/]")
        return

    table = Table(title=f"Methods in {interface}")
    table.add_column("#", justify="right", style="dim")
    table.add_column("Method", style="cyan")
    table.add_column("Return Type", style="green")
    table.add_column("Parameters", style="yellow")

    for idx, method in enumerate(result, 1):
        params = ", ".join([f"{p.type_hint}" for p in method.parameters])
        table.add_row(
            str(idx),
            method.name,
            method.return_type,
            params[:50] + "..." if len(params) > 50 else params,
        )

    console.print(table)


@app.command("extract-openapi")
def extract_openapi_command(
    output_dir: str = typer.Argument(..., help="Path to the Quarkus project directory"),
) -> None:
    """Extract OpenAPI schema from running Quarkus application.
    
    This command:
    1. Starts Quarkus in dev mode
    2. Waits for startup
    3. Fetches OpenAPI schema from /q/openapi endpoint
    4. Saves to src/main/resources/META-INF/openapi.json
    5. Stops Quarkus
    """
    console.print(f"\n[bold blue]Extracting OpenAPI schema from:[/] {output_dir}\n")
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Starting Quarkus and extracting schema...", total=None)
        
        success, message = extract_and_save_openapi(output_dir)
        
        progress.update(task, completed=True)
    
    if success:
        console.print(f"\n[bold green]✓[/] {message}\n")
    else:
        console.print(f"\n[bold red]✗[/] {message}\n")
        raise typer.Exit(code=1)


async def _generate_method(
    project_path: str,
    interface: str,
    method_name: str,
    output_dir: str,
    base_package: str,
    generate_tests: bool = True,
    generate_openapi: bool = True,
    separate_files: bool = False,
) -> GenerationResult:
    """Generate code for a single method across ALL hexagonal layers.
    
    In incremental mode (default), methods are merged into existing class files.
    In separate_files mode, each method creates its own file.
    """
    mcp = McpClient()
    generator = CodeGenerator(base_package)
    merger = CodeMerger(output_dir, base_package)
    writer = FileWriter(output_dir, base_package)
    test_writer = FileWriter(output_dir, base_package, is_test=True)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        # Get contract
        progress.add_task("Scanning EJB contract...", total=None)
        contract = await mcp.get_contract_by_name(project_path, interface)

        if not contract:
            return GenerationResult(
                facade_name=f"{interface}.{method_name}",
                errors=[f"Contract not found: {interface}"],
            )

        # Find the specific method
        method = None
        for m in contract.methods:
            if m.name == method_name:
                method = m
                break

        if not method:
            return GenerationResult(
                facade_name=f"{interface}.{method_name}",
                errors=[f"Method not found: {method_name} in {interface}"],
            )

        # Generate code for ALL layers
        progress.add_task("Generating code for all layers...", total=None)
        facade_name = interface.replace("Facade", "")
        
        method_result = await generator.generate_for_method(
            method, facade_name, output_dir,
            generate_tests=generate_tests,
            generate_openapi=generate_openapi,
            separate_files=separate_files,
        )
        
        # Display generation decisions log
        decision_log = generator.get_decision_log()
        if decision_log:
            console.print("\n[bold cyan]📋 Generation Decisions:[/]")
            console.print("[dim]" + "=" * 60 + "[/]")
            for decision in decision_log:
                console.print(f"[dim]{decision}[/]")
            console.print("[dim]" + "=" * 60 + "[/]\n")
            generator.clear_decision_log()
        
        files_created: list[GeneratedFile] = []
        files_skipped: list[str] = []
        
        # Write DTOs (check if they already exist first)
        progress.add_task("Writing DTO files...", total=None)
        dto_files = []
        
        if method_result.request_dto:
            # Check if DTO already exists
            if merger.dto_exists(method_result.request_dto.class_name):
                console.print(f"[yellow]⏭️  Request DTO exists:[/] {method_result.request_dto.class_name}.java (reusing)")
                files_skipped.append(str(merger.get_dto_path(method_result.request_dto.class_name)))
            else:
                dto_files.append(method_result.request_dto)
        
        if method_result.response_dto:
            # Check if DTO already exists
            if merger.dto_exists(method_result.response_dto.class_name):
                console.print(f"[yellow]⏭️  Response DTO exists:[/] {method_result.response_dto.class_name}.java (reusing)")
                files_skipped.append(str(merger.get_dto_path(method_result.response_dto.class_name)))
            else:
                dto_files.append(method_result.response_dto)
        
        if dto_files:
            created, skipped = writer.write_files(dto_files)
            files_created.extend(dto_files)
        
        # Handle mergeable components
        progress.add_task("Writing hexagonal components...", total=None)
        
        # UseCase interface
        if method_result.use_case_content:
            path = merger.write_or_merge(
                facade_name, "use_case", method_result.use_case_content, method_name
            )
            if path:
                files_created.append(GeneratedFile(
                    file_path=Path(path).relative_to(output_dir),
                    package_name=f"{base_package}.domain.port.in",
                    class_name=f"{facade_name}UseCase",
                    content="",  # Already written
                    layer="domain",
                    component_type="use_case",
                ))
        
        # RmiPort interface
        if method_result.rmi_port_content:
            path = merger.write_or_merge(
                facade_name, "rmi_port", method_result.rmi_port_content, method_name
            )
            if path:
                files_created.append(GeneratedFile(
                    file_path=Path(path).relative_to(output_dir),
                    package_name=f"{base_package}.domain.port.out",
                    class_name=f"{facade_name}RmiPort",
                    content="",
                    layer="domain",
                    component_type="port",
                ))
        
        # Service implementation
        if method_result.service_content:
            path = merger.write_or_merge(
                facade_name, "service", method_result.service_content, method_name
            )
            if path:
                files_created.append(GeneratedFile(
                    file_path=Path(path).relative_to(output_dir),
                    package_name=f"{base_package}.application.service",
                    class_name=f"{facade_name}Service",
                    content="",
                    layer="application",
                    component_type="service",
                ))
        
        # Resource endpoint
        if method_result.resource_content:
            path = merger.write_or_merge(
                facade_name, "resource", method_result.resource_content, method_name
            )
            if path:
                files_created.append(GeneratedFile(
                    file_path=Path(path).relative_to(output_dir),
                    package_name=f"{base_package}.infrastructure.adapter.in.rest",
                    class_name=f"{facade_name}Resource",
                    content="",
                    layer="infrastructure",
                    component_type="resource",
                ))
        
        # RmiAdapter implementation
        if method_result.rmi_adapter_content:
            path = merger.write_or_merge(
                facade_name, "rmi_adapter", method_result.rmi_adapter_content, method_name
            )
            if path:
                files_created.append(GeneratedFile(
                    file_path=Path(path).relative_to(output_dir),
                    package_name=f"{base_package}.infrastructure.adapter.out.rmi",
                    class_name=f"{facade_name}RmiAdapter",
                    content="",
                    layer="infrastructure",
                    component_type="adapter",
                ))
        
        # Mapper (always separate file per method)
        if method_result.mapper_content:
            method_pascal = method_name[0].upper() + method_name[1:]
            mapper_file = GeneratedFile(
                file_path=Path(f"infrastructure/mapper/{method_pascal}Mapper.java"),
                package_name=f"{base_package}.infrastructure.mapper",
                class_name=f"{method_pascal}Mapper",
                content=method_result.mapper_content,
                layer="infrastructure",
                component_type="mapper",
            )
            writer.write_files([mapper_file])
            files_created.append(mapper_file)
        
        # Write tests
        if generate_tests:
            progress.add_task("Writing test files...", total=None)
            
            # ServiceTest (merged)
            if method_result.service_test_content:
                path = merger.write_or_merge(
                    facade_name, "service_test", method_result.service_test_content,
                    method_name, is_test=True
                )
                if path:
                    files_created.append(GeneratedFile(
                        file_path=Path(path).relative_to(output_dir),
                        package_name=f"{base_package}.application.service",
                        class_name=f"{facade_name}ServiceTest",
                        content="",
                        layer="test",
                        component_type="service_test",
                    ))
            
            # ResourceTest (merged)
            if method_result.resource_test_content:
                path = merger.write_or_merge(
                    facade_name, "resource_test", method_result.resource_test_content,
                    method_name, is_test=True
                )
                if path:
                    files_created.append(GeneratedFile(
                        file_path=Path(path).relative_to(output_dir),
                        package_name=f"{base_package}.infrastructure.adapter.in.rest",
                        class_name=f"{facade_name}ResourceTest",
                        content="",
                        layer="test",
                        component_type="resource_test",
                    ))
            
            # MapperTest (always separate)
            if method_result.mapper_test:
                test_writer.write_files([method_result.mapper_test])
                files_created.append(method_result.mapper_test)
        
        # Write OpenAPI JSON (consolidated per facade)
        if generate_openapi and method_result.openapi_json:
            progress.add_task("Writing OpenAPI spec...", total=None)
            openapi_path, was_merged = merger.write_openapi_json(
                facade_name, method_name, method_result.openapi_json
            )
            action = "Merged into" if was_merged else "Created"
            console.print(f"[green]✓ OpenAPI spec ({action}):[/] {openapi_path}")
        
        # Write EJB models (TOs/VOs/DTOs from legacy EJB)
        if method_result.ejb_models:
            progress.add_task("Writing EJB models...", total=None)
            for ejb_model in method_result.ejb_models:
                model_path, was_created = merger.write_ejb_model(
                    ejb_model.class_name, ejb_model.content
                )
                if was_created:
                    files_created.append(ejb_model)
                    console.print(f"[green]✓ EJB model:[/] {ejb_model.class_name}.java")
                else:
                    files_skipped.append(str(model_path))
                    console.print(f"[yellow]⏭️  EJB model exists:[/] {ejb_model.class_name}.java")
        
        # Write EJB Facade interface
        if method_result.ejb_facade_interface:
            progress.add_task("Writing EJB Facade interface...", total=None)
            facade_path, was_created = merger.write_ejb_facade(
                facade_name, method_result.ejb_facade_interface.content
            )
            if was_created:
                files_created.append(method_result.ejb_facade_interface)
                console.print(f"[green]✓ EJB Facade interface:[/] {facade_name}Facade.java")
            else:
                files_skipped.append(str(facade_path))
                console.print(f"[yellow]⏭️  EJB Facade exists:[/] {facade_name}Facade.java")
        
        # Write pom.xml if it doesn't exist
        progress.add_task("Checking pom.xml...", total=None)
        pom_path = Path(output_dir) / "pom.xml"
        if not pom_path.exists():
            settings = get_settings()
            pom_content = _get_pom_template(base_package, settings.default_quarkus_version)
            pom_path.write_text(pom_content, encoding="utf-8")
            console.print(f"[green]✓ Created pom.xml[/]")
        else:
            console.print(f"[dim]⏭️  pom.xml already exists[/]")

    # Build result
    result = GenerationResult(facade_name=f"{interface}.{method_name}")
    result.files_created = files_created
    result.files_skipped = files_skipped

    return result


async def _get_methods(project_path: str, interface: str):
    """Get all methods for a specific interface."""
    mcp = McpClient()
    contract = await mcp.get_contract_by_name(project_path, interface)
    if contract:
        return contract.methods
    return None


async def _generate_facade(
    project_path: str,
    interface: str,
    output_dir: str,
    base_package: str,
    bian: bool,
) -> GenerationResult:
    """Generate code for a single facade."""
    mcp = McpClient()
    generator = CodeGenerator(base_package)
    writer = FileWriter(output_dir, base_package)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        # Get contract
        progress.add_task("Scanning EJB contract...", total=None)
        contract = await mcp.get_contract_by_name(project_path, interface)

        if not contract:
            return GenerationResult(
                facade_name=interface,
                errors=[f"Contract not found: {interface}"],
            )

        # Generate code
        progress.add_task("Generating hexagonal code...", total=None)
        structure = await generator.generate_for_facade(contract, bian)

        # Collect all files
        files: list[GeneratedFile] = []
        if structure.use_case:
            files.append(structure.use_case)
        if structure.rmi_port:
            files.append(structure.rmi_port)
        if structure.service:
            files.append(structure.service)
        if structure.resource:
            files.append(structure.resource)
        if structure.rmi_adapter:
            files.append(structure.rmi_adapter)
        files.extend(structure.mappers)

        # Write files
        progress.add_task("Writing files...", total=None)
        created_count, skipped_count = writer.write_files(files)

        # Write pom.xml
        settings = get_settings()
        pom_content = _get_pom_template(base_package, settings.default_quarkus_version)
        writer.write_pom(pom_content)

        # Write test application.properties
        writer.write_test_application_properties()

        # Write OpenAPI if BIAN
        if bian and structure.openapi_spec:
            writer.write_openapi(structure.openapi_spec)

    # Build result
    result = GenerationResult(facade_name=interface)

    for f in files:
        full_path = writer._resolve_path(f)
        if full_path.exists() and f not in result.files_created:
            result.files_skipped.append(str(full_path))
        else:
            result.files_created.append(f)

    return result


async def _generate_all(
    project_path: str,
    output_dir: str,
    base_package: str,
    bian: bool,
) -> list[GenerationResult]:
    """Generate code for all facades in a project."""
    mcp = McpClient()
    results: list[GenerationResult] = []

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("Scanning project...", total=None)
        scan_result = await mcp.scan_project(project_path, detailed_scan=True)

    for contract in scan_result.contracts:
        result = await _generate_facade(
            project_path,
            contract.interface_name,
            output_dir,
            base_package,
            bian,
        )
        results.append(result)

    return results


async def _scan_project(project_path: str):
    """Scan project and return result."""
    mcp = McpClient()
    return await mcp.scan_project(project_path, detailed_scan=False)


def _print_result(result: GenerationResult) -> None:
    """Print generation result to console."""
    if result.errors:
        console.print(f"\n[bold red]❌ {result.facade_name}[/]")
        for err in result.errors:
            console.print(f"  [red]{err}[/]")
        return

    console.print(f"\n[bold green]✅ {result.facade_name}[/]")

    if result.files_created:
        console.print(f"  [green]Created: {len(result.files_created)} files[/]")
        for f in result.files_created:
            console.print(f"    • {f.layer}/{f.component_type}: {f.class_name}.java")

    if result.files_skipped:
        console.print(f"  [yellow]Skipped: {len(result.files_skipped)} files[/]")


def _get_pom_template(base_package: str, quarkus_version: str) -> str:
    """Get POM template content."""
    group_id = ".".join(base_package.split(".")[:3])
    artifact_id = base_package.split(".")[-1]

    return f'''<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>{group_id}</groupId>
    <artifactId>{artifact_id}</artifactId>
    <version>1.0.0-SNAPSHOT</version>
    <packaging>jar</packaging>

    <name>{artifact_id} - Anti-Corruption Layer</name>
    <description>Quarkus reactive anti-corruption layer for JEE EJB integration</description>

    <properties>
        <maven.compiler.source>21</maven.compiler.source>
        <maven.compiler.target>21</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <quarkus.platform.version>{quarkus_version}</quarkus.platform.version>
    </properties>

    <dependencyManagement>
        <dependencies>
            <dependency>
                <groupId>io.quarkus.platform</groupId>
                <artifactId>quarkus-bom</artifactId>
                <version>${{quarkus.platform.version}}</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
        </dependencies>
    </dependencyManagement>

    <dependencies>
        <!-- Quarkus REST (Reactive) -->
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-rest-jackson</artifactId>
        </dependency>

        <!-- Mutiny (Reactive) -->
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-mutiny</artifactId>
        </dependency>

        <!-- OpenAPI -->
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-smallrye-openapi</artifactId>
        </dependency>

        <!-- Health Check -->
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-smallrye-health</artifactId>
        </dependency>

        <!-- Arc (CDI) -->
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-arc</artifactId>
        </dependency>

        <!-- https://mvnrepository.com/artifact/io.quarkus/quarkus-junit5-mockito -->
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-junit5-mockito</artifactId>
            <scope>test</scope>
        </dependency>

        <!-- JEE EJB Client (for RMI) -->
        <!-- TODO: Add your specific EJB client dependency -->
        <!--
        <dependency>
            <groupId>org.wildfly</groupId>
            <artifactId>wildfly-ejb-client-bom</artifactId>
            <version>30.0.0.Final</version>
            <type>pom</type>
        </dependency>
        -->

        <!-- Testing -->
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-junit5</artifactId>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>io.rest-assured</groupId>
            <artifactId>rest-assured</artifactId>
            <scope>test</scope>
        </dependency>
        
        <!-- AssertJ for fluent assertions -->
        <dependency>
            <groupId>org.assertj</groupId>
            <artifactId>assertj-core</artifactId>
            <version>3.24.2</version>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>io.quarkus.platform</groupId>
                <artifactId>quarkus-maven-plugin</artifactId>
                <version>${{quarkus.platform.version}}</version>
                <executions>
                    <execution>
                        <goals>
                            <goal>build</goal>
                            <goal>generate-code</goal>
                        </goals>
                    </execution>
                </executions>
            </plugin>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.12.1</version>
                <configuration>
                    <compilerArgs>
                        <arg>-parameters</arg>
                    </compilerArgs>
                </configuration>
            </plugin>
        </plugins>
    </build>
</project>
'''


if __name__ == "__main__":
    app()
