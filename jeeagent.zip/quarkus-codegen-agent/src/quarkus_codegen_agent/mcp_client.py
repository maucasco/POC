"""MCP Client for consuming the JEE Interpreter MCP Server via stdio."""

import json
import logging
import subprocess
import sys
from typing import Any

from .config import get_settings
from .models import (
    DtoDefinition,
    DtoField,
    EjbContract,
    MethodParameter,
    MethodSignature,
    ProjectScanResult,
)

LOGGER = logging.getLogger(__name__)


class McpClient:
    """Client for the JEE MCP Server using stdio transport."""

    def __init__(self) -> None:
        """Initialize MCP client with settings."""
        self.settings = get_settings()
        self.server_path = self.settings.mcp_server_path
        self.python_path = self.settings.mcp_python_path
        self._process: subprocess.Popen | None = None
        self._request_id = 0

    def _start_server(self) -> subprocess.Popen:
        """Start the MCP server as a subprocess."""
        LOGGER.info("Starting MCP server from: %s", self.server_path)
        
        process = subprocess.Popen(
            [self.python_path, "-m", "src.main", "--stdio"],
            cwd=self.server_path,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )
        
        # Initialize the MCP connection
        init_id = self._send_request(process, "initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "quarkus-codegen-agent", "version": "1.0.0"}
        })
        
        # Read initialization response
        self._read_response(process, expected_id=init_id)
        
        # Send initialized notification
        self._send_notification(process, "notifications/initialized", {})
        
        return process

    def _stop_server(self) -> None:
        """Stop the MCP server subprocess."""
        if self._process:
            try:
                self._process.terminate()
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()
            finally:
                self._process = None

    def _send_request(self, process: subprocess.Popen, method: str, params: dict[str, Any]) -> int:
        """Send a JSON-RPC request to the MCP server."""
        self._request_id += 1
        request = {
            "jsonrpc": "2.0",
            "id": self._request_id,
            "method": method,
            "params": params,
        }
        
        request_json = json.dumps(request)
        LOGGER.debug("Sending request: %s", request_json)
        
        if process.stdin:
            process.stdin.write(request_json + "\n")
            process.stdin.flush()
        
        return self._request_id

    def _send_notification(self, process: subprocess.Popen, method: str, params: dict[str, Any]) -> None:
        """Send a JSON-RPC notification (no id, no response expected)."""
        notification = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
        }
        
        notification_json = json.dumps(notification)
        LOGGER.debug("Sending notification: %s", notification_json)
        
        if process.stdin:
            process.stdin.write(notification_json + "\n")
            process.stdin.flush()

    def _read_response(self, process: subprocess.Popen, expected_id: int | None = None) -> dict[str, Any]:
        """Read a JSON-RPC response from the MCP server.
        
        Args:
            process: The subprocess to read from
            expected_id: If provided, keep reading until we get a response with this id
        """
        if not process.stdout:
            raise RuntimeError("Server stdout not available")
        
        while True:
            line = process.stdout.readline()
            if not line:
                stderr = process.stderr.read() if process.stderr else ""
                raise RuntimeError(f"No response from MCP server. Stderr: {stderr}")
            
            try:
                parsed = json.loads(line.strip())
            except json.JSONDecodeError:
                continue
            
            # Handle sampling/createMessage requests from server
            if parsed.get("method") == "sampling/createMessage" and "id" in parsed:
                LOGGER. info("Received sampling request, responding with empty summary (detailed_scan not supported via stdio)")
                self._handle_sampling_request(process, parsed)
                continue
            
            # If this is a notification (no id), skip it
            if "id" not in parsed:
                continue
            
            # If we're waiting for a specific id, check it matches
            if expected_id is not None and parsed.get("id") != expected_id:
                continue
            
            # Check if it's a valid response
            if "result" not in parsed and "error" not in parsed:
                # Invalid message, continue reading
                continue
            
            return parsed
    
    def _handle_sampling_request(self, process: subprocess.Popen, request: dict) -> None:
        """Handle sampling/createMessage request from MCP server.
        
        For stdio transport, we don't have LLM access, so return empty summary.
        """
        request_id = request.get("id")
        response = {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "role": "assistant",
                "content": {
                    "type": "text",
                    "text": "Summary not available (detailed_scan via stdio requires LLM configuration)"
                }
            }
        }
        
        if process.stdin:
            process.stdin.write(json.dumps(response) + "\n")
            process.stdin.flush()

    async def scan_project(
        self,
        project_path: str,
        detailed_scan: bool = True,
    ) -> ProjectScanResult:
        """Scan a JEE project and return EJB contracts.

        Args:
            project_path: Path to the JEE project
            detailed_scan: Include manager summaries and DTO details

        Returns:
            ProjectScanResult with list of EJB contracts
        """
        LOGGER.info("Scanning project: %s (detailed=%s)", project_path, detailed_scan)
        
        process = self._start_server()
        
        try:
            # Call the scan tool
            request_id = self._send_request(process, "tools/call", {
                "name": "scan_ejb_contracts",
                "arguments": {
                    "project_path": project_path,
                    "detailed_scan": detailed_scan,
                },
            })
            
            response = self._read_response(process, expected_id=request_id)
            return self._parse_response(response, project_path)
            
        finally:
            self._stop_server()

    def _parse_response(self, response: dict[str, Any], project_path: str) -> ProjectScanResult:
        """Parse MCP response into ProjectScanResult."""
        contracts: list[EjbContract] = []
        
        if "result" in response:
            contracts = self._extract_contracts(response["result"])
        elif "error" in response:
            LOGGER.error("MCP error: %s", response["error"])
        
        return ProjectScanResult(contracts=contracts, project_path=project_path)

    def _extract_contracts(self, result: dict) -> list[EjbContract]:
        """Extract contracts from MCP result structure."""
        contracts: list[EjbContract] = []
        
        try:
            # Handle structuredContent format
            if "structuredContent" in result:
                raw_contracts = result["structuredContent"].get("contracts", [])
                for raw in raw_contracts:
                    contract = self._parse_contract(raw)
                    contracts.append(contract)
                    LOGGER.info(
                        "Found contract: %s (%d methods)",
                        contract.interface_name,
                        len(contract.methods),
                    )
                return contracts
            
            # Handle content array format
            content_list = result.get("content", [])
            for content in content_list:
                if content.get("type") == "text":
                    text_data = json.loads(content.get("text", "{}"))
                    raw_contracts = text_data.get("contracts", [])

                    for raw in raw_contracts:
                        contract = self._parse_contract(raw)
                        contracts.append(contract)
                        LOGGER.info(
                            "Found contract: %s (%d methods)",
                            contract.interface_name,
                            len(contract.methods),
                        )

        except Exception as e:
            LOGGER.error("Error extracting contracts: %s", e, exc_info=True)

        return contracts

    def _parse_contract(self, raw: dict) -> EjbContract:
        """Parse a single contract from raw MCP data."""
        methods = []
        for raw_method in raw.get("methods", []):
            params = []
            for raw_param in raw_method.get("parameters", []):
                # Parse full DTO structure if present
                dto = None
                dto_fields = None
                if raw_param.get("dto"):
                    dto = self._parse_dto(raw_param["dto"])
                    # Also extract flat dto_fields for backward compatibility
                    dto_fields = raw_param["dto"].get("fields", [])

                params.append(
                    MethodParameter(
                        name=raw_param.get("name", ""),
                        type_hint=raw_param.get("type_hint", ""),
                        dto=dto,
                        dto_fields=dto_fields,
                    )
                )

            methods.append(
                MethodSignature(
                    name=raw_method.get("name", ""),
                    return_type=raw_method.get("return_type", "void"),
                    parameters=params,
                    documentation=raw_method.get("documentation"),
                    manager_summary=raw_method.get("manager_summary"),
                )
            )

        return EjbContract(
            interface_name=raw.get("interface_name", ""),
            annotation=raw.get("annotation", "@Remote"),
            file_path=raw.get("file_path"),
            methods=methods,
            related_manager_path=raw.get("related_manager_path"),
        )

    def _parse_dto(self, raw_dto: dict) -> DtoDefinition:
        """Parse a DTO definition including nested DTOs recursively."""
        fields = []
        for raw_field in raw_dto.get("fields", []):
            # Validate type before using .get()
            if not isinstance(raw_field, dict):
                LOGGER.warning("Skipping invalid field (not a dict): %s", raw_field)
                continue
                
            nested_dto = None
            if raw_field.get("nested_dto"):
                nested_dto = self._parse_dto(raw_field["nested_dto"])
            
            fields.append(
                DtoField(
                    name=raw_field.get("name", ""),
                    type_hint=raw_field.get("type_hint", ""),
                    nested_dto=nested_dto,
                )
            )
        
        return DtoDefinition(
            name=raw_dto.get("name", ""),
            file_path=raw_dto.get("file_path"),
            fields=fields,
        )

    async def get_contract_by_name(
        self,
        project_path: str,
        interface_name: str,
    ) -> EjbContract | None:
        """Get a specific contract by interface name.

        Args:
            project_path: Path to the JEE project
            interface_name: Name of the interface to find

        Returns:
            EjbContract if found, None otherwise
        """
        # Use non-detailed scan for faster lookup
        result = await self.scan_project(project_path, detailed_scan=False)

        for contract in result.contracts:
            if contract.interface_name == interface_name:
                return contract

        LOGGER.warning("Contract not found: %s", interface_name)
        return None
