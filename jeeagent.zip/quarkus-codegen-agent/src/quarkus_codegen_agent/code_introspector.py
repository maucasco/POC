"""Code introspector for extracting metadata from generated Java classes."""

import logging
import re
from dataclasses import dataclass
from pathlib import Path

LOGGER = logging.getLogger(__name__)


@dataclass
class FieldInfo:
    """Information about a Java class field."""
    name: str
    type: str
    is_record: bool


@dataclass
class ClassInfo:
    """Information about a Java class."""
    name: str
    package: str
    is_record: bool
    fields: list[FieldInfo]


class JavaFieldIntrospector:
    """Introspects generated Java classes to extract field information."""
    
    @staticmethod
    def introspect_class(java_code: str) -> ClassInfo | None:
        """Extract class information from Java source code.
        
        Args:
            java_code: Java source code as string
            
        Returns:
            ClassInfo with extracted metadata, or None if parsing failed
        """
        try:
            # Extract package
            package_match = re.search(r'^package\s+([\w.]+);', java_code, re.MULTILINE)
            package = package_match.group(1) if package_match else ""
            
            # Detect if it's a record
            is_record = bool(re.search(r'\brecord\s+(\w+)', java_code))
            
            if is_record:
                # Extract record name and fields
                record_match = re.search(
                    r'\brecord\s+(\w+)\s*\(([^)]*)\)',
                    java_code,
                    re.DOTALL
                )
                if not record_match:
                    LOGGER.warning("Could not parse record structure")
                    return None
                
                class_name = record_match.group(1)
                params_str = record_match.group(2)
                
                fields = JavaFieldIntrospector._parse_record_fields(params_str)
                
            else:
                # Extract class name and fields from traditional class
                class_match = re.search(r'\bclass\s+(\w+)', java_code)
                if not class_match:
                    LOGGER.warning("Could not parse class name")
                    return None
                
                class_name = class_match.group(1)
                fields = JavaFieldIntrospector._parse_class_fields(java_code)
            
            return ClassInfo(
                name=class_name,
                package=package,
                is_record=is_record,
                fields=fields
            )
            
        except Exception as e:
            LOGGER.error("Failed to introspect Java class: %s", e)
            return None
    
    @staticmethod
    def _parse_record_fields(params_str: str) -> list[FieldInfo]:
        """Parse fields from record constructor parameters.
        
        Args:
            params_str: Parameter list from record declaration
            
        Returns:
            List of FieldInfo extracted from parameters
        """
        fields = []
        
        # Split by comma but be careful with generics
        param_parts = []
        current = ""
        depth = 0
        
        for char in params_str:
            if char == '<':
                depth += 1
            elif char == '>':
                depth -= 1
            elif char == ',' and depth == 0:
                param_parts.append(current.strip())
                current = ""
                continue
            current += char
        
        if current.strip():
            param_parts.append(current.strip())
        
        for param in param_parts:
            param = param.strip()
            if not param:
                continue
            
            # Remove annotations like @JsonProperty
            param = re.sub(r'@\w+(?:\([^)]*\))?\s+', '', param)
            
            # Split into type and name
            parts = param.split()
            if len(parts) >= 2:
                field_type = ' '.join(parts[:-1])  # Everything except last is type
                field_name = parts[-1]
                
                fields.append(FieldInfo(
                    name=field_name,
                    type=field_type,
                    is_record=True
                ))
        
        return fields
    
    @staticmethod
    def _parse_class_fields(java_code: str) -> list[FieldInfo]:
        """Parse fields from traditional Java class.
        
        Args:
            java_code: Java source code
            
        Returns:
            List of FieldInfo for private fields
        """
        fields = []
        
        # Match field declarations (private Type fieldName;)
        field_pattern = r'private\s+([^;]+?)\s+(\w+)\s*;'
        matches = re.findall(field_pattern, java_code)
        
        for field_type, field_name in matches:
            field_type = field_type.strip()
            fields.append(FieldInfo(
                name=field_name,
                type=field_type,
                is_record=False
            ))
        
        return fields
    
    @staticmethod
    def introspect_file(file_path: Path) -> ClassInfo | None:
        """Introspect a Java file and return class information.
        
        Args:
            file_path: Path to Java source file
            
        Returns:
            ClassInfo with extracted metadata, or None if failed
        """
        try:
            java_code = file_path.read_text(encoding='utf-8')
            return JavaFieldIntrospector.introspect_class(java_code)
        except Exception as e:
            LOGGER.error("Failed to read/introspect file %s: %s", file_path, e)
            return None
    
    @staticmethod
    def get_field_names(java_code: str) -> list[str]:
        """Quick method to just get field names from Java code.
        
        Args:
            java_code: Java source code
            
        Returns:
            List of field names
        """
        class_info = JavaFieldIntrospector.introspect_class(java_code)
        if class_info:
            return [field.name for field in class_info.fields]
        return []
