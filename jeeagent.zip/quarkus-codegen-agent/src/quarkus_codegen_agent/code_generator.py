"""Code generator using LLM to create Quarkus hexagonal components."""

import json
import logging
import re
from pathlib import Path
from typing import Any

import anthropic
import openai

from .config import get_settings
from .code_merger import CodeMerger, GenerationContext
from .models import (
    EjbContract,
    GeneratedFile,
    GenerationResult,
    HexagonalStructure,
    MethodSignature,
)

LOGGER = logging.getLogger(__name__)


class MethodGenerationResult:
    """Result of generating code for a single method across all layers."""

    def __init__(self, method_name: str, facade_name: str):
        self.method_name = method_name
        self.facade_name = facade_name
        # Core hexagonal components (content strings for merging)
        self.use_case_content: str | None = None
        self.rmi_port_content: str | None = None
        self.service_content: str | None = None
        self.resource_content: str | None = None
        self.rmi_adapter_content: str | None = None
        self.mapper_content: str | None = None
        # Independent DTOs (GeneratedFile for separate files)
        self.request_dto: GeneratedFile | None = None
        self.response_dto: GeneratedFile | None = None
        # EJB Models - TOs/VOs/DTOs from legacy EJB
        self.ejb_models: list[GeneratedFile] = []
        self.ejb_facade_interface: GeneratedFile | None = None
        # Tests (content strings for merging)
        self.service_test_content: str | None = None
        self.resource_test_content: str | None = None
        self.mapper_test: GeneratedFile | None = None  # Separate per method
        # OpenAPI JSON
        self.openapi_json: str | None = None


class CodeGenerator:
    """Generates Quarkus code from EJB contracts using LLM."""

    def __init__(self, base_package: str) -> None:
        """Initialize code generator.

        Args:
            base_package: Base Java package for generated code
        """
        self.settings = get_settings()
        self.base_package = base_package
        self._prompts_cache: dict[str, str] = {}
        self._decision_log: list[str] = []  # Log de decisiones para debugging

    async def generate_for_method(
        self,
        method: MethodSignature,
        facade_name: str,
        output_dir: str,
        generate_tests: bool = True,
        generate_openapi: bool = True,
        separate_files: bool = False,
        skip_existing_dtos: bool = True,
        mapping_hints: list[dict] | None = None,
        generation_hints: str | None = None,
    ) -> MethodGenerationResult:
        """Generate complete hexagonal code for a single method.

        Generates content for merging into existing classes or creates new ones:
        - Request/Response DTOs (always separate files per method, skipped if exist)
        - UseCase interface (merged into {facade_name}UseCase.java)
        - RmiPort interface (merged into {facade_name}RmiPort.java)
        - Service implementation (merged into {facade_name}Service.java)
        - Resource endpoint (merged into {facade_name}Resource.java)
        - RmiAdapter implementation (merged into {facade_name}RmiAdapter.java)
        - Mapper class (separate file per method)
        - Unit tests (merged into test classes)
        - OpenAPI JSON spec (consolidated per facade)

        Args:
            method: Method signature to generate code for
            facade_name: Name of the facade (without 'Facade' suffix)
            output_dir: Output directory for generated code
            generate_tests: Generate unit tests for the components
            generate_openapi: Generate OpenAPI JSON spec
            separate_files: If True, create separate files per method (legacy mode)
            skip_existing_dtos: Skip DTO generation if they already exist (saves LLM calls)
            mapping_hints: Optional list of field mapping hints from CSV
            generation_hints: Optional user instructions for code generation

        Returns:
            MethodGenerationResult with all generated content
        """
        LOGGER.info("Generating hexagonal code for method: %s.%s", facade_name, method.name)
        result = MethodGenerationResult(method.name, facade_name)
        
        # Store generation hints for this session
        self._current_generation_hints = generation_hints
        
        merger = CodeMerger(output_dir, self.base_package)
        method_pascal = self._to_pascal_case(method.name)

        # 0. Generate independent DTOs (skip if they already exist)
        request_dto_name = f"{method_pascal}Request"
        response_dto_name = f"{method_pascal}Response"
        
        if skip_existing_dtos and merger.dto_exists(request_dto_name):
            LOGGER.info("Request DTO %s already exists, skipping generation", request_dto_name)
            result.request_dto = None
        else:
            result.request_dto = await self._generate_request_dto(method, facade_name)
        
        if skip_existing_dtos and merger.dto_exists(response_dto_name):
            LOGGER.info("Response DTO %s already exists, skipping generation", response_dto_name)
            result.response_dto = None
        else:
            result.response_dto = await self._generate_response_dto(method, facade_name)

        # Context enrichment: Read Request code if exists for better type inference
        context_vars = {}
        if method.parameters and len(method.parameters) > 0:
            # Intentar leer el código del Request si ya existe
            request_name = f"{method_pascal}Request"
            output_path = Path(output_dir) if isinstance(output_dir, str) else output_dir
            request_path = output_path / "src" / "main" / "java" / self.base_package.replace('.', '/') / "domain" / "model" / f"{request_name}.java"
            
            if request_path.exists():
                request_code = request_path.read_text()
                context_vars["request_code"] = request_code
                LOGGER.info(f"Added request_code to context for {method.name}")
                
                # Extraer campos del Request record
                fields_match = re.search(r'record\s+\w+\s*\((.*?)\)', request_code, re.DOTALL)
                if fields_match:
                    fields_str = fields_match.group(1)
                    # Parsear campos: "String campo1, Integer campo2"
                    context_vars["request_fields_parsed"] = fields_str
                    LOGGER.info(f"Parsed request fields: {fields_str}")

        # Pre-validation: Check method context before generating components
        validation_context = self._validate_method_context(method, existing_class_code=None)
        if validation_context.get("warnings"):
            for warning in validation_context["warnings"]:
                LOGGER.warning("Context validation: %s", warning)

        # Check if classes exist to determine if we generate full class or just method
        use_case_exists = merger.class_exists(facade_name, "use_case")
        rmi_port_exists = merger.class_exists(facade_name, "rmi_port")
        service_exists = merger.class_exists(facade_name, "service")
        resource_exists = merger.class_exists(facade_name, "resource")
        rmi_adapter_exists = merger.class_exists(facade_name, "rmi_adapter")

        # 1. UseCase content
        if use_case_exists and not separate_files:
            result.use_case_content = await self._generate_use_case_method_only(method, facade_name)
        else:
            result.use_case_content = await self._generate_use_case_full(method, facade_name)
        
        # Validate UseCase
        is_valid, errors = self._validate_generated_code(result.use_case_content, "use_case", method.name)
        if not is_valid:
            LOGGER.warning("UseCase validation failed: %s", errors)

        # 2. RmiPort content
        if rmi_port_exists and not separate_files:
            result.rmi_port_content = await self._generate_rmi_port_method_only(method, facade_name)
        else:
            result.rmi_port_content = await self._generate_rmi_port_full(method, facade_name)
        
        # Validate RmiPort
        is_valid, errors = self._validate_generated_code(result.rmi_port_content, "rmi_port", method.name)
        if not is_valid:
            LOGGER.warning("RmiPort validation failed: %s", errors)

        # 3. Service content
        if service_exists and not separate_files:
            result.service_content = await self._generate_service_method_only(method, facade_name)
        else:
            result.service_content = await self._generate_service_full(method, facade_name)
        
        # Validate Service
        is_valid, errors = self._validate_generated_code(result.service_content, "service", method.name)
        if not is_valid:
            LOGGER.warning("Service validation failed: %s", errors)

        # 4. Resource content
        if resource_exists and not separate_files:
            result.resource_content = await self._generate_resource_method_only(method, facade_name)
        else:
            result.resource_content = await self._generate_resource_full(method, facade_name)
        
        # Validate Resource
        is_valid, errors = self._validate_generated_code(result.resource_content, "resource", method.name)
        if not is_valid:
            LOGGER.warning("Resource validation failed: %s", errors)

        # Get request_code for consistency across RmiAdapter and Mapper
        request_code = result.request_dto if result.request_dto else ""

        # 5. RmiAdapter content - pass request_code for field consistency
        if rmi_adapter_exists and not separate_files:
            result.rmi_adapter_content = await self._generate_rmi_adapter_method_only(method, facade_name, request_code)
        else:
            result.rmi_adapter_content = await self._generate_rmi_adapter_full(method, facade_name, request_code)
        
        # Validate RmiAdapter
        is_valid, errors = self._validate_generated_code(result.rmi_adapter_content, "rmi_adapter", method.name)
        if not is_valid:
            LOGGER.warning("RmiAdapter validation failed: %s", errors)
        if rmi_adapter_exists and not separate_files:
            result.rmi_adapter_content = await self._generate_rmi_adapter_method_only(method, facade_name, request_code)
        else:
            result.rmi_adapter_content = await self._generate_rmi_adapter_full(method, facade_name, request_code)

        # 6. Mapper class (always separate per method) - pass request code and mapping hints
        mapper_file = await self._generate_mapper(method, facade_name, request_code, mapping_hints)
        result.mapper_content = mapper_file.content if mapper_file else None

        # 7. Generate tests if requested
        if generate_tests:
            service_test_exists = merger.class_exists(facade_name, "service_test", is_test=True)
            resource_test_exists = merger.class_exists(facade_name, "resource_test", is_test=True)
            
            if service_test_exists and not separate_files:
                result.service_test_content = await self._generate_service_test_method_only(method, facade_name)
            else:
                result.service_test_content = await self._generate_service_test_full(method, facade_name)
            
            if resource_test_exists and not separate_files:
                result.resource_test_content = await self._generate_resource_test_method_only(method, facade_name)
            else:
                result.resource_test_content = await self._generate_resource_test_full(method, facade_name)
            
            # Mapper test is always separate
            result.mapper_test = await self._generate_mapper_test(method, facade_name)

        # 8. OpenAPI JSON spec
        if generate_openapi:
            result.openapi_json = await self._generate_openapi_json(method, facade_name)

        # 9. Generate EJB models (TOs/VOs/DTOs) and Facade interface
        result.ejb_models = await self._generate_ejb_models(method, facade_name, merger)
        result.ejb_facade_interface = await self._generate_ejb_facade_interface(method, facade_name, merger)

        return result

    async def _generate_use_case_full(self, method: MethodSignature, facade_name: str) -> str:
        """Generate full UseCase interface with first method."""
        prompt = self._load_prompt("use_case_full")
        return await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}UseCase",
            base_package=self.base_package,
        )

    async def _generate_use_case_method_only(self, method: MethodSignature, facade_name: str) -> str:
        """Generate only the method snippet to add to existing UseCase."""
        prompt = self._load_prompt("use_case_method")
        return await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}UseCase",
            base_package=self.base_package,
        )

    async def _generate_rmi_port_full(self, method: MethodSignature, facade_name: str) -> str:
        """Generate full RmiPort interface with first method."""
        prompt = self._load_prompt("rmi_port_full")
        return await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}RmiPort",
            base_package=self.base_package,
        )

    async def _generate_rmi_port_method_only(self, method: MethodSignature, facade_name: str) -> str:
        """Generate only the method snippet to add to existing RmiPort."""
        prompt = self._load_prompt("rmi_port_method")
        return await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}RmiPort",
            base_package=self.base_package,
        )

    async def _generate_service_full(self, method: MethodSignature, facade_name: str) -> str:
        """Generate full Service class with first method."""
        prompt = self._load_prompt("service_full")
        return await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}Service",
            base_package=self.base_package,
        )

    async def _generate_service_method_only(self, method: MethodSignature, facade_name: str) -> str:
        """Generate only the method snippet to add to existing Service."""
        prompt = self._load_prompt("service_method")
        return await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}Service",
            base_package=self.base_package,
        )

    async def _generate_resource_full(self, method: MethodSignature, facade_name: str) -> str:
        """Generate full Resource class with first method."""
        prompt = self._load_prompt("resource_full")
        return await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}Resource",
            base_package=self.base_package,
        )

    async def _generate_resource_method_only(self, method: MethodSignature, facade_name: str) -> str:
        """Generate only the method snippet to add to existing Resource."""
        prompt = self._load_prompt("resource_method")
        return await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}Resource",
            base_package=self.base_package,
        )

    async def _generate_rmi_adapter_full(self, method: MethodSignature, facade_name: str, request_code: str = "") -> str:
        """Generate full RmiAdapter class with first method."""
        prompt = self._load_prompt("rmi_adapter_full")
        return await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}RmiAdapter",
            base_package=self.base_package,
            request_code=request_code,
        )

    async def _generate_rmi_adapter_method_only(self, method: MethodSignature, facade_name: str, request_code: str = "") -> str:
        """Generate only the method snippet to add to existing RmiAdapter."""
        prompt = self._load_prompt("rmi_adapter_method")
        return await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}RmiAdapter",
            base_package=self.base_package,
            request_code=request_code,
        )

    async def _generate_service_test_full(self, method: MethodSignature, facade_name: str) -> str:
        """Generate full ServiceTest class with first test methods."""
        prompt = self._load_prompt("service_test_full")
        return await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}ServiceTest",
            base_package=self.base_package,
        )

    async def _generate_service_test_method_only(self, method: MethodSignature, facade_name: str) -> str:
        """Generate only test methods to add to existing ServiceTest."""
        prompt = self._load_prompt("service_test_method")
        return await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}ServiceTest",
            base_package=self.base_package,
        )

    async def _generate_resource_test_full(self, method: MethodSignature, facade_name: str) -> str:
        """Generate full ResourceTest class with first test methods."""
        prompt = self._load_prompt("resource_test_full")
        return await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}ResourceTest",
            base_package=self.base_package,
        )

    async def _generate_resource_test_method_only(self, method: MethodSignature, facade_name: str) -> str:
        """Generate only test methods to add to existing ResourceTest."""
        prompt = self._load_prompt("resource_test_method")
        return await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}ResourceTest",
            base_package=self.base_package,
        )

    async def _generate_openapi_json(self, method: MethodSignature, facade_name: str) -> str:
        """Generate OpenAPI JSON specification for the method."""
        prompt = self._load_prompt("openapi_json")
        return await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            base_package=self.base_package,
        )

    def _extract_ejb_types(self, method: MethodSignature) -> set[str]:
        """Extract EJB model types (TO/VO/DTO) from method signature AND DTO fields.
        
        Args:
            method: Method signature to analyze
            
        Returns:
            Set of type names that need to be generated as EJB models
        """
        ejb_types = set()
        
        # Common EJB type suffixes
        ejb_suffixes = ('TO', 'VO', 'DTO')
        
        # Check return type
        return_type = method.return_type
        # Extract types from generics like HashMap<String, ArrayList<SomeTO>>
        self._extract_types_from_generic(return_type, ejb_types, ejb_suffixes)
        
        # Check parameter types AND their DTO fields
        for param in method.parameters:
            self._extract_types_from_generic(param.type_hint, ejb_types, ejb_suffixes)
            
            # Also extract from DTO fields (the actual fields inside the parameter DTO)
            if param.dto:
                self._extract_types_from_dto(param.dto, ejb_types, ejb_suffixes)
            elif param.dto_fields:
                for field in param.dto_fields:
                    # Validate type before using .get()
                    if not isinstance(field, dict):
                        LOGGER.warning("Skipping invalid field (not a dict): %s", field)
                        continue
                        
                    field_type = field.get("type_hint", "")
                    self._extract_types_from_generic(field_type, ejb_types, ejb_suffixes)
        
        return ejb_types
    
    def _extract_types_from_dto(self, dto, types_set: set[str], suffixes: tuple[str, ...]) -> None:
        """Recursively extract EJB types from a DtoDefinition.
        
        Args:
            dto: DtoDefinition with fields
            types_set: Set to add found types to
            suffixes: Tuple of suffixes to match (TO, VO, DTO)
        """
        for field in dto.fields:
            self._extract_types_from_generic(field.type_hint, types_set, suffixes)
            # Recurse into nested DTOs
            if field.nested_dto:
                self._extract_types_from_dto(field.nested_dto, types_set, suffixes)
    
    def _extract_types_from_generic(self, type_str: str, types_set: set[str], suffixes: tuple[str, ...]) -> None:
        """Extract type names from a potentially generic type string.
        
        Args:
            type_str: Type string like "HashMap<String, ArrayList<UserTO>>"
            types_set: Set to add found types to
            suffixes: Tuple of suffixes to match (TO, VO, DTO)
        """
        import re
        # Find all word tokens that could be type names
        tokens = re.findall(r'\b([A-Z][a-zA-Z0-9]*)\b', type_str)
        
        for token in tokens:
            # Check if it ends with any of the EJB suffixes
            if any(token.endswith(suffix) for suffix in suffixes):
                types_set.add(token)
    
    def _collect_dto_fields_map(self, method: MethodSignature) -> dict[str, list[dict]]:
        """Collect all DTO fields from method parameters into a map.
        
        Creates a mapping from DTO type name to its fields, traversing
        nested DTOs recursively.
        
        Args:
            method: Method signature with parameters containing DTOs
            
        Returns:
            Dict mapping type name -> list of field dicts
        """
        fields_map: dict[str, list[dict]] = {}
        
        for param in method.parameters:
            # Get the parameter's own type (if it's a DTO)
            param_type = param.type_hint.split("<")[0].replace("[]", "")
            
            # Collect fields from dto structure
            if param.dto:
                self._collect_fields_recursive(param.dto, fields_map)
            
            # Also use dto_fields if available (may have more complete info)
            if param.dto_fields and param_type not in fields_map:
                fields_map[param_type] = param.dto_fields
                # Also extract nested types from dto_fields
                for field in param.dto_fields:
                    # Validate type before using .get()
                    if not isinstance(field, dict):
                        LOGGER.warning("Skipping invalid field (not a dict): %s", field)
                        continue
                        
                    nested = field.get("nested_dto")
                    if nested and isinstance(nested, dict):
                        nested_name = nested.get("name", "")
                        nested_fields = nested.get("fields", [])
                        if nested_name and nested_fields:
                            fields_map[nested_name] = nested_fields
        
        return fields_map
    
    def _collect_fields_recursive(self, dto, fields_map: dict[str, list[dict]]) -> None:
        """Recursively collect fields from a DtoDefinition into the map.
        
        Args:
            dto: DtoDefinition object
            fields_map: Dict to populate with type_name -> fields
        """
        if dto is None:
            return
        
        # Add this DTO's fields to the map
        if dto.name and dto.fields:
            fields_map[dto.name] = [
                {
                    "name": f.name,
                    "type_hint": f.type_hint,
                    "nested_dto": self._dto_to_dict(f.nested_dto) if f.nested_dto else None
                }
                for f in dto.fields
            ]
            
            # Recurse into nested DTOs
            for field in dto.fields:
                if field.nested_dto:
                    self._collect_fields_recursive(field.nested_dto, fields_map)
    
    def _dto_to_dict(self, dto) -> dict | None:
        """Convert a DtoDefinition to a dict."""
        if dto is None:
            return None
        return {
            "name": dto.name,
            "fields": [
                {"name": f.name, "type_hint": f.type_hint}
                for f in dto.fields
            ] if dto.fields else []
        }
    
    def _format_fields_for_prompt(self, fields: list[dict]) -> str:
        """Format DTO fields as a string for the LLM prompt.
        
        Args:
            fields: List of field dicts with name, type_hint
            
        Returns:
            Formatted string with field list
        """
        if not fields:
            return "No fields available - infer from type name"
        
        lines = []
        for field in fields:
            # Validate type before using .get()
            if not isinstance(field, dict):
                LOGGER.warning("Skipping invalid field (not a dict): %s", field)
                continue
                
            field_name = field.get("name", "")
            field_type = field.get("type_hint", "Object")
            lines.append(f"- {field_type} {field_name}")
        
        return "\n".join(lines)

    async def _generate_ejb_models(
        self, 
        method: MethodSignature, 
        facade_name: str,
        merger: 'CodeMerger'
    ) -> list[GeneratedFile]:
        """Generate EJB model classes (TOs/VOs/DTOs) for the method.
        
        Args:
            method: Method signature containing EJB types
            facade_name: Name of the facade
            merger: CodeMerger to check for existing files
            
        Returns:
            List of generated model files
        """
        ejb_types = self._extract_ejb_types(method)
        generated_models = []
        
        # Collect real DTO fields from method parameters
        dto_fields_map = self._collect_dto_fields_map(method)
        LOGGER.info("Collected DTO fields for types: %s", list(dto_fields_map.keys()))
        
        for type_name in ejb_types:
            # Check if model already exists
            model_path = merger.get_ejb_model_path(type_name)
            if model_path.exists():
                LOGGER.info("EJB model %s already exists, skipping", type_name)
                continue
            
            # Get real fields for this type (if available)
            real_fields = dto_fields_map.get(type_name, [])
            fields_str = self._format_fields_for_prompt(real_fields)
            
            LOGGER.info("Generating EJB model: %s with %d real fields", type_name, len(real_fields))
            
            # Generate the model with real fields
            prompt = self._load_prompt("ejb_model")
            
            code = await self._call_llm(
                prompt,
                class_name=type_name,
                base_package=self.base_package,
                description=f"Model type used by {facade_name}Facade.{method.name}",
                real_fields=fields_str,
                has_real_fields="true" if real_fields else "false",
            )
            
            generated_models.append(GeneratedFile(
                file_path=Path(f"infrastructure/adapter/out/rmi/model/{type_name}.java"),
                package_name=f"{self.base_package}.infrastructure.adapter.out.rmi.model",
                class_name=type_name,
                content=code,
                layer="infrastructure",
                component_type="model",
            ))
        
        return generated_models
    
    async def _generate_ejb_facade_interface(
        self,
        method: MethodSignature,
        facade_name: str,
        merger: 'CodeMerger'
    ) -> GeneratedFile | None:
        """Generate or update the EJB Facade interface.
        
        If interface exists, generates only the method declaration for merge.
        Otherwise, generates full interface.
        
        Args:
            method: Method signature to add to the interface
            facade_name: Name of the facade
            merger: CodeMerger to check for existing files
            
        Returns:
            Generated facade interface file (full or method-only)
        """
        interface_name = f"{facade_name}Facade"
        interface_path = merger.get_ejb_facade_path(facade_name)
        
        if interface_path.exists():
            # Generate only the method declaration for merge
            LOGGER.info("EJB Facade interface %s exists, generating method for merge", interface_name)
            prompt = self._load_prompt("ejb_facade_method")
            code = await self._call_llm(
                prompt,
                method=method,
                facade_name=facade_name,
                class_name=interface_name,
                base_package=self.base_package,
            )
        else:
            # Generate full interface
            LOGGER.info("Generating full EJB Facade interface: %s", interface_name)
            prompt = self._load_prompt("ejb_facade_interface")
            code = await self._call_llm(
                prompt,
                method=method,
                facade_name=facade_name,
                class_name=interface_name,
                base_package=self.base_package,
            )
        
        return GeneratedFile(
            file_path=Path(f"infrastructure/adapter/out/rmi/ejb/{interface_name}.java"),
            package_name=f"{self.base_package}.infrastructure.adapter.out.rmi.ejb",
            class_name=interface_name,
            content=code,
            layer="infrastructure",
            component_type="adapter",
        )

    async def _generate_request_dto(
        self, method: MethodSignature, facade_name: str
    ) -> GeneratedFile:
        """Generate independent Request DTO class."""
        method_pascal = self._to_pascal_case(method.name)
        class_name = f"{method_pascal}Request"
        prompt = self._load_prompt("request_dto")

        code = await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=class_name,
            base_package=self.base_package,
        )

        return GeneratedFile(
            file_path=Path(f"domain/model/{class_name}.java"),
            package_name=f"{self.base_package}.domain.model",
            class_name=class_name,
            content=code,
            layer="domain",
            component_type="model",
        )

    async def _generate_response_dto(
        self, method: MethodSignature, facade_name: str
    ) -> GeneratedFile:
        """Generate independent Response DTO class."""
        method_pascal = self._to_pascal_case(method.name)
        class_name = f"{method_pascal}Response"
        prompt = self._load_prompt("response_dto")

        code = await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=class_name,
            base_package=self.base_package,
        )

        return GeneratedFile(
            file_path=Path(f"domain/model/{class_name}.java"),
            package_name=f"{self.base_package}.domain.model",
            class_name=class_name,
            content=code,
            layer="domain",
            component_type="model",
        )

    async def _generate_service_test(
        self, method: MethodSignature, facade_name: str
    ) -> GeneratedFile:
        """Generate Service unit test."""
        method_pascal = self._to_pascal_case(method.name)
        class_name = f"{facade_name}Service{method_pascal}Test"
        prompt = self._load_prompt("service_test")

        code = await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=class_name,
            base_package=self.base_package,
        )

        return GeneratedFile(
            file_path=Path(f"application/service/{class_name}.java"),
            package_name=f"{self.base_package}.application.service",
            class_name=class_name,
            content=code,
            layer="application",
            component_type="service",
        )

    async def _generate_mapper_test(
        self, method: MethodSignature, facade_name: str
    ) -> GeneratedFile:
        """Generate Mapper unit test."""
        method_pascal = self._to_pascal_case(method.name)
        class_name = f"{method_pascal}MapperTest"
        prompt = self._load_prompt("mapper_test")

        code = await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=class_name,
            base_package=self.base_package,
        )

        return GeneratedFile(
            file_path=Path(f"infrastructure/mapper/{class_name}.java"),
            package_name=f"{self.base_package}.infrastructure.mapper",
            class_name=class_name,
            content=code,
            layer="test",
            component_type="mapper_test",
        )

    async def _generate_resource_test(
        self, method: MethodSignature, facade_name: str
    ) -> GeneratedFile:
        """Generate Resource integration test."""
        method_pascal = self._to_pascal_case(method.name)
        class_name = f"{facade_name}Resource{method_pascal}Test"
        prompt = self._load_prompt("resource_test")

        code = await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=class_name,
            base_package=self.base_package,
        )

        return GeneratedFile(
            file_path=Path(f"infrastructure/adapter/in/rest/{class_name}.java"),
            package_name=f"{self.base_package}.infrastructure.adapter.in.rest",
            class_name=class_name,
            content=code,
            layer="infrastructure",
            component_type="resource",
        )

    async def _generate_use_case_method(
        self, method: MethodSignature, facade_name: str
    ) -> GeneratedFile:
        """Generate UseCase interface method snippet."""
        class_name = f"{facade_name}UseCase_{method.name}"
        prompt = self._load_prompt("use_case_method")

        code = await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}UseCase",
            base_package=self.base_package,
        )

        return GeneratedFile(
            file_path=Path(f"domain/port/in/{class_name}.java"),
            package_name=f"{self.base_package}.domain.port.in",
            class_name=class_name,
            content=code,
            layer="domain",
            component_type="use_case",
        )

    async def _generate_rmi_port_method(
        self, method: MethodSignature, facade_name: str
    ) -> GeneratedFile:
        """Generate RmiPort interface method snippet."""
        class_name = f"{facade_name}RmiPort_{method.name}"
        prompt = self._load_prompt("rmi_port_method")

        code = await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}RmiPort",
            base_package=self.base_package,
        )

        return GeneratedFile(
            file_path=Path(f"domain/port/out/{class_name}.java"),
            package_name=f"{self.base_package}.domain.port.out",
            class_name=class_name,
            content=code,
            layer="domain",
            component_type="port",
        )

    async def _generate_service_method(
        self, method: MethodSignature, facade_name: str
    ) -> GeneratedFile:
        """Generate Service method implementation snippet."""
        class_name = f"{facade_name}Service_{method.name}"
        prompt = self._load_prompt("service_method")

        code = await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}Service",
            base_package=self.base_package,
        )

        return GeneratedFile(
            file_path=Path(f"application/service/{class_name}.java"),
            package_name=f"{self.base_package}.application.service",
            class_name=class_name,
            content=code,
            layer="application",
            component_type="service",
        )

    async def _generate_resource_endpoint(
        self, method: MethodSignature, facade_name: str
    ) -> GeneratedFile:
        """Generate Resource endpoint snippet."""
        class_name = f"{facade_name}Resource_{method.name}"
        prompt = self._load_prompt("resource_method")

        code = await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}Resource",
            base_package=self.base_package,
        )

        return GeneratedFile(
            file_path=Path(f"infrastructure/adapter/in/rest/{class_name}.java"),
            package_name=f"{self.base_package}.infrastructure.adapter.in.rest",
            class_name=class_name,
            content=code,
            layer="infrastructure",
            component_type="resource",
        )

    async def _generate_rmi_adapter_method(
        self, method: MethodSignature, facade_name: str
    ) -> GeneratedFile:
        """Generate RmiAdapter method implementation snippet."""
        class_name = f"{facade_name}RmiAdapter_{method.name}"
        prompt = self._load_prompt("rmi_adapter_method")

        code = await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=f"{facade_name}RmiAdapter",
            base_package=self.base_package,
        )

        return GeneratedFile(
            file_path=Path(f"infrastructure/adapter/out/rmi/{class_name}.java"),
            package_name=f"{self.base_package}.infrastructure.adapter.out.rmi",
            class_name=class_name,
            content=code,
            layer="infrastructure",
            component_type="adapter",
        )

    async def _generate_openapi_method(
        self, method: MethodSignature, facade_name: str
    ) -> str:
        """Generate OpenAPI YAML snippet for a single endpoint."""
        prompt = self._load_prompt("openapi_method")

        return await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            base_package=self.base_package,
        )

    async def generate_for_facade(
        self,
        contract: EjbContract,
        bian_compliant: bool = False,
    ) -> HexagonalStructure:
        """Generate complete hexagonal structure for an EJB facade.

        Args:
            contract: EJB contract to generate code for
            bian_compliant: Generate BIAN-compliant OpenAPI

        Returns:
            HexagonalStructure with all generated components
        """
        facade_name = contract.interface_name.replace("Facade", "")
        LOGGER.info("Generating hexagonal structure for: %s", facade_name)

        structure = HexagonalStructure()

        # 1. Domain Layer - UseCase (Port In)
        structure.use_case = await self._generate_use_case(contract, facade_name)

        # 2. Domain Layer - RMI Port (Port Out)
        structure.rmi_port = await self._generate_rmi_port(contract, facade_name)

        # 3. Application Layer - Service
        structure.service = await self._generate_service(contract, facade_name)

        # 4. Infrastructure Layer - REST Resource
        structure.resource = await self._generate_resource(contract, facade_name)

        # 5. Infrastructure Layer - RMI Adapter
        structure.rmi_adapter = await self._generate_rmi_adapter(contract, facade_name)

        # 6. Infrastructure Layer - Mappers (one per method)
        for method in contract.methods:
            mapper = await self._generate_mapper(method, facade_name)
            if mapper:
                structure.mappers.append(mapper)

        # 7. OpenAPI (optional)
        if bian_compliant:
            structure.openapi_spec = await self._generate_openapi_bian(contract, facade_name)

        return structure

    async def _generate_use_case(
        self, contract: EjbContract, facade_name: str
    ) -> GeneratedFile:
        """Generate UseCase interface (inbound port)."""
        class_name = f"{facade_name}UseCase"
        prompt = self._load_prompt("use_case")

        code = await self._call_llm(
            prompt,
            contract=contract,
            facade_name=facade_name,
            class_name=class_name,
            base_package=self.base_package,
        )

        return GeneratedFile(
            file_path=Path(f"domain/port/in/{class_name}.java"),
            package_name=f"{self.base_package}.domain.port.in",
            class_name=class_name,
            content=code,
            layer="domain",
            component_type="use_case",
        )

    async def _generate_rmi_port(
        self, contract: EjbContract, facade_name: str
    ) -> GeneratedFile:
        """Generate RMI Port interface (outbound port)."""
        class_name = f"{facade_name}RmiPort"
        prompt = self._load_prompt("rmi_port")

        code = await self._call_llm(
            prompt,
            contract=contract,
            facade_name=facade_name,
            class_name=class_name,
            base_package=self.base_package,
        )

        return GeneratedFile(
            file_path=Path(f"domain/port/out/{class_name}.java"),
            package_name=f"{self.base_package}.domain.port.out",
            class_name=class_name,
            content=code,
            layer="domain",
            component_type="port",
        )

    async def _generate_service(
        self, contract: EjbContract, facade_name: str
    ) -> GeneratedFile:
        """Generate Application Service."""
        class_name = f"{facade_name}Service"
        prompt = self._load_prompt("service")

        code = await self._call_llm(
            prompt,
            contract=contract,
            facade_name=facade_name,
            class_name=class_name,
            base_package=self.base_package,
        )

        return GeneratedFile(
            file_path=Path(f"application/service/{class_name}.java"),
            package_name=f"{self.base_package}.application.service",
            class_name=class_name,
            content=code,
            layer="application",
            component_type="service",
        )

    async def _generate_resource(
        self, contract: EjbContract, facade_name: str
    ) -> GeneratedFile:
        """Generate REST Resource (Controller)."""
        class_name = f"{facade_name}Resource"
        prompt = self._load_prompt("resource")

        code = await self._call_llm(
            prompt,
            contract=contract,
            facade_name=facade_name,
            class_name=class_name,
            base_package=self.base_package,
        )

        return GeneratedFile(
            file_path=Path(f"infrastructure/adapter/in/rest/{class_name}.java"),
            package_name=f"{self.base_package}.infrastructure.adapter.in.rest",
            class_name=class_name,
            content=code,
            layer="infrastructure",
            component_type="resource",
        )

    async def _generate_rmi_adapter(
        self, contract: EjbContract, facade_name: str
    ) -> GeneratedFile:
        """Generate RMI Adapter (implements outbound port)."""
        class_name = f"{facade_name}RmiAdapter"
        prompt = self._load_prompt("rmi_adapter")

        code = await self._call_llm(
            prompt,
            contract=contract,
            facade_name=facade_name,
            class_name=class_name,
            base_package=self.base_package,
        )

        return GeneratedFile(
            file_path=Path(f"infrastructure/adapter/out/rmi/{class_name}.java"),
            package_name=f"{self.base_package}.infrastructure.adapter.out.rmi",
            class_name=class_name,
            content=code,
            layer="infrastructure",
            component_type="adapter",
        )

    async def _generate_mapper(
        self, method: MethodSignature, facade_name: str, request_code: str = "",
        mapping_hints: list[dict] | None = None
    ) -> GeneratedFile | None:
        """Generate Mapper for a specific method.
        
        Args:
            method: Method signature
            facade_name: Name of the facade
            request_code: Generated request DTO code for field consistency
            mapping_hints: Optional field mapping hints from CSV
        """
        # Convert method name to PascalCase for class name
        class_name = f"{self._to_pascal_case(method.name)}Mapper"
        prompt = self._load_prompt("mapper")
        
        # Format mapping hints for prompt if provided
        mapping_hints_text = self._format_mapping_hints(mapping_hints) if mapping_hints else ""

        code = await self._call_llm(
            prompt,
            method=method,
            facade_name=facade_name,
            class_name=class_name,
            base_package=self.base_package,
            request_code=request_code,
            mapping_hints=mapping_hints_text,
        )

        return GeneratedFile(
            file_path=Path(f"infrastructure/mapper/{class_name}.java"),
            package_name=f"{self.base_package}.infrastructure.mapper",
            class_name=class_name,
            content=code,
            layer="infrastructure",
            component_type="mapper",
        )

    def _format_mapping_hints(self, hints: list[dict]) -> str:
        """Format mapping hints for inclusion in the LLM prompt with enhanced tables.
        
        Supports nested paths with depth up to 3 (e.g., obj.nested.field).
        
        Args:
            hints: List of mapping hint dictionaries with keys:
                - objeto_origen: Source type name
                - objeto_destino: Destination type name  
                - campo_origen: Source field path (supports dot notation)
                - campo_destino: Destination field path
                - comentario: Optional comment/note (optional)
                
        Returns:
            Formatted markdown string with tables for LLM context
        """
        if not hints:
            return "No hay hints de mapeo disponibles."
        
        lines = ["## 📋 MAPPING HINTS - Mapeo de Campos:\n"]
        
        # Agrupar por objeto origen y destino
        grouped = {}
        for hint in hints:
            key = (hint.get("objeto_origen", ""), hint.get("objeto_destino", ""))
            if key not in grouped:
                grouped[key] = []
            grouped[key].append(hint)
        
        lines.append(f"**Total mappings: {len(hints)}**\n")
        
        for (origen, destino), type_hints in grouped.items():
            lines.append(f"### {origen} → {destino}\n")
            lines.append("| Campo Origen | Campo Destino | Comentario |")
            lines.append("|--------------|---------------|------------|")
            
            for h in type_hints:
                origen_field = h.get("campo_origen", "")
                destino_field = h.get("campo_destino", "")
                comentario = h.get("comentario", "-")
                lines.append(f"| `{origen_field}` | `{destino_field}` | {comentario} |")
            
            lines.append("")  # Línea en blanco entre grupos
        
        # CRÍTICO: Agregar instrucción de uso
        lines.append("\n**CÓMO USAR ESTOS HINTS:**")
        lines.append("1. En el Mapper, usa `campoDestino` para el objeto de la API")
        lines.append("2. Extrae de `campoOrigen` del objeto EJB/Request")
        lines.append("3. Si hay comentario, presta atención a conversiones especiales")
        lines.append("4. NO inventes nombres de campos que no estén en los hints")
        lines.append("")
        
        lines.append("**IMPORTANTE**: Para paths anidados (ej: a.b.c), genera código que:")
        lines.append("1. Verifique nulls en cada nivel intermedio")
        lines.append("2. Use Optional.ofNullable().map().orElse(null) o if-checks")
        lines.append("")
        
        return "\n".join(lines)
    
    def _analyze_ejb_signature(self, method: MethodSignature) -> dict:
        """Analyze EJB method signature to determine what mapper methods are needed.
        
        Returns:
            Dict with analysis results:
            - needs_to_vo: List of VO/TO types that need to{VO} methods
            - needs_api_response: Always True
            - has_primitives_only: True if only primitive params
            - signature_formatted: Human-readable signature string
        """
        needs_to_vo = []
        has_vo_param = False
        
        # Check parameters for VO/TO types
        for param in method.parameters:
            param_type = param.type_hint
            if param_type.endswith('VO') or param_type.endswith('TO') or param_type.endswith('DTO'):
                needs_to_vo.append(param_type)
                has_vo_param = True
        
        # Format signature for logging and prompt
        params_str = ", ".join([f"{p.type_hint} {p.name}" for p in method.parameters])
        signature = f"{method.return_type} {method.name}({params_str})"
        
        analysis = {
            'needs_to_vo': needs_to_vo,
            'needs_api_response': True,  # Always needed
            'has_primitives_only': len(method.parameters) > 0 and not has_vo_param,
            'signature_formatted': signature,
        }
        
        # Log decision
        decision = f"[{method.name}] EJB Signature Analysis:\n"
        decision += f"  Signature: {signature}\n"
        if needs_to_vo:
            decision += f"  ✓ Needs mapper methods: to{', to'.join(needs_to_vo)}\n"
        elif analysis['has_primitives_only']:
            decision += f"  ✓ Primitives only - no to{{VO}} methods needed\n"
        else:
            decision += f"  ✓ No parameters - no to{{VO}} methods needed\n"
        decision += f"  ✓ Always needs: toApiResponse\n"
        
        self._decision_log.append(decision)
        LOGGER.info(decision)
        
        return analysis
    
    def _determine_http_method(self, method_name: str) -> str:
        """Determine HTTP method based on method name conventions.
        
        Args:
            method_name: EJB method name (camelCase)
            
        Returns:
            'GET' for queries, 'POST' for mutations/operations
        """
        query_prefixes = ['consultar', 'listar', 'obtener', 'buscar', 'get', 'find', 'list', 'search']
        
        method_lower = method_name.lower()
        for prefix in query_prefixes:
            if method_lower.startswith(prefix):
                decision = f"[{method_name}] HTTP Method: GET (detected query prefix '{prefix}')\n"
                self._decision_log.append(decision)
                LOGGER.info(decision)
                return 'GET'
        
        decision = f"[{method_name}] HTTP Method: POST (default for operations)\n"
        self._decision_log.append(decision)
        LOGGER.info(decision)
        return 'POST'

    async def _generate_openapi_bian(
        self, contract: EjbContract, facade_name: str
    ) -> str:
        """Generate BIAN-compliant OpenAPI specification."""
        prompt = self._load_prompt("openapi_bian")

        return await self._call_llm(
            prompt,
            contract=contract,
            facade_name=facade_name,
            base_package=self.base_package,
        )

    def _load_prompt(self, prompt_name: str) -> str:
        """Load a prompt template from file."""
        if prompt_name in self._prompts_cache:
            return self._prompts_cache[prompt_name]

        prompt_path = self.settings.prompts_dir / f"{prompt_name}.prompt"
        if not prompt_path.exists():
            LOGGER.warning("Prompt file not found: %s", prompt_path)
            return self._get_default_prompt(prompt_name)

        content = prompt_path.read_text(encoding="utf-8")
        self._prompts_cache[prompt_name] = content
        return content
    
    def get_decision_log(self) -> list[str]:
        """Get the decision log for debugging.
        
        Returns:
            List of decision strings logged during generation
        """
        return self._decision_log.copy()
    
    def clear_decision_log(self) -> None:
        """Clear the decision log."""
        self._decision_log.clear()

    def validate_imports(self, java_code: str, generation_context) -> list[str]:
        """Validate that all imports point to existing classes.
        
        Args:
            java_code: Generated Java code to validate
            generation_context: GenerationContext with scanned project structure
            
        Returns:
            List of validation errors (empty if valid)
        """
        errors = []
        if not generation_context or not generation_context.scanned:
            return errors  # Skip validation if no context
        
        import_pattern = r'^import\s+([\w.]+);'
        imports = re.findall(import_pattern, java_code, re.MULTILINE)
        
        for import_stmt in imports:
            # Skip standard Java imports
            if import_stmt.startswith('java.') or import_stmt.startswith('javax.'):
                continue
            # Skip Quarkus/Jakarta imports
            if import_stmt.startswith('jakarta.') or import_stmt.startswith('io.quarkus.'):
                continue
            # Skip Mutiny imports
            if import_stmt.startswith('io.smallrye.mutiny'):
                continue
            # Skip wildcard imports (can't validate without full scan)
            if import_stmt.endswith('.*'):
                continue
            
            # Extract class name from import
            class_name = import_stmt.split('.')[-1]
            
            # Check if class exists in scanned context
            if class_name not in generation_context.package_locations:
                # Not found - this could be a problem
                errors.append(
                    f"Import '{import_stmt}' references class '{class_name}' "
                    f"which was not found in project structure. "
                    f"Expected in one of the scanned packages."
                )
        
        return errors

    def validate_contract(self, adapter_code: str, port_code: str, component_name: str) -> list[str]:
        """Validate that Adapter @Override methods match Port interface.
        
        Args:
            adapter_code: Generated Adapter implementation code
            port_code: Port interface code to validate against
            component_name: Name of component for error messages
            
        Returns:
            List of validation errors (empty if valid)
        """
        errors = []
        
        # Extract @Override methods from adapter
        override_pattern = r'@Override\s+(?:public\s+)?([\w<>]+)\s+(\w+)\s*\(([^)]*)\)'
        adapter_overrides = re.findall(override_pattern, adapter_code)
        
        # Extract method signatures from port interface
        port_method_pattern = r'(?:public\s+)?([\w<>]+)\s+(\w+)\s*\(([^)]*)\);'
        port_methods = re.findall(port_method_pattern, port_code)
        
        # Build set of port method signatures (return_type, name, params)
        port_signatures = set()
        for return_type, method_name, params in port_methods:
            # Normalize params (remove parameter names, keep only types)
            param_types = self._extract_param_types(params)
            port_signatures.add((return_type, method_name, param_types))
        
        # Validate each @Override method
        for return_type, method_name, params in adapter_overrides:
            param_types = self._extract_param_types(params)
            signature = (return_type, method_name, param_types)
            
            if signature not in port_signatures:
                errors.append(
                    f"Method '{method_name}' in {component_name} has @Override "
                    f"but does not match any method in Port interface. "
                    f"Signature: {return_type} {method_name}({param_types})"
                )
        
        return errors

    def _extract_param_types(self, params_str: str) -> str:
        """Extract parameter types from parameter list, ignoring names."""
        if not params_str.strip():
            return ""
        
        param_list = []
        for param in params_str.split(','):
            param = param.strip()
            if param:
                # Extract type (everything before last space/identifier)
                parts = param.split()
                if len(parts) >= 2:
                    # Last part is name, everything else is type
                    param_type = ' '.join(parts[:-1])
                    param_list.append(param_type)
                else:
                    param_list.append(param)
        
        return ', '.join(param_list)

    def validate_oas_schema(self, openapi_json: str) -> list[str]:
        """Validate that OpenAPI schemas have non-empty properties.
        
        Args:
            openapi_json: Generated OpenAPI JSON string
            
        Returns:
            List of validation errors (empty if valid)
        """
        errors = []
        
        try:
            import json
            oas_dict = json.loads(openapi_json)
            
            # Check components.schemas
            schemas = oas_dict.get('components', {}).get('schemas', {})
            
            for schema_name, schema_def in schemas.items():
                if isinstance(schema_def, dict):
                    properties = schema_def.get('properties', None)
                    
                    # Check if properties exists and is empty
                    if properties is not None and isinstance(properties, dict) and len(properties) == 0:
                        errors.append(
                            f"OAS schema '{schema_name}' has empty properties. "
                            f"This indicates the schema was not properly generated from the DTO. "
                            f"Schemas must have at least one property."
                        )
        
        except json.JSONDecodeError as e:
            errors.append(f"Invalid JSON in OpenAPI specification: {e}")
        except Exception as e:
            LOGGER.warning("Error validating OAS schema: %s", e)
        
        return errors

    def _validate_method_context(self, method: MethodSignature, existing_class_code: str | None) -> dict[str, Any]:
        """Valida y enriquece el contexto antes de generar código incremental.
        
        Args:
            method: MethodSignature con información del método a generar
            existing_class_code: Código de la clase existente o None si es nueva
        
        Returns:
            dict con validaciones y tipos inferidos
        """
        validation = {
            "has_existing_class": existing_class_code is not None,
            "return_type_explicit": None,
            "param_types_explicit": [],
            "warnings": []
        }
        
        # Si existe clase, extraer tipos de otros métodos para contexto
        if existing_class_code:
            # Buscar patrones de tipos usados en otros métodos
            type_patterns = re.findall(r'(\w+(?:<[^>]+>)?)\s+(\w+)\s*=\s*facade\.(\w+)\(', existing_class_code)
            if type_patterns:
                validation["existing_patterns"] = type_patterns
                LOGGER.info(f"Found {len(type_patterns)} existing type patterns for context")
        
        # Validar que el tipo de retorno no sea Object
        if method.return_type and "Object" in method.return_type:
            validation["warnings"].append("⚠️ Return type contains 'Object' - should be specific type")
        
        # Extraer tipo de retorno explícito del atributo
        if method.return_type:
            validation["return_type_explicit"] = method.return_type
            LOGGER.info(f"Method return type: {validation['return_type_explicit']}")
        
        return validation

    def _validate_generated_code(self, code: str, component_type: str, method_name: str) -> tuple[bool, list[str]]:
        """Valida código generado antes de devolverlo.
        
        Args:
            code: Código Java generado
            component_type: Tipo de componente (use_case, service, rmi_adapter, etc.)
            method_name: Nombre del método generado
        
        Returns:
            (is_valid, list_of_errors)
        """
        errors = []
        
        # 1. Verificar imports incorrectos
        wrong_imports = [
            r'import\s+\w+\.infrastructure\.adapter\.out\.rmi\.model\.\w+(?:Request|Response)',
            r'import\s+\w+\.domain\.model\.\w+(?:VO|TO|DTO)(?!\w*(Request|Response))',
        ]
        
        for pattern in wrong_imports:
            if re.search(pattern, code):
                errors.append(f"❌ Import incorrecto detectado: Request/Response debe estar en domain.model")
        
        # 2. Verificar uso de Object en lugar de tipos específicos
        if component_type == "rmi_adapter":
            object_usage = re.search(r'Object\s+ejbResponse\s*=', code)
            if object_usage:
                errors.append(f"❌ Uso de 'Object' en lugar de tipo específico en RmiAdapter")
        
        # 3. Verificar que métodos @Override existan
        if '@Override' in code and component_type in ['service', 'rmi_adapter']:
            # Debe tener al menos una llamada al método correspondiente
            if f'.{method_name}(' not in code:
                errors.append(f"⚠️ Método @Override no parece llamar a {method_name}")
        
        # 4. Para RmiAdapter, verificar uso del Mapper correcto
        if component_type == "rmi_adapter":
            method_pascal = self._to_pascal_case(method_name)
            expected_mapper = f"{method_pascal}Mapper"
            if expected_mapper not in code and "Mapper.toApiResponse" in code:
                errors.append(f"⚠️ Posible uso de Mapper incorrecto, esperado: {expected_mapper}")
        
        is_valid = len(errors) == 0
        return is_valid, errors

    def _get_default_prompt(self, prompt_name: str) -> str:
        """Get a default prompt if file doesn't exist."""
        defaults = {
            "use_case": "Generate a Java UseCase interface for a Quarkus application.",
            "rmi_port": "Generate a Java Port interface for RMI communication.",
            "service": "Generate a Java ApplicationScoped Service for Quarkus.",
            "resource": "Generate a Java REST Resource for Quarkus with reactive endpoints.",
            "rmi_adapter": "Generate a Java RMI Adapter that implements the outbound port.",
            "mapper": "Generate a Java Mapper class with static methods.",
            "openapi_bian": "Generate BIAN-compliant OpenAPI YAML specification.",
        }
        return defaults.get(prompt_name, "Generate Java code.")

    async def _call_llm(self, prompt_template: str, **context) -> str:
        """Call LLM to generate code.

        Args:
            prompt_template: Template with placeholders
            **context: Context variables for the prompt

        Returns:
            Generated code string
        """
        # Build the full prompt with context
        full_prompt = self._build_prompt(prompt_template, **context)

        if self.settings.llm_provider == "openai":
            return await self._call_openai(full_prompt)
        else:
            return await self._call_anthropic(full_prompt)

    def _build_prompt(self, template: str, **context) -> str:
        """Build prompt with context data."""
        # Serialize contract/method to readable format
        context_str = ""

        if "contract" in context:
            contract: EjbContract = context["contract"]
            context_str += f"\n## EJB Contract: {contract.interface_name}\n"
            context_str += f"Annotation: {contract.annotation}\n"
            context_str += "\n### Methods:\n"
            for m in contract.methods:
                params = ", ".join(
                    [f"{p.type_hint} {p.name}" for p in m.parameters]
                )
                context_str += f"- {m.return_type} {m.name}({params})\n"
                if m.documentation:
                    context_str += f"  Doc: {m.documentation}\n"

        if "method" in context:
            method: MethodSignature = context["method"]
            params = ", ".join([f"{p.type_hint} {p.name}" for p in method.parameters])
            
            # Analyze EJB signature
            analysis = self._analyze_ejb_signature(method)
            
            # Add structured EJB signature section (CRITICAL for prompts)
            context_str += f"\n## EJB_SIGNATURE (ORIGINAL CONTRACT):\n"
            context_str += f"```java\n{analysis['signature_formatted']}\n```\n"
            context_str += f"\n## MAPPER_METHODS_REQUIRED:\n"
            if analysis['needs_to_vo']:
                for vo_type in analysis['needs_to_vo']:
                    context_str += f"- to{vo_type}(request) - Convert Request → {vo_type}\n"
            else:
                context_str += f"- NONE - EJB receives primitives only or no parameters\n"
            context_str += f"- toApiResponse(ejbResponse) - Convert EJB response → API Response\n"
            
            # Traditional method context
            context_str += f"\n## Method: {method.return_type} {method.name}({params})\n"
            if method.documentation:
                context_str += f"Documentation: {method.documentation}\n"
            
            # Add derived naming variables for consistent prompt usage
            method_pascal = method.name[0].upper() + method.name[1:]
            context_str += f"\nmethodName: {method.name}\n"
            context_str += f"MetodoPascalCase: {method_pascal}\n"
            
            # Add HTTP method detection for resource generation
            http_method = self._determine_http_method(method.name)
            context_str += f"http_method: {http_method}\n"
            
            # Include DTO fields if available - with full nested structure
            for p in method.parameters:
                # Use the new dto structure (preferred) or fall back to dto_fields
                if p.dto:
                    context_str += f"\n### DTO Fields for {p.name} ({p.type_hint}):\n"
                    context_str += "```\n"
                    context_str += self._format_dto_from_model(p.dto, indent=0)
                    context_str += "```\n"
                elif p.dto_fields:
                    context_str += f"\n### DTO Fields for {p.name} ({p.type_hint}):\n"
                    context_str += "```\n"
                    context_str += self._format_dto_fields(p.dto_fields, indent=0)
                    context_str += "```\n"

        # Add other context vars
        for key, value in context.items():
            if key not in ("contract", "method") and isinstance(value, str):
                context_str += f"\n{key}: {value}\n"

        # Add user-provided generation hints if available
        if hasattr(self, '_current_generation_hints') and self._current_generation_hints:
            context_str += f"\n## USER INSTRUCTIONS (HIGHEST PRIORITY):\n{self._current_generation_hints}\n"
            context_str += "\nThese instructions MUST be followed with maximum priority over any default conventions.\n"

        return f"{template}\n\n## Context:\n{context_str}"
    
    def _format_dto_fields(self, fields: list, indent: int = 0) -> str:
        """Format DTO fields recursively, showing nested structure.
        
        Args:
            fields: List of field dictionaries
            indent: Current indentation level
            
        Returns:
            Formatted string representation of fields
        """
        result = ""
        prefix = "  " * indent
        
        for field in fields:
            field_name = field.get("name", "")
            field_type = field.get("type_hint", "Object")
            nested_dto = field.get("nested_dto")
            
            result += f"{prefix}- {field_type} {field_name}\n"
            
            # If there's a nested DTO, show its fields
            if nested_dto and isinstance(nested_dto, dict):
                nested_fields = nested_dto.get("fields", [])
                if nested_fields:
                    result += f"{prefix}  (nested {nested_dto.get('name', 'DTO')} fields):\n"
                    result += self._format_dto_fields(nested_fields, indent + 2)
        
        return result
    
    def _format_dto_from_model(self, dto, indent: int = 0) -> str:
        """Format DtoDefinition model recursively, showing nested structure.
        
        Args:
            dto: DtoDefinition model with fields
            indent: Current indentation level
            
        Returns:
            Formatted string representation of DTO fields
        """
        result = ""
        prefix = "  " * indent
        
        for field in dto.fields:
            result += f"{prefix}- {field.type_hint} {field.name}\n"
            
            # If there's a nested DTO, show its fields
            if field.nested_dto:
                result += f"{prefix}  (nested {field.nested_dto.name} fields):\n"
                result += self._format_dto_from_model(field.nested_dto, indent + 2)
        
        return result
        
        return result

    async def _call_openai(self, prompt: str) -> str:
        """Call OpenAI API."""
        client = openai.AsyncOpenAI(api_key=self.settings.openai_api_key)

        response = await client.chat.completions.create(
            model=self.settings.openai_model,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are an expert Java developer specializing in Quarkus reactive "
                        "applications with hexagonal architecture. Generate clean, production-ready "
                        "Java code following best practices. Return ONLY the Java code, no explanations."
                    ),
                },
                {"role": "user", "content": prompt},
            ],
            max_completion_tokens=4000,
            temperature=0.2,
        )

        content = response.choices[0].message.content or ""
        return self._extract_code(content)

    async def _call_anthropic(self, prompt: str) -> str:
        """Call Anthropic API."""
        client = anthropic.AsyncAnthropic(api_key=self.settings.anthropic_api_key)

        response = await client.messages.create(
            model=self.settings.anthropic_model,
            max_tokens=4000,
            system=(
                "You are an expert Java developer specializing in Quarkus reactive "
                "applications with hexagonal architecture. Generate clean, production-ready "
                "Java code following best practices. Return ONLY the Java code, no explanations."
            ),
            messages=[{"role": "user", "content": prompt}],
        )

        content = response.content[0].text if response.content else ""
        return self._extract_code(content)

    def _extract_code(self, response: str) -> str:
        """Extract code from LLM response, removing markdown fences."""
        code = response.strip()

        # Remove markdown code fences
        if code.startswith("```java"):
            code = code[7:]
        elif code.startswith("```"):
            code = code[3:]

        if code.endswith("```"):
            code = code[:-3]

        return code.strip()

    def _to_pascal_case(self, name: str) -> str:
        """Convert camelCase to PascalCase."""
        if not name:
            return name
        return name[0].upper() + name[1:]
