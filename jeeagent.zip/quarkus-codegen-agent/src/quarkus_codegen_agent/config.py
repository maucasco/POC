"""Configuration settings for Quarkus Codegen Agent."""

import logging
import sys
from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # MCP Server (stdio mode)
    # In Docker: /app/intepreter-jee-mcp-server
    # On host: /data/agente/intepreter-jee-mcp-server
    mcp_server_path: str = "/app/intepreter-jee-mcp-server"
    # Python path - defaults to current interpreter
    mcp_python_path: str = sys.executable

    # LLM Provider
    llm_provider: Literal["openai", "anthropic"] = "openai"

    # OpenAI
    openai_api_key: str = ""
    openai_model: str = "gpt-4o-mini"

    # Anthropic
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-4-20250514"

    # Generation defaults
    default_base_package: str = "com.example.anticorruption"
    default_quarkus_version: str = "3.17.0"

    # Logging
    log_level: str = "INFO"

    @property
    def prompts_dir(self) -> Path:
        """Get the prompts directory path."""
        return Path(__file__).parent / "prompts"


@lru_cache
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()


def setup_logging() -> None:
    """Configure logging for the application."""
    settings = get_settings()
    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper()),
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )
