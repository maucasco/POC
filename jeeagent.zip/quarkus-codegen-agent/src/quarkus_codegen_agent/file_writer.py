"""File writer for generated Quarkus code with no-overwrite policy."""

import logging
from pathlib import Path

from .models import GeneratedFile, GenerationResult

LOGGER = logging.getLogger(__name__)


class FileWriter:
    """Writes generated files to disk with no-overwrite policy."""

    def __init__(self, output_dir: str, base_package: str, is_test: bool = False) -> None:
        """Initialize file writer.

        Args:
            output_dir: Base output directory
            base_package: Base Java package (e.g., com.example.anticorruption)
            is_test: If True, write to src/test/java instead of src/main/java
        """
        self.output_dir = Path(output_dir)
        self.base_package = base_package
        self.package_path = base_package.replace(".", "/")
        self.is_test = is_test

    @property
    def java_src_dir(self) -> Path:
        """Get the Java source directory."""
        if self.is_test:
            return self.output_dir / "src" / "test" / "java" / self.package_path
        return self.output_dir / "src" / "main" / "java" / self.package_path

    @property
    def resources_dir(self) -> Path:
        """Get the resources directory."""
        return self.output_dir / "src" / "main" / "resources"

    @property
    def test_resources_dir(self) -> Path:
        """Get the test resources directory."""
        return self.output_dir / "src" / "test" / "resources"

    def write_files(self, files: list[GeneratedFile]) -> tuple[int, int]:
        """Write generated files to disk.

        Args:
            files: List of files to write

        Returns:
            Tuple of (created_count, skipped_count)
        """
        created = 0
        skipped = 0

        for file in files:
            full_path = self._resolve_path(file)

            if full_path.exists():
                LOGGER.warning("File already exists, skipping: %s", full_path)
                skipped += 1
            else:
                self._write_file(full_path, file.content)
                LOGGER.info("Created: %s", full_path)
                created += 1

        return created, skipped

    def write_pom(self, content: str) -> bool:
        """Write pom.xml if it doesn't exist.

        Args:
            content: POM XML content

        Returns:
            True if created, False if skipped
        """
        pom_path = self.output_dir / "pom.xml"

        if pom_path.exists():
            LOGGER.warning("pom.xml already exists, skipping: %s", pom_path)
            return False

        self._write_file(pom_path, content)
        LOGGER.info("Created: %s", pom_path)
        return True

    def write_openapi(self, content: str) -> bool:
        """Write openapi.yaml if it doesn't exist.

        Args:
            content: OpenAPI YAML content

        Returns:
            True if created, False if skipped
        """
        meta_inf = self.resources_dir / "META-INF"
        openapi_path = meta_inf / "openapi.yaml"

        if openapi_path.exists():
            LOGGER.warning("openapi.yaml already exists, skipping: %s", openapi_path)
            return False

        self._write_file(openapi_path, content)
        LOGGER.info("Created: %s", openapi_path)
        return True

    def write_test_application_properties(self) -> bool:
        """Write application.properties for tests if it doesn't exist.

        Returns:
            True if created, False if skipped
        """
        props_path = self.test_resources_dir / "application.properties"

        if props_path.exists():
            LOGGER.warning("Test application.properties already exists, skipping: %s", props_path)
            return False

        content = """# Test configuration for Quarkus
quarkus.log.level=INFO
quarkus.log.category."com.davivienda".level=DEBUG

# Disable banner in tests
quarkus.banner.enabled=false

# RMI/WebLogic mock configuration (placeholders for tests)
weblogic.jndi.url=t3://localhost:7001
weblogic.jndi.principal=weblogic
weblogic.jndi.credentials=welcome1

# EJB JNDI names (override in specific tests if needed)
# Example: preliquidacion.ejb.jndi.name=ejb/PreliquidacionFacadeRemote
"""
        self._write_file(props_path, content)
        LOGGER.info("Created: %s", props_path)
        return True

    def _resolve_path(self, file: GeneratedFile) -> Path:
        """Resolve the full path for a generated file based on hexagonal layer."""
        layer_paths = {
            "domain": {
                "use_case": "domain/port/in",
                "port": "domain/port/out",
                "model": "domain/model",
            },
            "application": {
                "service": "application/service",
            },
            "infrastructure": {
                "resource": "infrastructure/adapter/in/rest",
                "adapter": "infrastructure/adapter/out/rmi",
                "mapper": "infrastructure/mapper",
                "model": "infrastructure/adapter/out/rmi/model",
            },
            "test": {
                "mapper_test": "infrastructure/mapper",
                "service_test": "application/service",
                "resource_test": "infrastructure/adapter/in/rest",
            },
        }

        layer_map = layer_paths.get(file.layer, {})
        subpath = layer_map.get(file.component_type, file.layer)

        return self.java_src_dir / subpath / f"{file.class_name}.java"

    def _write_file(self, path: Path, content: str) -> None:
        """Write content to file, creating directories as needed."""
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def get_summary(self, result: GenerationResult) -> str:
        """Generate a summary of the generation result.

        Args:
            result: Generation result

        Returns:
            Human-readable summary
        """
        lines = [
            f"\n{'=' * 60}",
            f"Generation Summary for: {result.facade_name}",
            f"{'=' * 60}",
            f"Files created: {len(result.files_created)}",
            f"Files skipped: {len(result.files_skipped)}",
        ]

        if result.files_created:
            lines.append("\nCreated:")
            for f in result.files_created:
                lines.append(f"  ✅ {f.layer}/{f.component_type}: {f.class_name}.java")

        if result.files_skipped:
            lines.append("\nSkipped (already exist):")
            for path in result.files_skipped:
                lines.append(f"  ⏭️  {path}")

        if result.errors:
            lines.append("\nErrors:")
            for err in result.errors:
                lines.append(f"  ❌ {err}")

        lines.append(f"{'=' * 60}\n")
        return "\n".join(lines)
