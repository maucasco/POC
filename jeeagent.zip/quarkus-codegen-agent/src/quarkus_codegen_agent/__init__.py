"""Quarkus Codegen Agent - Generate Quarkus hexagonal code from JEE EJB contracts."""

__version__ = "0.1.0"
