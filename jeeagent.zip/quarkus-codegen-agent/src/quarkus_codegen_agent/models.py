"""Pydantic models for Quarkus code generation."""

from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field


# ============================================================================
# Input Models (from MCP JEE Scanner)
# ============================================================================


class DtoField(BaseModel):
    """Field of a DTO with optional nested DTO structure."""

    name: str
    type_hint: str
    nested_dto: "DtoDefinition | None" = None


class DtoDefinition(BaseModel):
    """Definition of a DTO including its fields."""

    name: str
    file_path: str | None = None
    fields: list[DtoField] = Field(default_factory=list)


# Rebuild models for forward reference resolution
DtoField.model_rebuild()
DtoDefinition.model_rebuild()


class MethodParameter(BaseModel):
    """Parameter of an EJB method."""

    name: str
    type_hint: str
    dto: DtoDefinition | None = None  # Full DTO structure with nested fields
    dto_fields: list[dict] | None = None  # Legacy: flat fields list (deprecated)


class MethodSignature(BaseModel):
    """Signature of an EJB method."""

    name: str
    return_type: str
    parameters: list[MethodParameter] = Field(default_factory=list)
    documentation: str | None = None
    manager_summary: str | None = None


class EjbContract(BaseModel):
    """Contract representing a JEE EJB interface."""

    interface_name: str
    annotation: str = "@Remote"
    file_path: str | None = None
    methods: list[MethodSignature] = Field(default_factory=list)
    related_manager_path: str | None = None


class ProjectScanResult(BaseModel):
    """Result of scanning a JEE project."""

    contracts: list[EjbContract] = Field(default_factory=list)
    project_path: str = ""


# ============================================================================
# Output Models (Generated Code)
# ============================================================================


class GeneratedFile(BaseModel):
    """Represents a generated Java file."""

    file_path: Path
    package_name: str
    class_name: str
    content: str
    layer: Literal["domain", "application", "infrastructure", "test"]
    component_type: Literal[
        "use_case",
        "port",
        "service",
        "resource",
        "adapter",
        "mapper",
        "model",
        "service_test",
        "resource_test",
        "mapper_test",
    ]


class GenerationResult(BaseModel):
    """Result of code generation for a facade."""

    facade_name: str
    files_created: list[GeneratedFile] = Field(default_factory=list)
    files_skipped: list[str] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)


class HexagonalStructure(BaseModel):
    """Complete hexagonal structure for a facade."""

    # Domain layer
    use_case: GeneratedFile | None = None
    rmi_port: GeneratedFile | None = None
    domain_models: list[GeneratedFile] = Field(default_factory=list)

    # Application layer
    service: GeneratedFile | None = None

    # Infrastructure layer
    resource: GeneratedFile | None = None
    rmi_adapter: GeneratedFile | None = None
    mappers: list[GeneratedFile] = Field(default_factory=list)

    # OpenAPI (optional)
    openapi_spec: str | None = None


# ============================================================================
# BIAN Models (for OpenAPI generation)
# ============================================================================


class BianEndpoint(BaseModel):
    """BIAN-compliant endpoint definition."""

    path: str
    method: Literal["GET", "POST", "PUT", "DELETE", "PATCH"]
    operation_id: str
    summary: str  # Business-oriented description
    description: str
    request_schema: dict | None = None
    response_schema: dict | None = None
    error_responses: list[dict] = Field(default_factory=list)


class BianServiceDomain(BaseModel):
    """BIAN Service Domain mapping."""

    domain_name: str  # e.g., "Party Reference Data Directory"
    service_name: str  # e.g., "Customer Profile"
    endpoints: list[BianEndpoint] = Field(default_factory=list)
