"""Centralized import management for consistent package resolution across generators."""

import logging
from typing import Literal

LOGGER = logging.getLogger(__name__)

ComponentType = Literal["UseCase", "RmiPort", "Service", "RmiAdapter", "Resource", "Mapper", "Request", "Response"]


class ImportManager:
    """Manages import statements for different component types in hexagonal architecture."""
    
    # Package rules: component type -> list of import patterns
    # Placeholders: {base_package}, {Method} (PascalCase), {Facade} (PascalCase)
    PACKAGE_RULES = {
        "UseCase": [
            "io.smallrye.mutiny.Uni",
            "{base_package}.domain.model.{Method}Request",
            "{base_package}.domain.model.{Method}Response",
        ],
        "RmiPort": [
            "io.smallrye.mutiny.Uni",
            "{base_package}.domain.model.{Method}Request",
            "{base_package}.domain.model.{Method}Response",
        ],
        "Service": [
            "io.smallrye.mutiny.Uni",
            "jakarta.enterprise.context.ApplicationScoped",
            "jakarta.inject.Inject",
            "{base_package}.domain.model.{Method}Request",
            "{base_package}.domain.model.{Method}Response",
            "{base_package}.domain.port.in.{Facade}UseCase",
            "{base_package}.domain.port.out.{Facade}RmiPort",
        ],
        "RmiAdapter": [
            "io.smallrye.mutiny.Uni",
            "jakarta.enterprise.context.ApplicationScoped",
            "jakarta.inject.Inject",
            "{base_package}.domain.model.{Method}Request",
            "{base_package}.domain.model.{Method}Response",
            "{base_package}.domain.port.out.{Facade}RmiPort",
            "{base_package}.infrastructure.mapper.{Method}Mapper",
            "{base_package}.infrastructure.adapter.out.rmi.model.*",
        ],
        "Resource": [
            "io.smallrye.mutiny.Uni",
            "jakarta.inject.Inject",
            "jakarta.ws.rs.*",
            "jakarta.ws.rs.core.MediaType",
            "jakarta.validation.Valid",
            "org.eclipse.microprofile.openapi.annotations.Operation",
            "org.eclipse.microprofile.openapi.annotations.media.Content",
            "org.eclipse.microprofile.openapi.annotations.media.Schema",
            "org.eclipse.microprofile.openapi.annotations.responses.APIResponse",
            "org.eclipse.microprofile.openapi.annotations.tags.Tag",
            "{base_package}.domain.model.{Method}Request",
            "{base_package}.domain.model.{Method}Response",
            "{base_package}.domain.port.in.{Facade}UseCase",
        ],
        "Mapper": [
            "jakarta.enterprise.context.ApplicationScoped",
            "{base_package}.domain.model.{Method}Request",
            "{base_package}.domain.model.{Method}Response",
            "{base_package}.infrastructure.adapter.out.rmi.model.*",
        ],
        "Request": [
            # Records typically don't need imports unless using complex types
        ],
        "Response": [
            # Records typically don't need imports unless using complex types
        ],
    }
    
    def get_required_imports(
        self,
        component_type: ComponentType,
        method_name: str,
        facade_name: str,
        base_package: str,
    ) -> list[str]:
        """Get required imports for a specific component type and method.
        
        Args:
            component_type: Type of component (UseCase, Service, etc.)
            method_name: Method name in camelCase (e.g., "consultarTarifa")
            facade_name: Facade name in PascalCase (e.g., "AdminPropuesta")
            base_package: Base package path (e.g., "com.davivienda.npe")
        
        Returns:
            List of import statements with placeholders replaced
        """
        import_patterns = self.PACKAGE_RULES.get(component_type, [])
        
        # Convert method name to PascalCase for class names
        method_pascal = self._to_pascal_case(method_name)
        
        # Replace placeholders
        imports = []
        for pattern in import_patterns:
            import_stmt = pattern.format(
                base_package=base_package,
                Method=method_pascal,
                Facade=facade_name,
            )
            imports.append(import_stmt)
        
        LOGGER.debug(
            "Generated %d imports for %s.%s: %s",
            len(imports),
            component_type,
            method_name,
            imports,
        )
        
        return imports
    
    def _to_pascal_case(self, camel_case: str) -> str:
        """Convert camelCase to PascalCase.
        
        Args:
            camel_case: String in camelCase (e.g., "consultarTarifa")
        
        Returns:
            String in PascalCase (e.g., "ConsultarTarifa")
        """
        if not camel_case:
            return ""
        return camel_case[0].upper() + camel_case[1:]
    
    def format_imports(self, imports: list[str]) -> str:
        """Format imports as Java import statements.
        
        Args:
            imports: List of import paths
        
        Returns:
            Formatted import block as string
        """
        if not imports:
            return ""
        
        # Sort imports: java/jakarta first, then others
        java_imports = [i for i in imports if i.startswith(("java.", "jakarta."))]
        eclipse_imports = [i for i in imports if i.startswith("org.eclipse.")]
        other_imports = [
            i for i in imports 
            if not i.startswith(("java.", "jakarta.", "org.eclipse."))
        ]
        
        sorted_imports = sorted(java_imports) + sorted(eclipse_imports) + sorted(other_imports)
        
        return "\n".join(f"import {imp};" for imp in sorted_imports) + "\n"
    
    def add_essential_imports_for_package(self, package: str) -> list[str]:
        """Add essential imports based on package location.
        
        This is a fallback for components not explicitly managed by component type.
        
        Args:
            package: Full package path
        
        Returns:
            List of essential import paths
        """
        essential = []
        
        # Extract base package
        parts = package.split(".")
        layer_markers = {"domain", "application", "infrastructure", "test"}
        base_parts = []
        for part in parts:
            if part in layer_markers:
                break
            base_parts.append(part)
        
        if base_parts:
            base_package = ".".join(base_parts)
            
            # For domain ports (interfaces)
            if "domain.port.in" in package or "domain.port.out" in package:
                essential.extend([
                    "io.smallrye.mutiny.Uni",
                    f"{base_package}.domain.model.*",
                ])
            
            # For infrastructure/application (implementations)
            if "infrastructure" in package or "application" in package:
                essential.extend([
                    f"{base_package}.domain.model.*",
                    f"{base_package}.infrastructure.adapter.out.rmi.model.*",
                ])
            
            # For test classes
            if "test" in package:
                essential.extend([
                    f"{base_package}.domain.model.*",
                    "io.quarkus.test.junit.QuarkusTest",
                    "org.junit.jupiter.api.Test",
                ])
        
        return essential


# Singleton instance
_import_manager = ImportManager()


def get_import_manager() -> ImportManager:
    """Get the singleton ImportManager instance."""
    return _import_manager
