"""Pytest configuration and shared fixtures for quarkus-codegen-agent tests."""
import sys
from pathlib import Path

import pytest

# Add source path to Python path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


@pytest.fixture
def sample_dto_definition():
    """Create a sample DtoDefinition for tests."""
    from quarkus_codegen_agent.models import DtoDefinition, DtoField
    
    return DtoDefinition(
        name="PersonaTO",
        file_path="/src/PersonaTO.java",
        fields=[
            DtoField(name="id", type_hint="Long"),
            DtoField(name="nombre", type_hint="String"),
            DtoField(name="activo", type_hint="boolean"),
        ],
    )


@pytest.fixture
def sample_method_signature():
    """Create a sample MethodSignature for tests."""
    from quarkus_codegen_agent.models import (
        MethodSignature,
        MethodParameter,
        DtoDefinition,
        DtoField,
    )
    
    filtro_dto = DtoDefinition(
        name="FiltroVO",
        fields=[
            DtoField(name="codigo", type_hint="String"),
            DtoField(name="limite", type_hint="int"),
        ],
    )
    
    return MethodSignature(
        name="consultarDatos",
        return_type="ResultadoTO",
        parameters=[
            MethodParameter(name="filtro", type_hint="FiltroVO", dto=filtro_dto),
            MethodParameter(name="pagina", type_hint="int"),
        ],
    )


@pytest.fixture
def sample_ejb_contract():
    """Create a sample EjbContract for tests."""
    from quarkus_codegen_agent.models import (
        EjbContract,
        MethodSignature,
        MethodParameter,
    )
    
    return EjbContract(
        interface_name="TestFacade",
        annotation="@Remote",
        file_path="/src/TestFacade.java",
        related_manager_path="/src/TestFacadeManager.java",
        methods=[
            MethodSignature(
                name="consultarDatos",
                return_type="ResultadoTO",
                parameters=[
                    MethodParameter(name="filtro", type_hint="FiltroVO"),
                ],
            ),
            MethodSignature(
                name="insertarRegistro",
                return_type="Long",
                parameters=[
                    MethodParameter(name="datos", type_hint="DatosTO"),
                ],
            ),
        ],
    )


@pytest.fixture
def sample_generated_file():
    """Create a sample GeneratedFile for tests."""
    from quarkus_codegen_agent.models import GeneratedFile
    
    return GeneratedFile(
        layer="domain",
        artifact_type="entity",
        file_path="/src/domain/entity/Persona.java",
        content="""package com.test.domain.entity;

public class Persona {
    private Long id;
    private String nombre;
}
""",
    )


@pytest.fixture
def sample_mapping_hints():
    """Create sample mapping hints."""
    return [
        {
            "objeto_origen": "FiltroVO",
            "objeto_destino": "ConsultarDatosRequest",
            "campo_origen": "codigo",
            "campo_destino": "codigoIdentificador",
        },
    ]
