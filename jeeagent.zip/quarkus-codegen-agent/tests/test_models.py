"""Tests for Pydantic models."""
from __future__ import annotations

import pytest
from pydantic import ValidationError

from quarkus_codegen_agent.models import (
    DtoDefinition,
    DtoField,
    EjbContract,
    GeneratedFile,
    MethodParameter,
    MethodSignature,
)


class TestDtoModels:
    """Tests for DTO-related models."""

    def test_dto_field_basic(self):
        """DtoField should accept basic fields."""
        field = DtoField(name="customerId", type_hint="String")
        assert field.name == "customerId"
        assert field.type_hint == "String"
        assert field.nested_dto is None

    def test_dto_field_with_nested(self):
        """DtoField should support nested DTOs."""
        nested = DtoDefinition(name="AddressTO", fields=[])
        field = DtoField(name="address", type_hint="AddressTO", nested_dto=nested)
        assert field.nested_dto is not None
        assert field.nested_dto.name == "AddressTO"

    def test_dto_definition_with_fields(self):
        """DtoDefinition should contain multiple fields."""
        dto = DtoDefinition(
            name="CustomerTO",
            file_path="/path/to/CustomerTO.java",
            fields=[
                DtoField(name="id", type_hint="Long"),
                DtoField(name="name", type_hint="String"),
            ],
        )
        assert dto.name == "CustomerTO"
        assert len(dto.fields) == 2
        assert dto.fields[0].name == "id"

    def test_dto_definition_recursive(self):
        """DtoDefinition should support recursive nesting (depth 3)."""
        level3 = DtoDefinition(name="Level3VO", fields=[
            DtoField(name="value", type_hint="BigDecimal"),
        ])
        level2 = DtoDefinition(name="Level2VO", fields=[
            DtoField(name="nested", type_hint="Level3VO", nested_dto=level3),
        ])
        level1 = DtoDefinition(name="Level1TO", fields=[
            DtoField(name="child", type_hint="Level2VO", nested_dto=level2),
        ])
        
        # Navigate 3 levels deep
        assert level1.fields[0].nested_dto.fields[0].nested_dto.name == "Level3VO"


class TestMethodModels:
    """Tests for method-related models."""

    def test_method_parameter_simple(self):
        """MethodParameter should work with primitive types."""
        param = MethodParameter(name="codigo", type_hint="String")
        assert param.name == "codigo"
        assert param.dto is None

    def test_method_parameter_with_dto(self):
        """MethodParameter should include DTO definition."""
        dto = DtoDefinition(name="RequestTO", fields=[
            DtoField(name="id", type_hint="Long"),
        ])
        param = MethodParameter(name="request", type_hint="RequestTO", dto=dto)
        assert param.dto is not None
        assert param.dto.name == "RequestTO"

    def test_method_signature_complete(self):
        """MethodSignature should contain all method info."""
        method = MethodSignature(
            name="insertarPreliquidacion",
            return_type="ResultadoTO",
            parameters=[
                MethodParameter(name="userTO", type_hint="UserTO"),
                MethodParameter(name="params", type_hint="ParametrosTO"),
            ],
            documentation="Inserta una preliquidación en el sistema",
            manager_summary="Valida datos y persiste en BD",
        )
        assert method.name == "insertarPreliquidacion"
        assert method.return_type == "ResultadoTO"
        assert len(method.parameters) == 2
        assert method.documentation is not None


class TestEjbContract:
    """Tests for EJB contract model."""

    def test_ejb_contract_basic(self):
        """EjbContract should represent a facade interface."""
        contract = EjbContract(
            interface_name="PreliquidacionFacade",
            annotation="@Remote",
            file_path="/path/to/PreliquidacionFacade.java",
        )
        assert contract.interface_name == "PreliquidacionFacade"
        assert contract.annotation == "@Remote"

    def test_ejb_contract_with_methods(self):
        """EjbContract should contain methods."""
        contract = EjbContract(
            interface_name="TestFacade",
            methods=[
                MethodSignature(name="method1", return_type="void"),
                MethodSignature(name="method2", return_type="String"),
            ],
        )
        assert len(contract.methods) == 2


class TestGeneratedFile:
    """Tests for generated file model."""

    def test_generated_file_domain(self):
        """GeneratedFile should accept domain layer components."""
        from pathlib import Path
        
        file = GeneratedFile(
            file_path=Path("domain/model/TestRequest.java"),
            package_name="com.example.domain.model",
            class_name="TestRequest",
            content="public record TestRequest() {}",
            layer="domain",
            component_type="model",
        )
        assert file.layer == "domain"
        assert file.component_type == "model"

    def test_generated_file_infrastructure(self):
        """GeneratedFile should accept infrastructure layer components."""
        from pathlib import Path
        
        file = GeneratedFile(
            file_path=Path("infrastructure/mapper/TestMapper.java"),
            package_name="com.example.infrastructure.mapper",
            class_name="TestMapper",
            content="public final class TestMapper {}",
            layer="infrastructure",
            component_type="mapper",
        )
        assert file.layer == "infrastructure"
        assert file.component_type == "mapper"

    def test_generated_file_invalid_layer(self):
        """GeneratedFile should reject invalid layers."""
        from pathlib import Path
        
        with pytest.raises(ValidationError):
            GeneratedFile(
                file_path=Path("invalid/Test.java"),
                package_name="com.example",
                class_name="Test",
                content="",
                layer="invalid_layer",  # type: ignore
                component_type="model",
            )
