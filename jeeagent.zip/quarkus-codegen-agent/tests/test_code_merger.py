"""Tests for CodeMerger class."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from quarkus_codegen_agent.code_merger import CodeMerger


@pytest.fixture
def output_dir(tmp_path: Path) -> Path:
    """Create a temporary output directory structure."""
    # Create standard hexagonal structure
    (tmp_path / "src/main/java/com/test/domain/model").mkdir(parents=True)
    (tmp_path / "src/main/java/com/test/domain/port/in").mkdir(parents=True)
    (tmp_path / "src/main/java/com/test/domain/port/out").mkdir(parents=True)
    (tmp_path / "src/main/java/com/test/application/service").mkdir(parents=True)
    (tmp_path / "src/main/java/com/test/infrastructure/adapter/in/rest").mkdir(parents=True)
    (tmp_path / "src/main/java/com/test/infrastructure/adapter/out/rmi").mkdir(parents=True)
    (tmp_path / "src/main/java/com/test/infrastructure/mapper").mkdir(parents=True)
    (tmp_path / "src/main/resources/openapi").mkdir(parents=True)
    (tmp_path / "src/test/java/com/test/application/service").mkdir(parents=True)
    return tmp_path


@pytest.fixture
def merger(output_dir: Path) -> CodeMerger:
    """Create a CodeMerger instance."""
    return CodeMerger(str(output_dir), "com.test")


class TestCodeMergerBasic:
    """Basic tests for CodeMerger."""

    def test_init(self, merger: CodeMerger, output_dir: Path):
        """CodeMerger should initialize with correct paths."""
        assert merger.output_dir == output_dir
        assert merger.base_package == "com.test"

    def test_class_exists_false(self, merger: CodeMerger):
        """class_exists should return False for non-existent files."""
        assert merger.class_exists("TestFacade", "service") is False
        assert merger.class_exists("TestFacade", "use_case") is False

    def test_class_exists_true(self, merger: CodeMerger, output_dir: Path):
        """class_exists should return True for existing files."""
        # Create a service file
        service_path = output_dir / "src/main/java/com/test/application/service/TestService.java"
        service_path.write_text("public class TestService {}")
        
        assert merger.class_exists("Test", "service") is True

    def test_dto_exists_false(self, merger: CodeMerger):
        """dto_exists should return False for non-existent DTOs."""
        assert merger.dto_exists("NonExistentRequest") is False

    def test_dto_exists_true(self, merger: CodeMerger, output_dir: Path):
        """dto_exists should return True for existing DTOs."""
        dto_path = output_dir / "src/main/java/com/test/domain/model/TestRequest.java"
        dto_path.write_text("public record TestRequest() {}")
        
        assert merger.dto_exists("TestRequest") is True


class TestCodeMergerMethodMerge:
    """Tests for method merging functionality."""

    def test_merge_method_into_interface(self, merger: CodeMerger, output_dir: Path):
        """Should merge new method into existing interface."""
        # Create existing UseCase interface
        use_case_path = output_dir / "src/main/java/com/test/domain/port/in/TestUseCase.java"
        existing_content = '''package com.test.domain.port.in;

public interface TestUseCase {
    
    String existingMethod(String param);
}
'''
        use_case_path.write_text(existing_content)
        
        # New method to merge
        new_method = "    Response newMethod(Request request);"
        
        result = merger.write_or_merge("Test", "use_case", new_method, "newMethod")
        
        assert result is not None
        merged_content = use_case_path.read_text()
        assert "existingMethod" in merged_content
        assert "newMethod" in merged_content

    def test_merge_method_into_class(self, merger: CodeMerger, output_dir: Path):
        """Should merge new method into existing class."""
        # Create existing Service class
        service_path = output_dir / "src/main/java/com/test/application/service/TestService.java"
        existing_content = '''package com.test.application.service;

@ApplicationScoped
public class TestService implements TestUseCase {
    
    @Override
    public String existingMethod(String param) {
        return param;
    }
}
'''
        service_path.write_text(existing_content)
        
        # New method to merge
        new_method = '''    @Override
    public Response newMethod(Request request) {
        return Response.ok();
    }'''
        
        result = merger.write_or_merge("Test", "service", new_method, "newMethod")
        
        assert result is not None
        merged_content = service_path.read_text()
        assert "existingMethod" in merged_content
        assert "newMethod" in merged_content

    def test_skip_duplicate_method(self, merger: CodeMerger, output_dir: Path):
        """Should skip merging if method already exists."""
        # Create existing class with the method
        service_path = output_dir / "src/main/java/com/test/application/service/TestService.java"
        existing_content = '''package com.test.application.service;

public class TestService {
    public String duplicateMethod() {
        return "original";
    }
}
'''
        service_path.write_text(existing_content)
        
        # Try to merge same method
        new_method = '''    public String duplicateMethod() {
        return "new";
    }'''
        
        result = merger.write_or_merge("Test", "service", new_method, "duplicateMethod")
        
        # Should return None (skipped)
        assert result is None
        # Original should be unchanged
        assert "original" in service_path.read_text()


class TestOpenAPIMerge:
    """Tests for OpenAPI JSON merging."""

    def test_write_new_openapi(self, merger: CodeMerger, output_dir: Path):
        """Should create new OpenAPI file."""
        openapi_content = json.dumps({
            "openapi": "3.0.3",
            "info": {"title": "Test API", "version": "1.0.0"},
            "paths": {
                "/test/method1": {
                    "post": {"operationId": "method1"}
                }
            }
        })
        
        result_path, was_merged = merger.write_openapi_json("Test", "method1", openapi_content)
        
        assert result_path.exists()
        assert was_merged is False
        
        written = json.loads(result_path.read_text())
        assert "/test/method1" in written["paths"]

    def test_merge_openapi_paths(self, merger: CodeMerger, output_dir: Path):
        """Should merge new paths into existing OpenAPI."""
        # Create existing OpenAPI file
        openapi_path = output_dir / "src/main/resources/openapi/Test.json"
        existing = {
            "openapi": "3.0.3",
            "info": {"title": "Test API", "version": "1.0.0"},
            "paths": {
                "/test/method1": {"post": {"operationId": "method1"}}
            },
            "components": {"schemas": {"Schema1": {"type": "object"}}}
        }
        openapi_path.write_text(json.dumps(existing))
        
        # New method to merge
        new_content = json.dumps({
            "openapi": "3.0.3",
            "info": {"title": "Test API", "version": "1.0.0"},
            "paths": {
                "/test/method2": {"post": {"operationId": "method2"}}
            },
            "components": {"schemas": {"Schema2": {"type": "string"}}}
        })
        
        result_path, was_merged = merger.write_openapi_json("Test", "method2", new_content)
        
        assert was_merged is True
        merged = json.loads(result_path.read_text())
        assert "/test/method1" in merged["paths"]
        assert "/test/method2" in merged["paths"]
        assert "Schema1" in merged["components"]["schemas"]
        assert "Schema2" in merged["components"]["schemas"]

    def test_merge_invalid_json_fallback(self, merger: CodeMerger, output_dir: Path):
        """Should fallback to separate file on invalid JSON."""
        invalid_content = "not valid json {"
        
        result_path, was_merged = merger.write_openapi_json("Test", "badMethod", invalid_content)
        
        assert result_path.exists()
        assert was_merged is False
        assert "badMethod" in result_path.name
