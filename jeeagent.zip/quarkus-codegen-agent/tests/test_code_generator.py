"""Tests for CodeGenerator class."""
from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from quarkus_codegen_agent.code_generator import CodeGenerator
from quarkus_codegen_agent.models import (
    MethodSignature,
    MethodParameter,
    DtoDefinition,
    DtoField,
)


@pytest.fixture
def generator() -> CodeGenerator:
    """Create a CodeGenerator instance."""
    return CodeGenerator(base_package="com.test")


@pytest.fixture
def simple_method() -> MethodSignature:
    """Create a simple method signature for testing."""
    return MethodSignature(
        name="consultarDatos",
        return_type="ResultadoTO",
        parameters=[
            MethodParameter(name="userTO", type_hint="UserTO"),
            MethodParameter(name="codigo", type_hint="String"),
        ],
    )


@pytest.fixture
def method_with_dto() -> MethodSignature:
    """Create a method signature with DTO parameter."""
    dto = DtoDefinition(
        name="ConsultaTO",
        fields=[
            DtoField(name="codigo", type_hint="String"),
            DtoField(name="fechaInicio", type_hint="Calendar"),
            DtoField(name="estado", type_hint="Integer"),
        ],
    )
    return MethodSignature(
        name="insertarRegistro",
        return_type="ResultadoInsertTO",
        parameters=[
            MethodParameter(name="userTO", type_hint="UserTO"),
            MethodParameter(name="consulta", type_hint="ConsultaTO", dto=dto),
        ],
    )


class TestCodeGeneratorBasic:
    """Basic tests for CodeGenerator."""

    def test_init(self, generator: CodeGenerator):
        """CodeGenerator should initialize with base package."""
        assert generator.base_package == "com.test"

    def test_to_pascal_case(self, generator: CodeGenerator):
        """_to_pascal_case should convert method names."""
        assert generator._to_pascal_case("consultarDatos") == "ConsultarDatos"
        assert generator._to_pascal_case("get") == "Get"
        assert generator._to_pascal_case("insertarPreliquidacion") == "InsertarPreliquidacion"

    def test_extract_code_removes_markdown(self, generator: CodeGenerator):
        """_extract_code should remove markdown fences."""
        response = '''```java
public class Test {}
```'''
        result = generator._extract_code(response)
        assert result == "public class Test {}"
        assert "```" not in result

    def test_extract_code_handles_plain(self, generator: CodeGenerator):
        """_extract_code should handle plain code."""
        response = "public class Test {}"
        result = generator._extract_code(response)
        assert result == "public class Test {}"


class TestPromptLoading:
    """Tests for prompt template loading."""

    def test_load_prompt_from_file(self, generator: CodeGenerator, tmp_path):
        """Should load prompt from file."""
        # Create a temp prompt file
        prompt_content = "Generate {class_name} for {method_name}"
        prompt_file = tmp_path / "test.prompt"
        prompt_file.write_text(prompt_content)
        
        generator.settings.prompts_dir = tmp_path
        generator._prompts_cache.clear()
        
        result = generator._load_prompt("test")
        assert result == prompt_content

    def test_load_prompt_caches(self, generator: CodeGenerator, tmp_path):
        """Should cache loaded prompts."""
        prompt_file = tmp_path / "cached.prompt"
        prompt_file.write_text("Original content")
        
        generator.settings.prompts_dir = tmp_path
        generator._prompts_cache.clear()
        
        # First load
        result1 = generator._load_prompt("cached")
        
        # Modify file
        prompt_file.write_text("Modified content")
        
        # Second load should return cached
        result2 = generator._load_prompt("cached")
        
        assert result1 == result2 == "Original content"


class TestMappingHintsFormatting:
    """Tests for mapping hints formatting."""

    def test_format_empty_hints(self, generator: CodeGenerator):
        """Should return empty string for no hints."""
        result = generator._format_mapping_hints([])
        assert result == ""

    def test_format_single_hint(self, generator: CodeGenerator):
        """Should format a single mapping hint."""
        hints = [
            {
                "objeto_origen": "ParametrosTO",
                "objeto_destino": "Request",
                "campo_origen": "codigo",
                "campo_destino": "codigo",
            }
        ]
        result = generator._format_mapping_hints(hints)
        
        assert "ParametrosTO" in result
        assert "Request" in result
        assert "codigo" in result

    def test_format_nested_hint_depth_2(self, generator: CodeGenerator):
        """Should indicate depth for nested paths."""
        hints = [
            {
                "objeto_origen": "ParametrosTO",
                "objeto_destino": "Request",
                "campo_origen": "liquidacionVO.valorTotal",
                "campo_destino": "valorTotal",
            }
        ]
        result = generator._format_mapping_hints(hints)
        
        assert "Profundidad 2" in result
        assert "null-checks" in result

    def test_format_nested_hint_depth_3(self, generator: CodeGenerator):
        """Should indicate depth 3 for deep nesting."""
        hints = [
            {
                "objeto_origen": "ParametrosTO",
                "objeto_destino": "Request",
                "campo_origen": "liquidacionVO.consumoVO.m3",
                "campo_destino": "m3",
            }
        ]
        result = generator._format_mapping_hints(hints)
        
        assert "Profundidad 3" in result

    def test_format_groups_by_source(self, generator: CodeGenerator):
        """Should group hints by source type."""
        hints = [
            {"objeto_origen": "TypeA", "objeto_destino": "Dest", "campo_origen": "f1", "campo_destino": "f1"},
            {"objeto_origen": "TypeA", "objeto_destino": "Dest", "campo_origen": "f2", "campo_destino": "f2"},
            {"objeto_origen": "TypeB", "objeto_destino": "Dest", "campo_origen": "f3", "campo_destino": "f3"},
        ]
        result = generator._format_mapping_hints(hints)
        
        assert "**TypeA**" in result
        assert "**TypeB**" in result


class TestDtoFieldCollection:
    """Tests for DTO field collection functionality."""

    def test_collect_dto_fields_empty(self, generator: CodeGenerator, simple_method: MethodSignature):
        """Should return empty map for method without DTOs."""
        result = generator._collect_dto_fields_map(simple_method)
        assert result == {}

    def test_collect_dto_fields_with_dto(self, generator: CodeGenerator, method_with_dto: MethodSignature):
        """Should collect fields from DTO parameter."""
        result = generator._collect_dto_fields_map(method_with_dto)
        
        assert "ConsultaTO" in result
        fields = result["ConsultaTO"]
        assert len(fields) == 3
        assert any(f["name"] == "codigo" for f in fields)

    def test_collect_nested_dto_fields(self, generator: CodeGenerator):
        """Should collect fields from nested DTOs."""
        nested_dto = DtoDefinition(
            name="NestedVO",
            fields=[DtoField(name="nestedValue", type_hint="BigDecimal")],
        )
        parent_dto = DtoDefinition(
            name="ParentTO",
            fields=[
                DtoField(name="id", type_hint="Long"),
                DtoField(name="nested", type_hint="NestedVO", nested_dto=nested_dto),
            ],
        )
        method = MethodSignature(
            name="test",
            return_type="void",
            parameters=[MethodParameter(name="param", type_hint="ParentTO", dto=parent_dto)],
        )
        
        result = generator._collect_dto_fields_map(method)
        
        assert "ParentTO" in result
        assert "NestedVO" in result


@pytest.mark.asyncio
class TestCodeGeneration:
    """Integration tests for code generation (with mocked LLM)."""

    async def test_generate_request_dto(self, generator: CodeGenerator, simple_method: MethodSignature):
        """Should generate request DTO."""
        with patch.object(generator, '_call_llm', new_callable=AsyncMock) as mock_llm:
            mock_llm.return_value = '''package com.test.domain.model;

public record ConsultarDatosRequest(
    String codigo
) {}'''
            
            result = await generator._generate_request_dto(simple_method, "Test")
            
            assert result is not None
            assert result.class_name == "ConsultarDatosRequest"
            assert result.layer == "domain"
            assert result.component_type == "model"

    async def test_generate_mapper(self, generator: CodeGenerator, simple_method: MethodSignature):
        """Should generate mapper class."""
        with patch.object(generator, '_call_llm', new_callable=AsyncMock) as mock_llm:
            mock_llm.return_value = '''package com.test.infrastructure.mapper;

public final class ConsultarDatosMapper {
    private ConsultarDatosMapper() {}
}'''
            
            result = await generator._generate_mapper(simple_method, "Test", "", None)
            
            assert result is not None
            assert result.class_name == "ConsultarDatosMapper"
            assert result.layer == "infrastructure"
            assert result.component_type == "mapper"

    async def test_generate_mapper_with_hints(self, generator: CodeGenerator, simple_method: MethodSignature):
        """Should pass mapping hints to LLM."""
        hints = [{"objeto_origen": "A", "objeto_destino": "B", "campo_origen": "x", "campo_destino": "y"}]
        
        with patch.object(generator, '_call_llm', new_callable=AsyncMock) as mock_llm:
            mock_llm.return_value = "public class Mapper {}"
            
            await generator._generate_mapper(simple_method, "Test", "", hints)
            
            # Verify mapping_hints was passed to _call_llm
            call_kwargs = mock_llm.call_args.kwargs
            assert "mapping_hints" in call_kwargs
            assert call_kwargs["mapping_hints"] != ""
