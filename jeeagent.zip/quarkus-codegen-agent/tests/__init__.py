"""Tests for quarkus-codegen-agent."""
