"""Tests for FileWriter class."""
from __future__ import annotations

from pathlib import Path

import pytest

from quarkus_codegen_agent.file_writer import FileWriter
from quarkus_codegen_agent.models import GeneratedFile


@pytest.fixture
def output_dir(tmp_path: Path) -> Path:
    """Create a temporary output directory."""
    return tmp_path


@pytest.fixture
def writer(output_dir: Path) -> FileWriter:
    """Create a FileWriter instance."""
    return FileWriter(str(output_dir), "com.test")


class TestFileWriter:
    """Tests for FileWriter functionality."""

    def test_init(self, writer: FileWriter, output_dir: Path):
        """FileWriter should initialize with correct paths."""
        assert writer.output_dir == output_dir
        assert writer.base_package == "com.test"

    def test_write_single_file(self, writer: FileWriter, output_dir: Path):
        """Should write a single generated file."""
        file = GeneratedFile(
            file_path=Path("domain/model/TestDto.java"),
            package_name="com.test.domain.model",
            class_name="TestDto",
            content="public record TestDto(String value) {}",
            layer="domain",
            component_type="model",
        )
        
        created, skipped = writer.write_files([file])
        
        assert created == 1
        assert skipped == 0
        
        expected_path = output_dir / "src/main/java/com/test/domain/model/TestDto.java"
        assert expected_path.exists()
        assert "public record TestDto" in expected_path.read_text()

    def test_write_multiple_files(self, writer: FileWriter, output_dir: Path):
        """Should write multiple generated files."""
        files = [
            GeneratedFile(
                file_path=Path("domain/model/Request.java"),
                package_name="com.test.domain.model",
                class_name="Request",
                content="public record Request() {}",
                layer="domain",
                component_type="model",
            ),
            GeneratedFile(
                file_path=Path("domain/model/Response.java"),
                package_name="com.test.domain.model",
                class_name="Response",
                content="public record Response() {}",
                layer="domain",
                component_type="model",
            ),
        ]
        
        created, skipped = writer.write_files(files)
        
        assert created == 2
        assert skipped == 0

    def test_skip_existing_file(self, writer: FileWriter, output_dir: Path):
        """Should skip existing files by default."""
        # Pre-create the file
        target_dir = output_dir / "src/main/java/com/test/domain/model"
        target_dir.mkdir(parents=True)
        target_file = target_dir / "Existing.java"
        target_file.write_text("// Original content")
        
        file = GeneratedFile(
            file_path=Path("domain/model/Existing.java"),
            package_name="com.test.domain.model",
            class_name="Existing",
            content="// New content",
            layer="domain",
            component_type="model",
        )
        
        created, skipped = writer.write_files([file])
        
        assert created == 0
        assert skipped == 1
        assert "Original content" in target_file.read_text()

    def test_overwrite_existing_file(self, writer: FileWriter, output_dir: Path):
        """Should overwrite existing files when requested."""
        # Pre-create the file
        target_dir = output_dir / "src/main/java/com/test/domain/model"
        target_dir.mkdir(parents=True)
        target_file = target_dir / "Overwrite.java"
        target_file.write_text("// Original content")
        
        file = GeneratedFile(
            file_path=Path("domain/model/Overwrite.java"),
            package_name="com.test.domain.model",
            class_name="Overwrite",
            content="// New content",
            layer="domain",
            component_type="model",
        )
        
        created, skipped = writer.write_files([file], overwrite=True)
        
        assert created == 1
        assert skipped == 0
        assert "New content" in target_file.read_text()

    def test_write_test_file(self, writer: FileWriter, output_dir: Path):
        """Should write test files to test directory."""
        file = GeneratedFile(
            file_path=Path("application/service/TestServiceTest.java"),
            package_name="com.test.application.service",
            class_name="TestServiceTest",
            content="@QuarkusTest public class TestServiceTest {}",
            layer="test",
            component_type="service_test",
        )
        
        created, _ = writer.write_files([file])
        
        assert created == 1
        expected_path = output_dir / "src/test/java/com/test/application/service/TestServiceTest.java"
        assert expected_path.exists()

    def test_create_directory_structure(self, writer: FileWriter, output_dir: Path):
        """Should create nested directory structure."""
        file = GeneratedFile(
            file_path=Path("infrastructure/adapter/out/rmi/model/DeepNested.java"),
            package_name="com.test.infrastructure.adapter.out.rmi.model",
            class_name="DeepNested",
            content="public class DeepNested {}",
            layer="infrastructure",
            component_type="model",
        )
        
        created, _ = writer.write_files([file])
        
        assert created == 1
        expected_path = output_dir / "src/main/java/com/test/infrastructure/adapter/out/rmi/model/DeepNested.java"
        assert expected_path.exists()


class TestFileWriterOpenAPI:
    """Tests for OpenAPI file writing."""

    def test_write_openapi(self, writer: FileWriter, output_dir: Path):
        """Should write OpenAPI spec to resources."""
        openapi_content = '{"openapi": "3.0.3", "info": {"title": "Test"}}'
        
        writer.write_openapi(openapi_content, "test-api.json")
        
        expected_path = output_dir / "src/main/resources/openapi/test-api.json"
        assert expected_path.exists()
        assert "3.0.3" in expected_path.read_text()
