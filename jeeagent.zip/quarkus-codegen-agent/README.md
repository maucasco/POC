# Quarkus Codegen Agent

Agente que genera código Quarkus reactivo con arquitectura hexagonal a partir de contratos EJB JEE.

## Características

- 🏗️ **Arquitectura Hexagonal**: Genera código limpio siguiendo patrón puertos y adaptadores
- ⚡ **Reactivo**: Usa Mutiny con `Uni<T>` para programación reactiva
- 🔌 **Anti-Corruption Layer**: Capa anticorrupción entre EJBs legacy y APIs modernas
- 📄 **OpenAPI JSON**: Genera especificaciones OpenAPI 3.0 por método
- 🔄 **Generación Incremental**: Los métodos se acumulan en las mismas clases por facade
- 🚫 **No Sobrescribe**: Respeta archivos existentes

## Instalación

```bash
cd quarkus-codegen-agent
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Configuración

Crear archivo `.env`:

```bash
# MCP Server (stdio - se lanza automáticamente)
MCP_SERVER_COMMAND=/data/agente/.venv/bin/python
MCP_SERVER_ARGS=-m,src.main
MCP_SERVER_CWD=/data/agente/intepreter-jee-mcp-server

# LLM Provider: openai | anthropic
LLM_PROVIDER=openai
OPENAI_API_KEY=sk-your-key
OPENAI_MODEL=gpt-4o-mini

# Alternativa Anthropic
ANTHROPIC_API_KEY=sk-ant-your-key
ANTHROPIC_MODEL=claude-3-5-sonnet-20241022
```

## Uso

### Listar facades disponibles

```bash
quarkus-gen list /path/to/jee-project
```

### Listar métodos de una facade

```bash
quarkus-gen methods /path/to/jee-project -i PreliquidacionConsultaFacade
```

### Generar código para un método (modo incremental)

```bash
# Primera invocación - crea las clases
quarkus-gen method /path/to/jee-project \
  -i PreliquidacionConsultaFacade \
  -m consultarAgendasActivas \
  -o ./output \
  -p com.example.acl

# Segunda invocación - agrega método a las mismas clases
quarkus-gen method /path/to/jee-project \
  -i PreliquidacionConsultaFacade \
  -m consultarAgendasPeriodo \
  -o ./output \
  -p com.example.acl
```

### Generar con archivos separados por método (legacy)

```bash
quarkus-gen method /path/to/jee-project \
  -i PreliquidacionConsultaFacade \
  -m consultarAgendasActivas \
  -o ./output \
  --separate-files
```

### Opciones del comando `method`

| Opción | Descripción |
|--------|-------------|
| `-i, --interface` | Nombre de la interface Facade (requerido) |
| `-m, --method` | Nombre del método a generar (requerido) |
| `-o, --output` | Directorio de salida (requerido) |
| `-p, --base-package` | Paquete Java base (default: com.example.anticorruption) |
| `--no-tests` | No generar tests unitarios |
| `--no-openapi` | No generar spec OpenAPI JSON |
| `--separate-files` | Crear archivos separados por método |

### Generar facade completa

```bash
quarkus-gen facade /path/to/jee-project \
  -i PreliquidacionConsultaFacade \
  -o ./output \
  -p com.example.acl
```

### Inicializar estructura del proyecto

```bash
quarkus-gen init ./output -p com.example.acl
```

## Estructura Generada

```
output/
├── pom.xml
└── src/
    ├── java/com/example/acl/
    │   ├── domain/
    │   │   ├── model/                    # DTOs (separados por método)
    │   │   │   ├── ConsultarAgendasActivasRequest.java
    │   │   │   ├── ConsultarAgendasActivasResponse.java
    │   │   │   └── ...
    │   │   └── port/
    │   │       ├── in/                   # Use Cases (una por facade)
    │   │       │   └── PreliquidacionConsultaUseCase.java
    │   │       └── out/                  # RMI Ports (una por facade)
    │   │           └── PreliquidacionConsultaRmiPort.java
    │   ├── application/
    │   │   └── service/                  # Services (una por facade)
    │   │       └── PreliquidacionConsultaService.java
    │   └── infrastructure/
    │       ├── adapter/
    │       │   ├── in/rest/              # Resources (una por facade)
    │       │   │   └── PreliquidacionConsultaResource.java
    │       │   └── out/rmi/              # RMI Adapters (una por facade)
    │       │       └── PreliquidacionConsultaRmiAdapter.java
    │       └── mapper/                   # Mappers (uno por método)
    │           └── ConsultarAgendasActivasMapper.java
    ├── test/java/...                     # Tests
    └── resources/
        └── openapi/                      # OpenAPI JSON specs
            └── PreliquidacionConsulta_consultarAgendasActivas.json
```

## Componentes Generados

| Componente | Capa | Propósito | Merge |
|------------|------|-----------|-------|
| `Request/Response DTO` | Domain Model | DTOs de entrada/salida | ❌ Separado |
| `UseCase` | Domain Port In | Define operaciones de negocio | ✅ Merge |
| `RmiPort` | Domain Port Out | Interface comunicación EJB | ✅ Merge |
| `Service` | Application | Orquesta lógica de negocio | ✅ Merge |
| `Resource` | Infrastructure In | Endpoints REST | ✅ Merge |
| `RmiAdapter` | Infrastructure Out | Cliente EJB/RMI WebLogic | ✅ Merge |
| `Mapper` | Infrastructure | Transformaciones DTO | ❌ Separado |
| `ServiceTest` | Test | Tests unitarios del servicio | ✅ Merge |
| `ResourceTest` | Test | Tests de integración REST | ✅ Merge |
| `MapperTest` | Test | Tests del mapper | ❌ Separado |

## Requisitos

- Python 3.11+
- MCP Server `intepreter-jee-mcp-server` (se ejecuta automáticamente vía stdio)
- API key de OpenAI o Anthropic

## Licencia

MIT
