import asyncio
import logging
logging.basicConfig(level=logging.INFO)

from src.quarkus_codegen_agent.mcp_client import McpClient

async def main():
    client = McpClient()
    result = await client.scan_project(
        project_path="/data/jee-projects/parametros-portal-rmi/parametros-portal-rmi-ejb",
        detailed_scan=False
    )
    print(f"\nContracts found: {len(result.contracts)}")
    for c in result.contracts:
        print(f"  - {c.interface_name} ({len(c.methods)} methods)")
        for m in c.methods:
            print(f"      * {m.name}")
    
asyncio.run(main())
