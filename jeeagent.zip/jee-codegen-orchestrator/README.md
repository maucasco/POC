# JEE Codegen Orchestrator

LangGraph-based orchestrator for migrating JEE EJB facades to Quarkus hexagonal architecture with automatic compilation verification and error fixing.

## Features

- **Automated Workflow**: Orchestrates the complete migration pipeline
- **MCP Integration**: Uses MCP server to scan JEE projects for EJB contracts
- **Documentation Generation**: Creates comprehensive functional documentation using LLM
- **Code Generation**: Generates Quarkus hexagonal architecture code
- **Compilation Verification**: Automatically compiles generated code
- **Auto-Fix**: Uses LLM to fix compilation errors (up to 3 attempts)

## Architecture

The orchestrator uses LangGraph to manage the following workflow:

```
┌─────────┐     ┌──────────┐     ┌──────────┐     ┌─────────┐
│  Scan   │────▶│ Document │────▶│ Generate │────▶│ Compile │
└─────────┘     └──────────┘     └──────────┘     └────┬────┘
                                                       │
                                          ┌────────────┴────────────┐
                                          ▼                         ▼
                                    ┌─────────┐               ┌─────────┐
                                    │   Fix   │◀─────────────│ Success │
                                    └────┬────┘   (retry)     └─────────┘
                                         │
                                    (max 3 attempts)
                                         │
                                         ▼
                                    ┌─────────┐
                                    │   End   │
                                    └─────────┘
```

## Installation

```bash
# From the workspace root
cd jee-codegen-orchestrator

# Install with pip
pip install -e .

# Or install dependencies only
pip install langgraph typer pydantic-settings anthropic
```

## Usage

### Generate code for a specific method

```bash
jee-orchestrate method /path/to/jee-project \
    -i AdministracionPropuestaFacade \
    -m consultarPropuesta \
    -o /data/agente/output \
    --max-retries 3
```

### Generate code for all methods in a facade

```bash
jee-orchestrate method /path/to/jee-project \
    -i AdministracionPropuestaFacade \
    -o /data/agente/output
```

### Verify compilation only

```bash
jee-orchestrate verify /data/agente/output
```

### Show configuration

```bash
jee-orchestrate config
```

## Configuration

Create a `.env` file in `/data/agente/` with:

```env
LLM_PROVIDER=anthropic
ANTHROPIC_API_KEY=your-api-key
ANTHROPIC_MODEL=claude-sonnet-4-20250514
MCP_SERVER_PATH=/data/agente/intepreter-jee-mcp-server
OUTPUT_BASE_DIR=/data/agente/output
MAX_FIX_ATTEMPTS=3
```

## Components

### Nodes

- **scanner.py**: Uses MCP server to scan JEE projects and extract EJB contracts
- **documenter.py**: Generates documentation using LLM analysis (from jee-doc-agent)
- **generator.py**: Generates Quarkus hexagonal code (from quarkus-codegen-agent)
- **compiler.py**: Runs `mvn compile` and parses errors
- **fixer.py**: Uses LLM to fix compilation errors

### State

The orchestrator maintains a typed state dictionary with:

- Input parameters (project_path, facade_name, method_name, etc.)
- Scan results (contract, method)
- Documentation content
- Generated files list
- Compilation status and errors
- Fix attempt counter

## Dependencies

This project reuses components from:

- `intepreter-jee-mcp-server`: MCP server for EJB contract scanning
- `jee-doc-agent`: LLM-based documentation generation
- `quarkus-codegen-agent`: Quarkus code generation

## Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Type checking
mypy src

# Lint
ruff check src
```

## License

Proprietary
