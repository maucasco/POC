"""FastMCP server exposing orchestrator as tools for GitHub Copilot agents."""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any
from uuid import uuid4

from mcp.server.fastmcp import FastMCP, Context

from .mcp_models import (
    CachedContract,
    CacheStats,
    CompileError,
    FacadeInfo,
    GeneratedFileInfo,
    ListFacadesResult,
    MappingHintInput,
    MigrationProgress,
    MigrationResult,
    MigrationStatus,
    ValidationResult,
)
from .graph import run_orchestrator, _parse_mapping_csv
from .state import MappingHint

LOGGER = logging.getLogger(__name__)

# Server configuration (set via get_mcp_server)
_server_host: str = "127.0.0.1"
_server_port: int = 8000

# Path mappings for Docker volume translation
# Maps host paths to container paths
_path_mappings: list[tuple[str, str]] = []


def _init_path_mappings() -> None:
    """Initialize path mappings from environment variables."""
    import os
    
    global _path_mappings
    _path_mappings = []
    
    # JEE_HOST_MOUNT -> /data/jee-projects
    jee_host = os.environ.get("JEE_HOST_MOUNT")
    if jee_host:
        _path_mappings.append((jee_host.rstrip("/"), "/data/jee-projects"))
        LOGGER.info("Path mapping: %s -> /data/jee-projects", jee_host)
    
    # OUTPUT_HOST_MOUNT -> /data/output
    output_host = os.environ.get("OUTPUT_HOST_MOUNT")
    if output_host:
        _path_mappings.append((output_host.rstrip("/"), "/data/output"))
        LOGGER.info("Path mapping: %s -> /data/output", output_host)


def _translate_path(path: str) -> str:
    """Translate host path to container path if mapping exists.
    
    Args:
        path: Path from client (could be host path or container path)
        
    Returns:
        Translated container path
    """
    if not _path_mappings:
        _init_path_mappings()
    
    for host_prefix, container_prefix in _path_mappings:
        if path.startswith(host_prefix):
            translated = path.replace(host_prefix, container_prefix, 1)
            LOGGER.debug("Path translated: %s -> %s", path, translated)
            return translated
    
    return path


# Contract cache with TTL
_contract_cache: dict[str, CachedContract] = {}
_cache_ttl_minutes: int = 30
_cache_stats = {"hits": 0, "misses": 0}

# Active migrations for progress tracking
_active_migrations: dict[str, MigrationProgress] = {}

# Module-level FastMCP instance for decorators
# Will be reconfigured with host/port by get_mcp_server()
mcp = FastMCP(
    name="jee-codegen-orchestrator",
    instructions="Orchestrates JEE to Quarkus migration with hexagonal architecture. "
                "Use migrate_facade_method to migrate EJB facades, list_facades to discover facades, "
                "and validate_mapping_csv to check field mapping files.",
)


def _get_cache_key(project_path: str, facade_name: str) -> str:
    """Generate cache key for contract."""
    return f"{project_path}::{facade_name}"


def _get_cached_contract(project_path: str, facade_name: str) -> dict[str, Any] | None:
    """Get contract from cache if valid."""
    key = _get_cache_key(project_path, facade_name)
    cached = _contract_cache.get(key)
    
    if cached and not cached.is_expired():
        _cache_stats["hits"] += 1
        LOGGER.debug("Cache hit for %s", key)
        return cached.contract_data
    
    if cached:
        del _contract_cache[key]
    
    _cache_stats["misses"] += 1
    return None


def _set_cached_contract(project_path: str, facade_name: str, contract_data: dict[str, Any]) -> None:
    """Store contract in cache."""
    key = _get_cache_key(project_path, facade_name)
    now = datetime.now()
    
    _contract_cache[key] = CachedContract(
        project_path=project_path,
        facade_name=facade_name,
        contract_data=contract_data,
        scanned_at=now,
        expires_at=now + timedelta(minutes=_cache_ttl_minutes),
    )
    LOGGER.debug("Cached contract for %s (expires in %d min)", key, _cache_ttl_minutes)


def _convert_mapping_hints(hints: list[MappingHintInput]) -> list[MappingHint]:
    """Convert MCP mapping hints to internal format."""
    return [
        {
            "objeto_origen": h.source_object,
            "objeto_destino": h.target_object,
            "campo_origen": h.source_field,
            "campo_destino": h.target_field,
        }
        for h in hints
    ]


async def _report_progress(
    ctx: Context,
    run_id: str,
    status: MigrationStatus,
    step_name: str,
    step_number: int,
    total_steps: int,
    message: str,
    details: dict[str, Any] | None = None,
) -> None:
    """Report progress via MCP progress notification."""
    progress = MigrationProgress(
        run_id=run_id,
        status=status,
        step_name=step_name,
        step_number=step_number,
        total_steps=total_steps,
        message=message,
        details=details or {},
    )
    _active_migrations[run_id] = progress
    
    # Report progress to MCP client
    try:
        await ctx.report_progress(
            progress=float(step_number),
            total=float(total_steps),
            message=f"{step_name}: {message}",
        )
    except Exception:
        # Progress reporting is optional, don't fail if not supported
        pass
    
    LOGGER.info("[%s] Step %d/%d: %s - %s", run_id[:8], step_number, total_steps, step_name, message)


@mcp.tool()
async def migrate_facade_method(
    ctx: Context,
    project_path: str,
    facade_name: str,
    output_dir: str,
    method_name: str | None = None,
    base_package: str = "com.davivienda",
    max_fix_attempts: int = 3,
    mapping_hints: list[dict] | None = None,
    oas_fragments: list[dict] | None = None,
    skip_documentation: bool = False,
    generation_hints: str | None = None,
) -> str:
    """Migrate a JEE EJB facade method to Quarkus hexagonal architecture.
    
    This tool orchestrates the complete migration workflow:
    1. Scans the JEE project to extract EJB contracts
    2. Generates functional documentation (optional)
    3. Generates Quarkus code with hexagonal architecture
    4. Compiles and auto-fixes compilation errors
    
    Args:
        project_path: Absolute path to the JEE project root
        facade_name: Name of the EJB facade interface (e.g., 'AdministracionPropuestaFacade')
        output_dir: Absolute path for generated code output
        method_name: Specific method to migrate, or None for all methods
        base_package: Base Java package (e.g., 'com.davivienda')
        max_fix_attempts: Maximum compilation fix attempts (0-10)
        mapping_hints: Optional list of field mappings with keys: ObjetoOrigen, ObjetoDestino, campoOrigen, campoDestino
        oas_fragments: Optional OpenAPI fragments to inject
        skip_documentation: Skip the documentation generation step
        generation_hints: Optional user instructions for code generation (e.g., 'Use exact field names from EJB, no translation')
        
    Returns:
        Migration result summary as markdown
    """
    run_id = str(uuid4())
    started_at = datetime.now()
    total_steps = 4 if skip_documentation else 5
    
    # Translate paths from host to container
    project_path = _translate_path(project_path)
    output_dir = _translate_path(output_dir)
    
    LOGGER.info("Starting migration %s: %s.%s", run_id[:8], facade_name, method_name or "*")
    LOGGER.info("  Project path: %s", project_path)
    LOGGER.info("  Output dir: %s", output_dir)
    
    try:
        # Step 1: Validate inputs
        await _report_progress(ctx, run_id, MigrationStatus.PENDING, "validate", 1, total_steps, "Validating inputs")
        
        if not Path(project_path).exists():
            return MigrationResult(
                run_id=run_id,
                success=False,
                status=MigrationStatus.FAILED,
                facade_name=facade_name,
                method_name=method_name,
                started_at=started_at,
                completed_at=datetime.now(),
                error_message=f"Project path does not exist: {project_path}",
            ).to_summary()
        
        # Convert mapping hints if provided
        internal_hints: list[MappingHint] | None = None
        if mapping_hints:
            try:
                hints = [MappingHintInput(**h) for h in mapping_hints]
                internal_hints = _convert_mapping_hints(hints)
            except Exception as e:
                LOGGER.warning("Invalid mapping hints: %s", e)
        
        # Step 2: Run orchestrator
        step = 2
        await _report_progress(ctx, run_id, MigrationStatus.SCANNING, "scan", step, total_steps, f"Scanning {facade_name}")
        
        # Inject OAS fragments into state if provided
        # TODO: Pass oas_fragments to generator node when implemented
        
        final_state = await run_orchestrator(
            project_path=project_path,
            facade_name=facade_name,
            method_name=method_name,
            output_dir=output_dir,
            base_package=base_package,
            max_fix_attempts=max_fix_attempts,
            mapping_csv_path=None,  # Using mapping_hints directly
            generation_hints=generation_hints,
        )
        
        # Update state with mapping hints if not from CSV
        if internal_hints and not final_state.get("mapping_hints"):
            final_state["mapping_hints"] = internal_hints
        
        completed_at = datetime.now()
        duration = (completed_at - started_at).total_seconds()
        
        # Build result
        generated_files = []
        for f in final_state.get("generated_files", []):
            if isinstance(f, str):
                # Extract layer and type from path
                layer = "infrastructure"
                artifact_type = "unknown"
                if "/domain/" in f:
                    layer = "domain"
                elif "/application/" in f:
                    layer = "application"
                
                if "Entity" in f or "/entity/" in f:
                    artifact_type = "entity"
                elif "Port" in f or "/port/" in f:
                    artifact_type = "port"
                elif "Adapter" in f or "/adapter/" in f:
                    artifact_type = "adapter"
                elif "Mapper" in f:
                    artifact_type = "mapper"
                elif "Request" in f or "Response" in f:
                    artifact_type = "dto"
                
                generated_files.append(GeneratedFileInfo(
                    path=f,
                    layer=layer,
                    artifact_type=artifact_type,
                ))
        
        compile_errors = []
        for err in final_state.get("compile_errors", []):
            if isinstance(err, dict):
                compile_errors.append(CompileError(
                    file_path=err.get("file_path", "unknown"),
                    line=err.get("line"),
                    message=err.get("message", "Unknown error"),
                ))
        
        result = MigrationResult(
            run_id=run_id,
            success=final_state.get("compile_success", False),
            status=MigrationStatus.COMPLETED if final_state.get("compile_success") else MigrationStatus.FAILED,
            facade_name=facade_name,
            method_name=method_name,
            started_at=started_at,
            completed_at=completed_at,
            duration_seconds=duration,
            generated_files=generated_files,
            total_files=len(generated_files),
            compile_success=final_state.get("compile_success", False),
            compile_errors=compile_errors,
            fix_attempts=final_state.get("fix_attempts", 0),
            documentation_generated=final_state.get("documentation") is not None,
            openapi_path=f"{output_dir}/src/main/resources/openapi.json" if generated_files else None,
            error_message=final_state.get("error_message"),
        )
        
        # Cache the contract for future use
        if final_state.get("contract"):
            _set_cached_contract(project_path, facade_name, final_state["contract"])
        
        await _report_progress(
            ctx, run_id,
            MigrationStatus.COMPLETED if result.success else MigrationStatus.FAILED,
            "complete", total_steps, total_steps,
            f"Migration {'succeeded' if result.success else 'failed'}",
            {"total_files": result.total_files},
        )
        
        return result.to_summary()
        
    except Exception as e:
        LOGGER.exception("Migration failed: %s", e)
        return MigrationResult(
            run_id=run_id,
            success=False,
            status=MigrationStatus.FAILED,
            facade_name=facade_name,
            method_name=method_name,
            started_at=started_at,
            completed_at=datetime.now(),
            error_message=str(e),
        ).to_summary()
    finally:
        # Cleanup active migration
        _active_migrations.pop(run_id, None)


@mcp.tool()
async def list_facades(
    ctx: Context,
    project_path: str,
) -> str:
    """List all EJB facades found in a JEE project.
    
    Scans the project to find all EJB interfaces with @Remote or @Local
    annotations and returns their details.
    
    Args:
        project_path: Absolute path to the JEE project root
        
    Returns:
        List of facades with their methods as markdown
    """
    import sys
    sys.path.insert(0, "/app/quarkus-codegen-agent/src")
    
    from quarkus_codegen_agent.mcp_client import McpClient
    
    # Translate path from host to container
    project_path = _translate_path(project_path)
    
    started_at = datetime.now()
    
    try:
        client = McpClient()
        result = await client.scan_project(project_path, detailed_scan=False)
        
        facades = []
        total_methods = 0
        
        for contract in result.contracts:
            methods = [m.name for m in contract.methods]
            total_methods += len(methods)
            
            facades.append(FacadeInfo(
                interface_name=contract.interface_name,
                annotation=contract.annotation,
                file_path=str(contract.file_path),
                method_count=len(methods),
                methods=methods,
                has_manager=contract.related_manager_path is not None,
                manager_path=str(contract.related_manager_path) if contract.related_manager_path else None,
            ))
            
            # Cache each contract
            _set_cached_contract(
                project_path, 
                contract.interface_name,
                contract.model_dump(),
            )
        
        duration = (datetime.now() - started_at).total_seconds()
        
        # Format as markdown
        lines = [
            f"# EJB Facades in {project_path}",
            "",
            f"**Total Facades:** {len(facades)}",
            f"**Total Methods:** {total_methods}",
            f"**Scan Time:** {duration:.2f}s",
            "",
            "---",
            "",
        ]
        
        for facade in facades:
            lines.extend([
                f"## {facade.interface_name}",
                f"- **Annotation:** `{facade.annotation}`",
                f"- **File:** `{facade.file_path}`",
                f"- **Methods:** {facade.method_count}",
            ])
            if facade.has_manager:
                lines.append(f"- **Manager:** `{facade.manager_path}`")
            lines.append("")
            lines.append("### Methods")
            for method in facade.methods:
                lines.append(f"- `{method}()`")
            lines.extend(["", "---", ""])
        
        return "\n".join(lines)
        
    except Exception as e:
        LOGGER.exception("Failed to list facades: %s", e)
        return f"**Error:** Failed to list facades: {e}"


@mcp.tool()
async def validate_mapping_csv(
    ctx: Context,
    csv_path: str,
) -> str:
    """Validate a field mapping CSV file.
    
    Checks that the CSV has the required columns and valid data.
    Required columns: ObjetoOrigen, ObjetoDestino, campoOrigen, campoDestino
    
    Args:
        csv_path: Path to the CSV file to validate
        
    Returns:
        Validation result as markdown
    """
    # Translate path from host to container
    csv_path = _translate_path(csv_path)
    
    errors = []
    warnings = []
    
    if not Path(csv_path).exists():
        return ValidationResult(
            valid=False,
            errors=[f"File not found: {csv_path}"],
        ).model_dump_json(indent=2)
    
    try:
        hints = _parse_mapping_csv(csv_path)
        
        if not hints:
            errors.append("No valid mapping hints found in CSV")
        
        # Check for common issues
        seen_mappings = set()
        for hint in hints:
            key = (hint["objeto_origen"], hint["campo_origen"])
            if key in seen_mappings:
                warnings.append(f"Duplicate source mapping: {hint['objeto_origen']}.{hint['campo_origen']}")
            seen_mappings.add(key)
            
            # Check field depth
            for field in [hint["campo_origen"], hint["campo_destino"]]:
                depth = field.count(".") + 1
                if depth > 3:
                    warnings.append(f"Field path exceeds max depth (3): {field}")
        
        result = ValidationResult(
            valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
        )
        
        # Format as markdown
        lines = [
            "# CSV Validation Result",
            "",
            f"**File:** `{csv_path}`",
            f"**Valid:** {'✅ Yes' if result.valid else '❌ No'}",
            f"**Mappings Found:** {len(hints)}",
            "",
        ]
        
        if errors:
            lines.extend(["## Errors", ""])
            for err in errors:
                lines.append(f"- ❌ {err}")
            lines.append("")
        
        if warnings:
            lines.extend(["## Warnings", ""])
            for warn in warnings:
                lines.append(f"- ⚠️ {warn}")
            lines.append("")
        
        if hints:
            lines.extend([
                "## Mappings Preview",
                "",
                "| Source Object | Source Field | Target Object | Target Field |",
                "|---------------|--------------|---------------|--------------|",
            ])
            for h in hints[:10]:
                lines.append(f"| {h['objeto_origen']} | {h['campo_origen']} | {h['objeto_destino']} | {h['campo_destino']} |")
            if len(hints) > 10:
                lines.append(f"| ... | ... | ... | ... |")
                lines.append(f"*({len(hints) - 10} more rows)*")
        
        return "\n".join(lines)
        
    except Exception as e:
        return f"**Error:** Failed to validate CSV: {e}"


@mcp.tool()
async def get_cache_stats(ctx: Context) -> str:
    """Get statistics about the contract cache.
    
    Returns cache hit/miss rates and entry information.
    
    Returns:
        Cache statistics as markdown
    """
    total = _cache_stats["hits"] + _cache_stats["misses"]
    hit_rate = _cache_stats["hits"] / total if total > 0 else 0
    
    oldest = None
    newest = None
    for cached in _contract_cache.values():
        if oldest is None or cached.scanned_at < oldest:
            oldest = cached.scanned_at
        if newest is None or cached.scanned_at > newest:
            newest = cached.scanned_at
    
    stats = CacheStats(
        total_entries=len(_contract_cache),
        hit_count=_cache_stats["hits"],
        miss_count=_cache_stats["misses"],
        hit_rate=hit_rate,
        oldest_entry=oldest,
        newest_entry=newest,
    )
    
    lines = [
        "# Contract Cache Statistics",
        "",
        f"**Entries:** {stats.total_entries}",
        f"**Hit Rate:** {stats.hit_rate:.1%}",
        f"**Hits:** {stats.hit_count}",
        f"**Misses:** {stats.miss_count}",
        f"**TTL:** {_cache_ttl_minutes} minutes",
        "",
    ]
    
    if _contract_cache:
        lines.extend([
            "## Cached Contracts",
            "",
            "| Facade | Project | Scanned | Expires |",
            "|--------|---------|---------|---------|",
        ])
        for cached in _contract_cache.values():
            lines.append(
                f"| {cached.facade_name} | ...{cached.project_path[-30:]} | "
                f"{cached.scanned_at.strftime('%H:%M:%S')} | "
                f"{cached.expires_at.strftime('%H:%M:%S')} |"
            )
    
    return "\n".join(lines)


@mcp.tool()
async def clear_cache(ctx: Context) -> str:
    """Clear the contract cache.
    
    Removes all cached EJB contracts, forcing fresh scans on next use.
    
    Returns:
        Confirmation message
    """
    count = len(_contract_cache)
    _contract_cache.clear()
    _cache_stats["hits"] = 0
    _cache_stats["misses"] = 0
    
    return f"✅ Cleared {count} cached contracts"


@mcp.tool()
async def get_migration_status(
    ctx: Context,
    run_id: str,
) -> str:
    """Get the status of an active or recent migration.
    
    Args:
        run_id: The migration run ID
        
    Returns:
        Migration status as markdown
    """
    progress = _active_migrations.get(run_id)
    
    if not progress:
        return f"**Not Found:** Migration `{run_id}` not found or already completed"
    
    return f"""# Migration Status: {run_id[:8]}

**Status:** {progress.status.value}
**Step:** {progress.step_name} ({progress.step_number}/{progress.total_steps})
**Message:** {progress.message}
**Updated:** {progress.timestamp.strftime('%H:%M:%S')}
"""


# MCP Resource for migration status
@mcp.resource("migration://status/{run_id}")
async def migration_status_resource(run_id: str) -> str:
    """Resource providing real-time migration status."""
    progress = _active_migrations.get(run_id)
    
    if not progress:
        return f"Migration {run_id} not found"
    
    return progress.model_dump_json(indent=2)


# Export for main.py
def get_mcp_server(host: str | None = None, port: int | None = None) -> FastMCP:
    """Get the configured MCP server instance.
    
    Reconfigures the module-level server with host/port settings.
    The server was already initialized with tools via decorators.
    
    Args:
        host: Server host (default: 127.0.0.1)
        port: Server port (default: 8000)
        
    Returns:
        Configured FastMCP instance
    """
    global mcp, _server_host, _server_port
    
    # Update configuration if provided
    if host is not None:
        _server_host = host
    if port is not None:
        _server_port = port
    
    # FastMCP uses pydantic-settings, so we need to update the settings object
    # The settings are accessed via mcp.settings
    if hasattr(mcp, 'settings'):
        mcp.settings.host = _server_host
        mcp.settings.port = _server_port
        LOGGER.info("Configured MCP server at %s:%d", _server_host, _server_port)
    
    return mcp
