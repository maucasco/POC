"""State definitions for the LangGraph orchestrator."""

from typing import TypedDict, Optional, List
from dataclasses import dataclass, field


class MappingHint(TypedDict):
    """A single field mapping hint from CSV."""
    objeto_origen: str      # e.g., ParametrosInserccionTO
    objeto_destino: str     # e.g., PreliquidacionRequest
    campo_origen: str       # e.g., liquidacionConsumoVO.valorTotal (supports depth 3)
    campo_destino: str      # e.g., valorTotal


class OrchestratorState(TypedDict, total=False):
    """Shared state for the orchestration graph."""
    
    # Input parameters
    project_path: str
    facade_name: str
    method_name: Optional[str]
    output_dir: str
    base_package: str
    
    # Mapping hints from CSV (optional)
    mapping_csv_path: Optional[str]
    mapping_hints: Optional[List[MappingHint]]
    
    # User-provided generation instructions (optional)
    generation_hints: Optional[str]
    
    # MCP Scanner results
    contract: Optional[dict]
    method: Optional[dict]
    
    # Documentation results
    documentation: Optional[str]
    
    # Code generation results
    generated_files: List[str]
    
    # Compilation results
    compile_success: bool
    compile_errors: List[str]
    
    # Fix loop control
    fix_attempts: int
    max_fix_attempts: int
    
    # Status tracking
    current_step: str
    error_message: Optional[str]


@dataclass
class CompileError:
    """Represents a compilation error."""
    file_path: str
    line: int
    column: int
    message: str
    error_type: str  # error, warning
    
    @classmethod
    def from_maven_line(cls, line: str, base_dir: str) -> Optional["CompileError"]:
        """Parse a Maven compiler error line.
        
        Example format:
        [ERROR] /path/to/File.java:[10,15] error message
        """
        import re
        
        # Pattern: [ERROR] /path/to/file.java:[line,col] message
        pattern = r'\[(ERROR|WARNING)\]\s+(.+?\.java):\[(\d+),(\d+)\]\s+(.+)'
        match = re.match(pattern, line.strip())
        
        if match:
            error_type = match.group(1).lower()
            file_path = match.group(2)
            line_num = int(match.group(3))
            col = int(match.group(4))
            message = match.group(5)
            
            return cls(
                file_path=file_path,
                line=line_num,
                column=col,
                message=message,
                error_type=error_type
            )
        
        return None


@dataclass
class FixResult:
    """Result of a code fix attempt."""
    success: bool
    fixed_files: List[str] = field(default_factory=list)
    remaining_errors: List[CompileError] = field(default_factory=list)
    fix_description: str = ""
