"""Pydantic models for MCP server input/output."""
from __future__ import annotations

from datetime import datetime, timedelta
from enum import Enum
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field


class MigrationStatus(str, Enum):
    """Status of a migration run."""
    
    PENDING = "pending"
    SCANNING = "scanning"
    DOCUMENTING = "documenting"
    GENERATING = "generating"
    COMPILING = "compiling"
    FIXING = "fixing"
    COMPLETED = "completed"
    FAILED = "failed"


class OasFragment(BaseModel):
    """OpenAPI fragment to inject into generation.
    
    Use this to provide pre-defined OAS schemas that the generator
    should respect when creating DTOs and endpoints.
    """
    
    path: str | None = Field(
        default=None,
        description="API path pattern (e.g., '/api/v1/propuestas')",
    )
    operation_id: str | None = Field(
        default=None,
        description="OperationId to assign to the endpoint",
    )
    schema_name: str | None = Field(
        default=None,
        description="Name of the schema (e.g., 'PropuestaRequest')",
    )
    schema_definition: dict[str, Any] | None = Field(
        default=None,
        description="OpenAPI schema definition as JSON object",
    )
    tags: list[str] = Field(
        default_factory=list,
        description="Tags for the operation",
    )
    summary: str | None = Field(
        default=None,
        description="Summary for the OpenAPI operation",
    )


class MappingHintInput(BaseModel):
    """Field mapping hint for DTO transformation."""
    
    source_object: str = Field(
        ...,
        alias="ObjetoOrigen",
        description="Source DTO/VO class name",
    )
    target_object: str = Field(
        ...,
        alias="ObjetoDestino", 
        description="Target Request/Response class name",
    )
    source_field: str = Field(
        ...,
        alias="campoOrigen",
        description="Source field path (supports dot notation up to 3 levels)",
    )
    target_field: str = Field(
        ...,
        alias="campoDestino",
        description="Target field path",
    )
    
    model_config = {"populate_by_name": True}


class MigrationRequest(BaseModel):
    """Request to migrate a JEE facade method to Quarkus."""
    
    project_path: str = Field(
        ...,
        description="Absolute path to the JEE project root",
    )
    facade_name: str = Field(
        ...,
        description="Name of the EJB facade interface (e.g., 'AdministracionPropuestaFacade')",
    )
    method_name: str | None = Field(
        default=None,
        description="Specific method to migrate. If None, migrates all methods.",
    )
    output_dir: str = Field(
        default="/data/output",
        description="Output directory for generated Quarkus code",
    )
    base_package: str = Field(
        default="com.davivienda",
        description="Base Java package for generated code",
    )
    max_fix_attempts: int = Field(
        default=3,
        ge=0,
        le=10,
        description="Maximum compilation fix attempts (0-10)",
    )
    mapping_hints: list[MappingHintInput] = Field(
        default_factory=list,
        description="Optional field mapping hints for DTO transformation",
    )
    oas_fragments: list[OasFragment] = Field(
        default_factory=list,
        description="Optional OpenAPI fragments to inject",
    )
    skip_documentation: bool = Field(
        default=False,
        description="Skip LLM documentation generation step",
    )


class CompileError(BaseModel):
    """A compilation error from Maven."""
    
    file_path: str
    line: int | None = None
    column: int | None = None
    message: str
    error_type: str | None = None


class GeneratedFileInfo(BaseModel):
    """Information about a generated file."""
    
    path: str
    layer: str = Field(description="Hexagonal layer: domain, application, infrastructure")
    artifact_type: str = Field(description="Type: entity, port, adapter, dto, mapper, etc.")
    lines: int = Field(default=0)


class MigrationProgress(BaseModel):
    """Progress update during migration."""
    
    run_id: str
    status: MigrationStatus
    step_name: str
    step_number: int
    total_steps: int
    message: str
    timestamp: datetime = Field(default_factory=datetime.now)
    details: dict[str, Any] = Field(default_factory=dict)


class MigrationResult(BaseModel):
    """Result of a migration run."""
    
    run_id: str = Field(default_factory=lambda: str(uuid4()))
    success: bool
    status: MigrationStatus
    facade_name: str
    method_name: str | None = None
    
    # Timing
    started_at: datetime
    completed_at: datetime | None = None
    duration_seconds: float | None = None
    
    # Results
    generated_files: list[GeneratedFileInfo] = Field(default_factory=list)
    total_files: int = 0
    
    # Compilation
    compile_success: bool = False
    compile_errors: list[CompileError] = Field(default_factory=list)
    fix_attempts: int = 0
    
    # Documentation
    documentation_generated: bool = False
    documentation_path: str | None = None
    
    # OpenAPI
    openapi_path: str | None = None
    
    # Errors
    error_message: str | None = None
    
    def to_summary(self) -> str:
        """Generate human-readable summary."""
        lines = [
            f"## Migration Result: {self.facade_name}",
            f"**Status:** {'✅ Success' if self.success else '❌ Failed'}",
            f"**Method:** {self.method_name or 'all methods'}",
        ]
        
        if self.duration_seconds:
            lines.append(f"**Duration:** {self.duration_seconds:.1f}s")
        
        lines.append(f"**Files Generated:** {self.total_files}")
        
        if self.compile_success:
            lines.append("**Compilation:** ✅ Passed")
        else:
            lines.append(f"**Compilation:** ❌ Failed ({len(self.compile_errors)} errors)")
            if self.fix_attempts > 0:
                lines.append(f"**Fix Attempts:** {self.fix_attempts}")
        
        if self.error_message:
            lines.append(f"\n**Error:** {self.error_message}")
        
        return "\n".join(lines)


class FacadeInfo(BaseModel):
    """Information about an EJB facade found in the project."""
    
    interface_name: str
    annotation: str
    file_path: str
    method_count: int
    methods: list[str]
    has_manager: bool
    manager_path: str | None = None


class ListFacadesResult(BaseModel):
    """Result of listing facades in a project."""
    
    project_path: str
    facades: list[FacadeInfo]
    total_methods: int
    scan_time_seconds: float


class ValidationResult(BaseModel):
    """Result of validating input data."""
    
    valid: bool
    errors: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


# Cache models

class CachedContract(BaseModel):
    """Cached EJB contract for a project."""
    
    project_path: str
    facade_name: str
    contract_data: dict[str, Any]
    scanned_at: datetime
    expires_at: datetime
    
    def is_expired(self) -> bool:
        """Check if cache entry has expired."""
        return datetime.now() > self.expires_at


class CacheStats(BaseModel):
    """Statistics about the contract cache."""
    
    total_entries: int
    hit_count: int
    miss_count: int
    hit_rate: float
    oldest_entry: datetime | None = None
    newest_entry: datetime | None = None
