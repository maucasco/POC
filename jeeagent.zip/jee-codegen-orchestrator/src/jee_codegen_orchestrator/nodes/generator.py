"""Generator node - Uses quarkus-codegen-agent to generate Quarkus code."""

import logging
import re
import sys
from pathlib import Path
from typing import Any, List

from ..config import get_settings

# Add quarkus-codegen-agent to path for reusing components
# Use settings to get the correct path (Docker vs host)
_settings = get_settings()
sys.path.insert(0, f"{_settings.quarkus_codegen_path}/src")

from quarkus_codegen_agent.code_generator import CodeGenerator
from quarkus_codegen_agent.file_writer import FileWriter
from quarkus_codegen_agent.code_merger import ContextScanner
from quarkus_codegen_agent.models import (
    DtoDefinition,
    DtoField,
    MethodParameter,
    MethodSignature,
)

from ..state import OrchestratorState

LOGGER = logging.getLogger(__name__)


def _get_pom_template(base_package: str, quarkus_version: str = "3.17.0") -> str:
    """Get POM template content for Quarkus project.
    
    Args:
        base_package: Base Java package (e.g., com.davivienda.anticorruption)
        quarkus_version: Quarkus platform version
        
    Returns:
        Complete pom.xml content
    """
    group_id = ".".join(base_package.split(".")[:3])
    artifact_id = base_package.split(".")[-1]

    return f'''<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>{group_id}</groupId>
    <artifactId>{artifact_id}</artifactId>
    <version>1.0.0-SNAPSHOT</version>
    <packaging>jar</packaging>

    <name>{artifact_id} - Anti-Corruption Layer</name>
    <description>Quarkus reactive anti-corruption layer for JEE EJB integration</description>

    <properties>
        <maven.compiler.source>21</maven.compiler.source>
        <maven.compiler.target>21</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <quarkus.platform.version>{quarkus_version}</quarkus.platform.version>
    </properties>

    <dependencyManagement>
        <dependencies>
            <dependency>
                <groupId>io.quarkus.platform</groupId>
                <artifactId>quarkus-bom</artifactId>
                <version>${{quarkus.platform.version}}</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
        </dependencies>
    </dependencyManagement>

    <dependencies>
        <!-- Quarkus REST (Reactive) -->
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-rest-jackson</artifactId>
        </dependency>

        <!-- Mutiny (Reactive) -->
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-mutiny</artifactId>
        </dependency>

        <!-- OpenAPI -->
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-smallrye-openapi</artifactId>
        </dependency>

        <!-- Health Check -->
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-smallrye-health</artifactId>
        </dependency>

        <!-- Arc (CDI) -->
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-arc</artifactId>
        </dependency>

        <!-- JUnit5 with Mockito for Quarkus -->
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-junit5-mockito</artifactId>
            <scope>test</scope>
        </dependency>

        <!-- Testing -->
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-junit5</artifactId>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>io.rest-assured</groupId>
            <artifactId>rest-assured</artifactId>
            <scope>test</scope>
        </dependency>
        
        <!-- AssertJ for fluent assertions -->
        <dependency>
            <groupId>org.assertj</groupId>
            <artifactId>assertj-core</artifactId>
            <version>3.24.2</version>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>io.quarkus.platform</groupId>
                <artifactId>quarkus-maven-plugin</artifactId>
                <version>${{quarkus.platform.version}}</version>
                <executions>
                    <execution>
                        <goals>
                            <goal>build</goal>
                            <goal>generate-code</goal>
                        </goals>
                    </execution>
                </executions>
            </plugin>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.12.1</version>
                <configuration>
                    <compilerArgs>
                        <arg>-parameters</arg>
                    </compilerArgs>
                </configuration>
            </plugin>
        </plugins>
    </build>
</project>
'''


def _get_test_application_properties() -> str:
    """Get test application.properties content.
    
    Returns:
        Content for src/test/resources/application.properties
    """
    return """# Test configuration for Quarkus
quarkus.log.level=INFO
quarkus.log.category."com.davivienda".level=DEBUG

# Disable banner in tests
quarkus.banner.enabled=false

# RMI/WebLogic mock configuration (placeholders for tests)
weblogic.jndi.url=t3://localhost:7001
weblogic.jndi.principal=weblogic
weblogic.jndi.credentials=welcome1

# EJB JNDI names (override in specific tests if needed)
# Example: preliquidacion.ejb.jndi.name=ejb/PreliquidacionFacadeRemote
"""


def _filter_mapping_hints_for_method(
    all_hints: list[dict] | None, 
    method: "MethodSignature"
) -> list[dict]:
    """Filter mapping hints relevant to the types used in a method.
    
    Args:
        all_hints: All mapping hints from CSV
        method: Method signature with parameters and return type
        
    Returns:
        Filtered hints that match types in the method's parameters or return
    """
    if not all_hints:
        return []
    
    # Collect type names from the method (parameters and return)
    relevant_types: set[str] = set()
    
    # Parameter types
    for param in method.parameters:
        # Extract base type name (remove generics, arrays)
        type_name = param.type_hint.replace("[]", "").split("<")[0].strip()
        if type_name:
            relevant_types.add(type_name)
        # Also add DTO name if available
        if param.dto:
            relevant_types.add(param.dto.name)
    
    # Return type
    if method.return_type and method.return_type != "void":
        ret_type = method.return_type.replace("[]", "").split("<")[0].strip()
        if ret_type:
            relevant_types.add(ret_type)
    
    # Also include Request/Response DTOs by convention
    method_pascal = method.name[0].upper() + method.name[1:]
    relevant_types.add(f"{method_pascal}Request")
    relevant_types.add(f"{method_pascal}Response")
    
    LOGGER.debug("Relevant types for method %s: %s", method.name, relevant_types)
    
    # Filter hints where ObjetoOrigen or ObjetoDestino matches
    filtered = [
        hint for hint in all_hints
        if hint.get('objeto_origen') in relevant_types 
        or hint.get('objeto_destino') in relevant_types
    ]
    
    if filtered:
        LOGGER.info("Found %d mapping hints for method %s", len(filtered), method.name)
    
    return filtered


def _convert_dto_from_dict(dto_dict: dict[str, Any] | None) -> DtoDefinition | None:
    """Convert a DTO dictionary back to DtoDefinition model.
    
    Recursively converts nested DTOs as well.
    """
    if dto_dict is None:
        return None
    
    fields = []
    for field_dict in dto_dict.get("fields", []):
        nested_dto = _convert_dto_from_dict(field_dict.get("nested_dto"))
        fields.append(DtoField(
            name=field_dict.get("name", ""),
            type_hint=field_dict.get("type_hint", ""),
            nested_dto=nested_dto,
        ))
    
    return DtoDefinition(
        name=dto_dict.get("name", ""),
        file_path=dto_dict.get("file_path"),
        fields=fields,
    )


def _convert_method_from_dict(method_dict: dict) -> MethodSignature:
    """Convert a method dictionary back to MethodSignature model."""
    parameters = []
    for p in method_dict.get("parameters", []):
        # Validate type before using .get()
        if not isinstance(p, dict):
            LOGGER.warning("Skipping invalid parameter (not a dict): %s", p)
            continue
            
        # Convert dto structure if present
        dto = _convert_dto_from_dict(p.get("dto"))
        
        parameters.append(MethodParameter(
            name=p.get("name", ""),
            type_hint=p.get("type_hint", ""),
            dto=dto,
            dto_fields=p.get("dto_fields"),
        ))
    
    return MethodSignature(
        name=method_dict.get("name", ""),
        return_type=method_dict.get("return_type", "void"),
        parameters=parameters,
        documentation=method_dict.get("documentation"),
        manager_summary=method_dict.get("manager_summary"),
    )


async def generate_code(state: OrchestratorState) -> OrchestratorState:
    """Generate Quarkus hexagonal code from the scanned contract.
    
    This node uses the CodeGenerator from quarkus-codegen-agent to create
    all the hexagonal architecture components.
    """
    LOGGER.info("=== GENERATE NODE ===")
    
    contract = state.get("contract")
    method_dict = state.get("method")
    output_dir = state.get("output_dir", "/data/output")
    base_package = state.get("base_package", "com.davivienda")
    
    if not contract:
        LOGGER.error("No contract available for code generation")
        return {
            **state,
            "current_step": "generate_failed",
            "error_message": "No contract available for code generation",
        }
    
    facade_name = contract.get("interface_name", "").replace("Facade", "")
    
    # Determine which methods to generate
    methods_to_generate = []
    if method_dict:
        methods_to_generate = [method_dict]
    else:
        methods_to_generate = contract.get("methods", [])
    
    if not methods_to_generate:
        LOGGER.error("No methods to generate code for")
        return {
            **state,
            "current_step": "generate_failed",
            "error_message": "No methods found to generate code for",
        }
    
    try:
        generator = CodeGenerator(base_package=base_package)
        writer = FileWriter(output_dir=output_dir, base_package=base_package)
        
        # CRITICAL: Scan existing project structure BEFORE generation
        # This prevents PATTERN_001 (incorrect imports) and PATTERN_002 (contextual amnesia)
        scanner = ContextScanner(Path(output_dir), base_package)
        generation_context = scanner.scan()
        LOGGER.info("Project structure scanned: %d existing DTOs, %d Mappers, %d VOs",
                    len(generation_context.existing_dtos),
                    len(generation_context.existing_mappers),
                    len(generation_context.existing_vos))
        
        # Generate pom.xml if it doesn't exist
        pom_path = Path(output_dir) / "pom.xml"
        if not pom_path.exists():
            pom_content = _get_pom_template(base_package)
            pom_path.parent.mkdir(parents=True, exist_ok=True)
            pom_path.write_text(pom_content, encoding="utf-8")
            LOGGER.info("Created pom.xml at: %s", pom_path)
        else:
            LOGGER.info("pom.xml already exists, skipping: %s", pom_path)
        
        # Generate test application.properties if it doesn't exist
        test_props_path = Path(output_dir) / "src" / "test" / "resources" / "application.properties"
        if not test_props_path.exists():
            test_props_content = _get_test_application_properties()
            test_props_path.parent.mkdir(parents=True, exist_ok=True)
            test_props_path.write_text(test_props_content, encoding="utf-8")
            LOGGER.info("Created test application.properties at: %s", test_props_path)
        else:
            LOGGER.info("test application.properties already exists, skipping: %s", test_props_path)
        
        # Get mapping hints from state (optional)
        all_mapping_hints = state.get("mapping_hints")
        
        generated_files: List[str] = []
        
        for method_dict in methods_to_generate:
            method = _convert_method_from_dict(method_dict)
            
            # Filter mapping hints relevant to this method's types
            method_hints = _filter_mapping_hints_for_method(all_mapping_hints, method)
            
            LOGGER.info("Generating code for method: %s.%s", facade_name, method.name)
            
            # Generate all components for this method
            result = await generator.generate_for_method(
                method=method,
                facade_name=facade_name,
                output_dir=output_dir,
                generate_tests=True,
                generate_openapi=True,
                separate_files=False,
                skip_existing_dtos=True,
                mapping_hints=method_hints if method_hints else None,
                generation_hints=state.get("generation_hints"),
            )
            
            # Log generation decisions for debugging
            decision_log = generator.get_decision_log()
            if decision_log:
                LOGGER.info("=" * 60)
                LOGGER.info("GENERATION DECISIONS FOR: %s.%s", facade_name, method.name)
                LOGGER.info("=" * 60)
                for decision in decision_log:
                    LOGGER.info(decision)
                LOGGER.info("=" * 60)
                generator.clear_decision_log()
            
            # Write generated files using FileWriter
            files_written = _write_generated_files(writer, result, facade_name, method.name)
            generated_files.extend(files_written)
            
            # CRITICAL: Validate generated code for common errors
            validation_errors = []
            
            # Validate imports (PATTERN_001)
            if result.service_content:
                import_errors = generator.validate_imports(result.service_content, generation_context)
                validation_errors.extend([f"Service: {err}" for err in import_errors])
            
            if result.rmi_adapter_content:
                import_errors = generator.validate_imports(result.rmi_adapter_content, generation_context)
                validation_errors.extend([f"RmiAdapter: {err}" for err in import_errors])
            
            # Validate Port/Adapter contract (PATTERN_004)
            if result.rmi_adapter_content and result.rmi_port_content:
                contract_errors = generator.validate_contract(
                    result.rmi_adapter_content,
                    result.rmi_port_content,
                    f"{facade_name}RmiAdapter"
                )
                validation_errors.extend([f"Contract: {err}" for err in contract_errors])
            
            # Validate OAS schemas (PATTERN_006)
            if result.openapi_json:
                oas_errors = generator.validate_oas_schema(result.openapi_json)
                validation_errors.extend([f"OAS: {err}" for err in oas_errors])
            
            # Log validation results
            if validation_errors:
                LOGGER.warning("=" * 60)
                LOGGER.warning("VALIDATION WARNINGS FOR: %s.%s", facade_name, method.name)
                LOGGER.warning("=" * 60)
                for error in validation_errors:
                    LOGGER.warning("⚠️  %s", error)
                LOGGER.warning("=" * 60)
                LOGGER.warning("Generated code may have issues. Review warnings above.")
            else:
                LOGGER.info("✅ Validation passed for: %s.%s", facade_name, method.name)
            
            LOGGER.info("Generated %d files for method: %s", len(files_written), method.name)
        
        # Save documentation if available (with merge support)
        documentation = state.get("documentation")
        if documentation:
            doc_path = Path(output_dir) / "docs" / f"{facade_name}_documentation.md"
            doc_path.parent.mkdir(parents=True, exist_ok=True)
            
            if doc_path.exists():
                # Merge with existing documentation
                existing_content = doc_path.read_text(encoding="utf-8")
                merged_content = _merge_documentation(existing_content, documentation, method.name if method_dict else None)
                doc_path.write_text(merged_content, encoding="utf-8")
                LOGGER.info("Merged documentation into: %s", doc_path)
            else:
                doc_path.write_text(documentation, encoding="utf-8")
                LOGGER.info("Created documentation: %s", doc_path)
            
            generated_files.append(str(doc_path))
        
        return {
            **state,
            "generated_files": generated_files,
            "current_step": "generated",
        }
        
    except Exception as e:
        LOGGER.exception("Error generating code")
        return {
            **state,
            "current_step": "generate_failed",
            "error_message": str(e),
        }


def _write_generated_files(
    writer: FileWriter, 
    result, 
    facade_name: str, 
    method_name: str
) -> List[str]:
    """Write generated files to disk and return list of paths."""
    from quarkus_codegen_agent.code_merger import CodeMerger
    from quarkus_codegen_agent.models import GeneratedFile
    
    written_files = []
    output_dir = writer.output_dir
    base_package = writer.base_package
    
    merger = CodeMerger(str(output_dir), base_package)
    
    # Collect files to write
    files_to_write = []
    
    # Write Request DTO
    if result.request_dto:
        files_to_write.append(result.request_dto)
    
    # Write Response DTO
    if result.response_dto:
        files_to_write.append(result.response_dto)
    
    # Write EJB models
    for model in result.ejb_models:
        files_to_write.append(model)
    
    # Write EJB Facade interface (with merge support)
    if result.ejb_facade_interface:
        path = merger.write_or_merge_ejb_facade(
            facade_name, result.ejb_facade_interface.content, method_name
        )
        if path:
            written_files.append(str(path))
    
    # Write Mapper Test
    if result.mapper_test:
        # Use test writer
        test_writer = FileWriter(output_dir=str(output_dir), base_package=base_package, is_test=True)
        created, _ = test_writer.write_files([result.mapper_test])
        if created > 0:
            test_path = test_writer._resolve_path(result.mapper_test)
            written_files.append(str(test_path))
    
    # Write all collected files
    if files_to_write:
        created, _ = writer.write_files(files_to_write)
        for f in files_to_write:
            path = writer._resolve_path(f)
            if path.exists():
                written_files.append(str(path))
    
    # Merge UseCase
    if result.use_case_content:
        path = merger.write_or_merge(facade_name, "use_case", result.use_case_content, method_name)
        if path:
            written_files.append(str(path))
    
    # Merge RmiPort
    if result.rmi_port_content:
        path = merger.write_or_merge(facade_name, "rmi_port", result.rmi_port_content, method_name)
        if path:
            written_files.append(str(path))
    
    # Merge Service
    if result.service_content:
        path = merger.write_or_merge(facade_name, "service", result.service_content, method_name)
        if path:
            written_files.append(str(path))
    
    # Merge Resource
    if result.resource_content:
        path = merger.write_or_merge(facade_name, "resource", result.resource_content, method_name)
        if path:
            written_files.append(str(path))
    
    # Merge RmiAdapter
    if result.rmi_adapter_content:
        path = merger.write_or_merge(facade_name, "rmi_adapter", result.rmi_adapter_content, method_name)
        if path:
            written_files.append(str(path))
    
    # Merge Service Test
    if result.service_test_content:
        path = merger.write_or_merge(facade_name, "service_test", result.service_test_content, method_name, is_test=True)
        if path:
            written_files.append(str(path))
    
    # Merge Resource Test
    if result.resource_test_content:
        path = merger.write_or_merge(facade_name, "resource_test", result.resource_test_content, method_name, is_test=True)
        if path:
            written_files.append(str(path))
    
    # Write Mapper as a GeneratedFile
    if result.mapper_content:
        method_pascal = method_name[0].upper() + method_name[1:]
        mapper_file = GeneratedFile(
            file_path=Path(f"infrastructure/mapper/{method_pascal}Mapper.java"),
            package_name=f"{base_package}.infrastructure.mapper",
            class_name=f"{method_pascal}Mapper",
            content=result.mapper_content,
            layer="infrastructure",
            component_type="mapper",
        )
        created, _ = writer.write_files([mapper_file])
        if created > 0:
            mapper_path = writer._resolve_path(mapper_file)
            written_files.append(str(mapper_path))
    
    # Write/Merge OpenAPI JSON (consolidated per facade)
    if result.openapi_json:
        openapi_path, was_merged = merger.write_openapi_json(facade_name, method_name, result.openapi_json)
        written_files.append(str(openapi_path))
        if was_merged:
            LOGGER.info("Merged OpenAPI spec for %s.%s into %s", facade_name, method_name, openapi_path)
    
    return written_files


def _merge_documentation(existing_content: str, new_content: str, method_name: str | None = None) -> str:
    """Merge new documentation into existing documentation file.
    
    Args:
        existing_content: Content of the existing markdown file
        new_content: New documentation content to add
        method_name: Name of the method being documented (for duplicate detection)
        
    Returns:
        Merged documentation content
    """
    import re
    
    # Check if the method is already documented
    if method_name:
        # Look for ## InterfaceName.methodName or # InterfaceName.methodName header
        pattern = rf'^#+\s+\S+\.{re.escape(method_name)}\s*$'
        if re.search(pattern, existing_content, re.MULTILINE):
            LOGGER.info("Method %s already documented, skipping merge", method_name)
            return existing_content
    
    # Find the last separator (---) in the existing content
    last_separator_idx = existing_content.rfind('\n---\n')
    
    if last_separator_idx > 0:
        # Insert new content before the last separator
        merged = (
            existing_content[:last_separator_idx] + 
            "\n\n---\n\n" + 
            new_content + 
            existing_content[last_separator_idx:]
        )
    else:
        # No separator found, just append
        merged = existing_content + "\n\n---\n\n" + new_content
    
    return merged
