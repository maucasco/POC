"""Documenter node - Uses jee-doc-agent to generate documentation."""

import logging
import sys
from pathlib import Path

from ..config import get_settings

# Add jee-doc-agent to path for reusing components
_settings = get_settings()
sys.path.insert(0, f"{_settings.jee_doc_agent_path}/src")

from jee_doc_agent.llm_analyzer import LLMAnalyzer
from jee_doc_agent.config import Settings as DocSettings
from jee_doc_agent.models import MethodSignature, MethodParameter, DtoDefinition

from ..state import OrchestratorState

LOGGER = logging.getLogger(__name__)


def _convert_method_from_dict(method_dict: dict) -> MethodSignature:
    """Convert a method dictionary back to MethodSignature model."""
    parameters = []
    for p in method_dict.get("parameters", []):
        # Validate type before using .get()
        if not isinstance(p, dict):
            LOGGER.warning("Skipping invalid parameter (not a dict): %s", p)
            continue
            
        dto = None
        if p.get("dto_fields"):
            dto = DtoDefinition(
                name=p.get("type_hint", ""),
                file_path="",
                fields=[],  # Simplified
            )
        parameters.append(MethodParameter(
            name=p.get("name", ""),
            type_hint=p.get("type_hint", ""),
            dto=dto,
        ))
    
    return MethodSignature(
        name=method_dict.get("name", ""),
        return_type=method_dict.get("return_type", "void"),
        parameters=parameters,
        documentation=method_dict.get("documentation"),
        manager_summary=method_dict.get("manager_summary"),
    )


async def generate_documentation(state: OrchestratorState) -> OrchestratorState:
    """Generate documentation for the scanned method using LLM analysis.
    
    This node uses the LLMAnalyzer from jee-doc-agent to create
    comprehensive functional documentation.
    """
    LOGGER.info("=== DOCUMENT NODE ===")
    
    contract = state.get("contract")
    method_dict = state.get("method")
    
    if not contract:
        LOGGER.error("No contract available for documentation")
        return {
            **state,
            "current_step": "document_failed",
            "error_message": "No contract available for documentation",
        }
    
    # If no specific method, document all methods
    methods_to_document = []
    if method_dict:
        methods_to_document = [method_dict]
    else:
        methods_to_document = contract.get("methods", [])
    
    if not methods_to_document:
        LOGGER.error("No methods to document")
        return {
            **state,
            "current_step": "document_failed",
            "error_message": "No methods found to document",
        }
    
    try:
        # Create settings for the analyzer using orchestrator settings
        settings = get_settings()
        doc_settings = DocSettings(
            llm_provider=settings.llm_provider,
            openai_api_key=settings.openai_api_key,
            openai_model=settings.openai_model,
            anthropic_api_key=settings.anthropic_api_key,
            anthropic_model=settings.anthropic_model,
        )
        
        analyzer = LLMAnalyzer(doc_settings)
        
        all_documentation = []
        
        for method_dict in methods_to_document:
            method = _convert_method_from_dict(method_dict)
            
            LOGGER.info("Generating documentation for method: %s", method.name)
            
            doc = await analyzer.analyze_method(
                method=method,
                interface_name=contract.get("interface_name", ""),
                manager_path=contract.get("related_manager_path"),
            )
            
            # Format documentation as markdown
            doc_md = _format_documentation(doc, contract.get("interface_name", ""))
            all_documentation.append(doc_md)
            
            LOGGER.info("Documentation generated for: %s", method.name)
        
        # Combine all documentation
        full_documentation = "\n\n---\n\n".join(all_documentation)
        
        return {
            **state,
            "documentation": full_documentation,
            "current_step": "documented",
        }
        
    except Exception as e:
        LOGGER.exception("Error generating documentation")
        return {
            **state,
            "current_step": "document_failed",
            "error_message": str(e),
        }


def _format_documentation(doc, interface_name: str) -> str:
    """Format MethodDocumentation as markdown."""
    lines = [
        f"# {interface_name}.{doc.method_name}",
        "",
        "## Descripción Funcional",
        "",
        doc.functional_description,
        "",
        "## Firma del Método",
        "",
        f"```java",
        doc.raw_signature,
        "```",
        "",
    ]
    
    if doc.input_attributes:
        lines.extend([
            "## Atributos de Entrada",
            "",
            "| Campo | Tipo | Requerido | Descripción |",
            "|-------|------|-----------|-------------|",
        ])
        for attr in doc.input_attributes:
            required = "Sí" if attr.get("required", False) else "No"
            name = attr.get("name", "")
            type_hint = attr.get("type", "")
            desc = attr.get("description", "").replace("|", "\\|")
            lines.append(f"| {name} | {type_hint} | {required} | {desc} |")
        lines.append("")
    
    if doc.output_attributes:
        lines.extend([
            "## Atributos de Salida",
            "",
            "| Campo | Tipo | Descripción |",
            "|-------|------|-------------|",
        ])
        for attr in doc.output_attributes:
            name = attr.get("name", "")
            type_hint = attr.get("type", "")
            desc = attr.get("description", "").replace("|", "\\|")
            lines.append(f"| {name} | {type_hint} | {desc} |")
        lines.append("")
    
    if doc.business_rules:
        lines.extend([
            "## Reglas de Negocio",
            "",
        ])
        for rule in doc.business_rules:
            lines.append(f"- {rule}")
        lines.append("")
    
    if doc.error_messages:
        lines.extend([
            "## Errores Posibles",
            "",
            "| Código | Mensaje | Causa | Solución |",
            "|--------|---------|-------|----------|",
        ])
        for err in doc.error_messages:
            code = err.get("code", "")
            msg = err.get("message", "").replace("|", "\\|")
            cause = err.get("cause", "").replace("|", "\\|")
            solution = err.get("solution", "").replace("|", "\\|")
            lines.append(f"| {code} | {msg} | {cause} | {solution} |")
        lines.append("")
    
    if doc.consumption_tips:
        lines.extend([
            "## Tips de Consumo",
            "",
        ])
        for tip in doc.consumption_tips:
            lines.append(f"- {tip}")
        lines.append("")
    
    return "\n".join(lines)
