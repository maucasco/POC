"""Scanner node - Uses MCP server to scan EJB contracts."""

import logging
import sys
from pathlib import Path
from typing import Any

from ..config import get_settings

# Add quarkus-codegen-agent to path for reusing components
_settings = get_settings()
sys.path.insert(0, f"{_settings.quarkus_codegen_path}/src")

from quarkus_codegen_agent.mcp_client import McpClient
from quarkus_codegen_agent.models import DtoDefinition, EjbContract, MethodSignature

from ..state import OrchestratorState

LOGGER = logging.getLogger(__name__)


def _dto_to_dict(dto: DtoDefinition | None) -> dict[str, Any] | None:
    """Convert DtoDefinition model to dict for state serialization.
    
    Recursively converts nested DTOs as well.
    """
    if dto is None:
        return None
    
    return {
        "name": dto.name,
        "file_path": str(dto.file_path) if dto.file_path else None,
        "fields": [
            {
                "name": field.name,
                "type_hint": field.type_hint,
                "nested_dto": _dto_to_dict(field.nested_dto) if field.nested_dto else None,
            }
            for field in dto.fields
        ],
    }


async def scan_project(state: OrchestratorState) -> OrchestratorState:
    """Scan the JEE project to extract EJB contract information.
    
    This node uses the MCP server to scan the project and extract
    the facade interface and method details.
    """
    LOGGER.info("=== SCAN NODE ===")
    LOGGER.info("Scanning project: %s", state.get("project_path"))
    LOGGER.info("Looking for facade: %s", state.get("facade_name"))
    
    try:
        client = McpClient()
        
        # Scan the project (use detailed_scan=False to avoid sampling/createMessage issues)
        result = await client.scan_project(
            project_path=state["project_path"],
            detailed_scan=False
        )
        
        # Find the specific facade
        facade_name = state["facade_name"]
        contract: EjbContract | None = None
        
        for c in result.contracts:
            if c.interface_name == facade_name:
                contract = c
                break
        
        if not contract:
            LOGGER.error("Facade not found: %s", facade_name)
            return {
                **state,
                "current_step": "scan_failed",
                "error_message": f"Facade '{facade_name}' not found in project",
            }
        
        LOGGER.info("Found facade: %s with %d methods", contract.interface_name, len(contract.methods))
        
        # If a specific method is requested, find it
        method_name = state.get("method_name")
        method: MethodSignature | None = None
        
        if method_name:
            for m in contract.methods:
                if m.name == method_name:
                    method = m
                    break
            
            if not method:
                LOGGER.error("Method not found: %s", method_name)
                return {
                    **state,
                    "current_step": "scan_failed",
                    "error_message": f"Method '{method_name}' not found in facade '{facade_name}'",
                }
            
            LOGGER.info("Found method: %s", method.name)
        
        # Convert to dict for state
        contract_dict = {
            "interface_name": contract.interface_name,
            "annotation": contract.annotation,
            "file_path": contract.file_path,
            "related_manager_path": contract.related_manager_path,
            "methods": [
                {
                    "name": m.name,
                    "return_type": m.return_type,
                    "parameters": [
                        {
                            "name": p.name,
                            "type_hint": p.type_hint,
                            "dto": _dto_to_dict(p.dto) if p.dto else None,
                            "dto_fields": p.dto_fields,
                        }
                        for p in m.parameters
                    ],
                    "documentation": m.documentation,
                    "manager_summary": m.manager_summary,
                }
                for m in contract.methods
            ],
        }
        
        method_dict = None
        if method:
            method_dict = {
                "name": method.name,
                "return_type": method.return_type,
                "parameters": [
                    {
                        "name": p.name,
                        "type_hint": p.type_hint,
                        "dto": _dto_to_dict(p.dto) if p.dto else None,
                        "dto_fields": p.dto_fields,
                    }
                    for p in method.parameters
                ],
                "documentation": method.documentation,
                "manager_summary": method.manager_summary,
            }
        
        return {
            **state,
            "contract": contract_dict,
            "method": method_dict,
            "current_step": "scanned",
        }
        
    except Exception as e:
        LOGGER.exception("Error scanning project")
        return {
            **state,
            "current_step": "scan_failed",
            "error_message": str(e),
        }
