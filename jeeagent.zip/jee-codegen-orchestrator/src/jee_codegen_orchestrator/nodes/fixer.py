"""Fixer node - Uses LLM to fix compilation errors."""

import logging
from pathlib import Path
from typing import List, Dict

import anthropic
import openai

from ..state import OrchestratorState, CompileError, FixResult
from ..config import get_settings

LOGGER = logging.getLogger(__name__)


def _get_error_attr(error, attr: str, default=None):
    """Get attribute from error object (dict, dataclass, or string)."""
    if isinstance(error, str):
        # Error is a raw string (e.g., timeout message)
        return default
    elif isinstance(error, dict):
        return error.get(attr, default)
    return getattr(error, attr, default)


async def fix_errors(state: OrchestratorState) -> OrchestratorState:
    """Attempt to fix compilation errors using LLM analysis.
    
    This node reads the files with errors, sends them to the LLM
    along with the error messages, and applies the suggested fixes.
    """
    LOGGER.info("=== FIX NODE ===")
    
    fix_attempts = state.get("fix_attempts", 0)
    compile_errors = state.get("compile_errors", [])
    output_dir = state.get("output_dir", "/data/output")
    
    LOGGER.info("Fix attempt %d, processing %d errors", fix_attempts + 1, len(compile_errors))
    
    if not compile_errors:
        LOGGER.warning("No errors to fix")
        return {
            **state,
            "fix_attempts": fix_attempts + 1,
            "current_step": "fixed",
        }
    
    try:
        settings = get_settings()
        
        # Group errors by file
        errors_by_file = _group_errors_by_file(compile_errors)
        
        fixed_files = []
        
        for file_path, file_errors in errors_by_file.items():
            LOGGER.info("Fixing %d errors in: %s", len(file_errors), file_path)
            
            # Read the file content
            try:
                file_content = Path(file_path).read_text(encoding="utf-8")
            except FileNotFoundError:
                LOGGER.error("File not found: %s", file_path)
                continue
            
            # Build error context
            error_context = "\n".join([
                f"Line {_get_error_attr(e, 'line', '?')}: {_get_error_attr(e, 'message', 'Unknown error')}"
                for e in file_errors
            ])
            
            # Call LLM to fix the errors
            fixed_content = await _fix_file_with_llm(
                file_content=file_content,
                file_path=file_path,
                errors=error_context,
                settings=settings,
            )
            
            if fixed_content and fixed_content != file_content:
                # Write the fixed content
                Path(file_path).write_text(fixed_content, encoding="utf-8")
                fixed_files.append(file_path)
                LOGGER.info("Fixed file: %s", file_path)
            else:
                LOGGER.warning("No changes made to: %s", file_path)
        
        return {
            **state,
            "fix_attempts": fix_attempts + 1,
            "current_step": "fixed",
        }
        
    except Exception as e:
        LOGGER.exception("Error during fix attempt")
        return {
            **state,
            "fix_attempts": fix_attempts + 1,
            "current_step": "fix_failed",
            "error_message": str(e),
        }


def _group_errors_by_file(errors: List) -> Dict[str, List]:
    """Group errors by file path."""
    grouped = {}
    for error in errors:
        file_path = _get_error_attr(error, "file_path", "")
        if file_path:
            if file_path not in grouped:
                grouped[file_path] = []
            grouped[file_path].append(error)
    return grouped


async def _fix_file_with_llm(
    file_content: str,
    file_path: str,
    errors: str,
    settings,
) -> str:
    """Use LLM to fix a file with compilation errors.
    
    Args:
        file_content: Current content of the file
        file_path: Path to the file (for context)
        errors: Error messages from compiler
        settings: Application settings
        
    Returns:
        Fixed file content
    """
    prompt = _build_fix_prompt(file_content, file_path, errors)
    
    if settings.llm_provider == "openai":
        client = openai.AsyncOpenAI(api_key=settings.openai_api_key)
        response = await client.chat.completions.create(
            model=settings.openai_model,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are an expert Java developer specializing in Quarkus and hexagonal architecture. "
                        "Your task is to fix compilation errors in Java code. "
                        "Return ONLY the complete fixed Java file content, no explanations. "
                        "Do not wrap the code in markdown code blocks."
                    ),
                },
                {"role": "user", "content": prompt},
            ],
            max_completion_tokens=settings.openai_max_tokens,
            temperature=settings.openai_temperature,
        )
        content = response.choices[0].message.content or ""
    else:
        client = anthropic.AsyncAnthropic(api_key=settings.anthropic_api_key)
        response = await client.messages.create(
            model=settings.anthropic_model,
            max_tokens=8000,
            system=(
                "You are an expert Java developer specializing in Quarkus and hexagonal architecture. "
                "Your task is to fix compilation errors in Java code. "
                "Return ONLY the complete fixed Java file content, no explanations. "
                "Do not wrap the code in markdown code blocks."
            ),
            messages=[{"role": "user", "content": prompt}],
        )
        content = response.content[0].text if response.content else ""
    
    return _extract_code(content)


def _build_fix_prompt(file_content: str, file_path: str, errors: str) -> str:
    """Build the prompt for fixing compilation errors."""
    # Load template if available
    prompts_dir = Path(__file__).parent.parent / "prompts"
    template_path = prompts_dir / "fix_error.prompt"
    
    if template_path.exists():
        template = template_path.read_text(encoding="utf-8")
        return template.format(
            file_path=file_path,
            file_content=file_content,
            errors=errors,
        )
    
    # Default template
    return f"""Fix the following Java file that has compilation errors.

## File: {file_path}

## Current Content:
```java
{file_content}
```

## Compilation Errors:
{errors}

## Instructions:
1. Analyze each compilation error carefully
2. Fix the errors while maintaining the original functionality
3. Ensure all imports are correct
4. Ensure all types are compatible
5. Return the complete fixed file content

## Fixed Content:
"""


def _extract_code(response: str) -> str:
    """Extract code from LLM response, removing markdown fences."""
    code = response.strip()
    
    # Remove markdown code fences
    if code.startswith("```java"):
        code = code[7:]
    elif code.startswith("```"):
        code = code[3:]
    
    if code.endswith("```"):
        code = code[:-3]
    
    return code.strip()
