"""Compiler node - Compiles the generated code using Maven."""

import logging
import re
import subprocess
from pathlib import Path
from typing import List, Tuple

from ..state import OrchestratorState, CompileError

LOGGER = logging.getLogger(__name__)


async def compile_code(state: OrchestratorState) -> OrchestratorState:
    """Compile the generated code using Maven.
    
    This node runs 'mvn compile' on the output directory and parses
    any compilation errors for potential fixing.
    """
    LOGGER.info("=== COMPILE NODE ===")
    
    output_dir = state.get("output_dir", "/data/output")
    
    # Check if pom.xml exists
    pom_path = Path(output_dir) / "pom.xml"
    if not pom_path.exists():
        LOGGER.error("No pom.xml found in output directory: %s", output_dir)
        return {
            **state,
            "compile_success": False,
            "compile_errors": [{
                "file_path": "",
                "line": 0,
                "column": 0,
                "message": "No pom.xml found in output directory",
                "error_type": "error"
            }],
            "current_step": "compile_failed",
        }
    
    try:
        LOGGER.info("Running mvn compile in: %s", output_dir)
        
        # Run Maven compile
        result = subprocess.run(
            ["mvn", "compile", "-q"],
            cwd=output_dir,
            capture_output=True,
            text=True,
            timeout=120,
        )
        
        # Parse output for errors
        errors = _parse_maven_errors(result.stdout + result.stderr, output_dir)
        
        if result.returncode == 0:
            LOGGER.info("Compilation successful!")
            return {
                **state,
                "compile_success": True,
                "compile_errors": [],
                "current_step": "compiled",
            }
        else:
            LOGGER.warning("Compilation failed with %d errors", len(errors))
            for err in errors[:5]:  # Log first 5 errors
                LOGGER.warning("  - %s:%d: %s", err.file_path, err.line, err.message)
            
            return {
                **state,
                "compile_success": False,
                "compile_errors": [_error_to_dict(e) for e in errors],
                "current_step": "compile_failed",
            }
        
    except subprocess.TimeoutExpired:
        LOGGER.error("Compilation timed out")
        return {
            **state,
            "compile_success": False,
            "compile_errors": [{
                "file_path": "",
                "line": 0,
                "column": 0,
                "message": "Compilation timed out after 120 seconds",
                "error_type": "error"
            }],
            "current_step": "compile_failed",
        }
    except Exception as e:
        LOGGER.exception("Error during compilation")
        return {
            **state,
            "compile_success": False,
            "compile_errors": [{
                "file_path": "",
                "line": 0,
                "column": 0,
                "message": str(e),
                "error_type": "error"
            }],
            "current_step": "compile_failed",
        }


def _parse_maven_errors(output: str, base_dir: str) -> List[CompileError]:
    """Parse Maven compilation output for errors.
    
    Args:
        output: Combined stdout/stderr from Maven
        base_dir: Base directory for resolving paths
        
    Returns:
        List of CompileError objects
    """
    errors = []
    
    # Pattern 1: [ERROR] /path/to/file.java:[line,col] message
    pattern1 = r'\[ERROR\]\s+(.+?\.java):\[(\d+),(\d+)\]\s+(.+)'
    
    # Pattern 2: /path/to/file.java:[line,col] error: message
    pattern2 = r'(.+?\.java):\[(\d+),(\d+)\]\s+error:\s+(.+)'
    
    # Pattern 3: [ERROR] /path/to/file.java:[line] error: message
    pattern3 = r'\[ERROR\]\s+(.+?\.java):\[(\d+)\]\s+(.+)'
    
    for line in output.split('\n'):
        line = line.strip()
        
        # Try pattern 1
        match = re.match(pattern1, line)
        if match:
            errors.append(CompileError(
                file_path=match.group(1),
                line=int(match.group(2)),
                column=int(match.group(3)),
                message=match.group(4),
                error_type="error",
            ))
            continue
        
        # Try pattern 2
        match = re.match(pattern2, line)
        if match:
            errors.append(CompileError(
                file_path=match.group(1),
                line=int(match.group(2)),
                column=int(match.group(3)),
                message=match.group(4),
                error_type="error",
            ))
            continue
        
        # Try pattern 3
        match = re.match(pattern3, line)
        if match:
            errors.append(CompileError(
                file_path=match.group(1),
                line=int(match.group(2)),
                column=0,
                message=match.group(3),
                error_type="error",
            ))
            continue
    
    return errors


def _error_to_dict(error: CompileError) -> dict:
    """Convert CompileError to dictionary for state storage."""
    return {
        "file_path": error.file_path,
        "line": error.line,
        "column": error.column,
        "message": error.message,
        "error_type": error.error_type,
    }


def should_fix(state: OrchestratorState) -> str:
    """Conditional edge: determine if we should try to fix errors.
    
    Returns:
        "fix" if we should try to fix, "end" if we should stop
    """
    compile_success = state.get("compile_success", False)
    fix_attempts = state.get("fix_attempts", 0)
    max_attempts = state.get("max_fix_attempts", 3)
    
    if compile_success:
        LOGGER.info("Compilation successful, ending workflow")
        return "end"
    
    if fix_attempts >= max_attempts:
        LOGGER.warning("Max fix attempts (%d) reached, ending workflow", max_attempts)
        return "end"
    
    LOGGER.info("Will attempt fix (attempt %d/%d)", fix_attempts + 1, max_attempts)
    return "fix"
