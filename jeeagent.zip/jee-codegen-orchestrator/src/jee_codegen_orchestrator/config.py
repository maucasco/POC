"""Configuration settings for the orchestrator."""

import sys
from pydantic_settings import BaseSettings
from pathlib import Path
from functools import lru_cache


class Settings(BaseSettings):
    """Application settings loaded from environment."""
    
    # LLM Configuration
    llm_provider: str = "openai"
    openai_api_key: str = ""
    openai_model: str = "gpt-4.1-mini"
    openai_max_tokens: int = 50000
    openai_temperature: float = 0.2
    # Keep anthropic for backwards compatibility
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-4-20250514"
    
    # MCP Server Configuration (Docker: /app/*, Host: /data/agente/*)
    mcp_server_path: str = "/app/intepreter-jee-mcp-server"
    mcp_python_path: str = sys.executable
    
    # Agent paths
    quarkus_codegen_path: str = "/app/quarkus-codegen-agent"
    jee_doc_agent_path: str = "/app/jee-doc-agent"
    
    # Orchestration settings
    max_fix_attempts: int = 3
    compile_timeout: int = 120  # seconds
    
    # Paths (Docker: /data/output, Host: /data/agente/output)
    output_base_dir: str = "/data/output"
    prompts_dir: str = ""
    
    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "extra": "ignore"
    }
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if not self.prompts_dir:
            self.prompts_dir = str(Path(__file__).parent / "prompts")


@lru_cache
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()
