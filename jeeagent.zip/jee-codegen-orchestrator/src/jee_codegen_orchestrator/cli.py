"""CLI for the JEE Codegen Orchestrator."""

import asyncio
import logging
import sys
from pathlib import Path
from typing import Optional

import typer

from .config import get_settings
from .graph import run_orchestrator

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)

LOGGER = logging.getLogger(__name__)

app = typer.Typer(
    name="jee-orchestrate",
    help="Orchestrate JEE to Quarkus migration with auto-fix capability",
)


@app.command("method")
def generate_method(
    project_path: str = typer.Argument(
        ...,
        help="Path to the JEE project to migrate",
    ),
    interface: str = typer.Option(
        ...,
        "-i", "--interface",
        help="Name of the EJB facade interface (e.g., AdministracionPropuestaFacade)",
    ),
    method: Optional[str] = typer.Option(
        None,
        "-m", "--method",
        help="Specific method to generate (if not provided, generates all)",
    ),
    output: str = typer.Option(
        "/data/agente/output",
        "-o", "--output",
        help="Output directory for generated code",
    ),
    package: str = typer.Option(
        "com.davivienda",
        "-p", "--package",
        help="Base Java package for generated code",
    ),
    max_retries: int = typer.Option(
        3,
        "--max-retries",
        help="Maximum number of fix attempts for compilation errors",
    ),
    skip_docs: bool = typer.Option(
        False,
        "--skip-docs",
        help="Skip documentation generation",
    ),
    mapping_csv: Optional[str] = typer.Option(
        None,
        "--mapping-csv",
        help="Optional CSV file with field mappings (columns: ObjetoOrigen,ObjetoDestino,campoOrigen,campoDestino). Path relative to project.",
    ),
):
    """Generate Quarkus hexagonal code for a JEE EJB facade method.
    
    This command:
    1. Scans the JEE project to extract the EJB contract
    2. Generates documentation using LLM analysis
    3. Generates Quarkus hexagonal architecture code
    4. Compiles the generated code
    5. Auto-fixes compilation errors (up to max-retries times)
    
    Example:
        jee-orchestrate method /path/to/jee-project -i AdministracionPropuestaFacade -m consultarPropuesta
    """
    typer.echo(f"🚀 Starting JEE to Quarkus migration orchestrator")
    typer.echo(f"   Project: {project_path}")
    typer.echo(f"   Facade: {interface}")
    typer.echo(f"   Method: {method or 'all methods'}")
    typer.echo(f"   Output: {output}")
    typer.echo(f"   Max retries: {max_retries}")
    typer.echo()
    
    # Verify project path exists
    if not Path(project_path).exists():
        typer.echo(f"❌ Error: Project path does not exist: {project_path}", err=True)
        raise typer.Exit(1)
    
    # Resolve mapping CSV path (relative to project or absolute)
    resolved_mapping_csv = None
    if mapping_csv:
        csv_path = Path(mapping_csv)
        if not csv_path.is_absolute():
            csv_path = Path(project_path) / mapping_csv
        if csv_path.exists():
            resolved_mapping_csv = str(csv_path)
            typer.echo(f"   Mapping CSV: {resolved_mapping_csv}")
        else:
            typer.echo(f"⚠️  Warning: Mapping CSV not found: {csv_path}", err=True)
    
    # Run the orchestrator
    try:
        final_state = asyncio.run(
            run_orchestrator(
                project_path=project_path,
                facade_name=interface,
                method_name=method,
                output_dir=output,
                base_package=package,
                max_fix_attempts=max_retries,
                mapping_csv_path=resolved_mapping_csv,
            )
        )
        
        # Report results
        typer.echo()
        if final_state.get("compile_success"):
            typer.echo("✅ Migration completed successfully!")
            files = final_state.get("generated_files", [])
            typer.echo(f"   Generated {len(files)} files")
            
            # Show generated files
            typer.echo()
            typer.echo("📁 Generated files:")
            for f in files[:10]:  # Show first 10
                typer.echo(f"   - {f}")
            if len(files) > 10:
                typer.echo(f"   ... and {len(files) - 10} more")
        else:
            typer.echo("❌ Migration completed with errors")
            typer.echo(f"   Fix attempts: {final_state.get('fix_attempts', 0)}/{max_retries}")
            
            errors = final_state.get("compile_errors", [])
            if errors:
                typer.echo()
                typer.echo("🔴 Remaining compilation errors:")
                for err in errors[:5]:
                    if isinstance(err, dict):
                        typer.echo(f"   - {err.get('file_path')}:{err.get('line')}: {err.get('message')}")
                    else:
                        typer.echo(f"   - {err}")
                if len(errors) > 5:
                    typer.echo(f"   ... and {len(errors) - 5} more errors")
            
            raise typer.Exit(1)
            
    except Exception as e:
        typer.echo(f"❌ Error: {e}", err=True)
        LOGGER.exception("Orchestration failed")
        raise typer.Exit(1)


@app.command("verify")
def verify_compilation(
    output_dir: str = typer.Argument(
        "/data/agente/output",
        help="Output directory to verify",
    ),
):
    """Verify that the generated code compiles successfully.
    
    This command runs 'mvn compile' on the output directory
    and reports any compilation errors.
    """
    import subprocess
    
    typer.echo(f"🔍 Verifying compilation in: {output_dir}")
    
    pom_path = Path(output_dir) / "pom.xml"
    if not pom_path.exists():
        typer.echo(f"❌ Error: No pom.xml found in {output_dir}", err=True)
        raise typer.Exit(1)
    
    try:
        result = subprocess.run(
            ["mvn", "compile"],
            cwd=output_dir,
            capture_output=True,
            text=True,
            timeout=120,
        )
        
        if result.returncode == 0:
            typer.echo("✅ Compilation successful!")
        else:
            typer.echo("❌ Compilation failed!")
            typer.echo()
            typer.echo("Maven output:")
            typer.echo(result.stdout)
            if result.stderr:
                typer.echo("Errors:")
                typer.echo(result.stderr)
            raise typer.Exit(1)
            
    except subprocess.TimeoutExpired:
        typer.echo("❌ Error: Compilation timed out", err=True)
        raise typer.Exit(1)
    except FileNotFoundError:
        typer.echo("❌ Error: Maven not found. Please install Maven.", err=True)
        raise typer.Exit(1)


@app.command("config")
def show_config():
    """Show current configuration settings."""
    settings = get_settings()
    
    typer.echo("📋 Current Configuration:")
    typer.echo(f"   LLM Provider: {settings.llm_provider}")
    typer.echo(f"   Model: {settings.anthropic_model}")
    typer.echo(f"   MCP Server: {settings.mcp_server_path}")
    typer.echo(f"   Max Fix Attempts: {settings.max_fix_attempts}")
    typer.echo(f"   Output Base Dir: {settings.output_base_dir}")
    
    # Check API key
    if settings.anthropic_api_key:
        masked = settings.anthropic_api_key[:8] + "..." + settings.anthropic_api_key[-4:]
        typer.echo(f"   API Key: {masked}")
    else:
        typer.echo("   API Key: ❌ NOT SET")


def main():
    """Entry point for the CLI."""
    app()


if __name__ == "__main__":
    main()
