"""LangGraph definition for the JEE to Quarkus orchestration workflow."""

import csv
import logging
from pathlib import Path
from typing import Literal

from langgraph.graph import StateGraph, END

from .state import OrchestratorState, MappingHint
from .nodes.scanner import scan_project
from .nodes.documenter import generate_documentation
from .nodes.generator import generate_code
from .nodes.compiler import compile_code, should_fix
from .nodes.fixer import fix_errors

LOGGER = logging.getLogger(__name__)


def _parse_mapping_csv(csv_path: str) -> list[MappingHint]:
    """Parse mapping hints from CSV file.
    
    Expected columns: ObjetoOrigen,ObjetoDestino,campoOrigen,campoDestino
    Supports field paths with depth up to 3 (e.g., obj.nested.field)
    
    Args:
        csv_path: Path to the CSV file
        
    Returns:
        List of MappingHint dictionaries
    """
    hints: list[MappingHint] = []
    
    try:
        with open(csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            
            # Validate header
            required_columns = {'ObjetoOrigen', 'ObjetoDestino', 'campoOrigen', 'campoDestino'}
            if not reader.fieldnames or not required_columns.issubset(set(reader.fieldnames)):
                LOGGER.error(
                    "Invalid CSV header. Required: %s, Found: %s",
                    required_columns, reader.fieldnames
                )
                return []
            
            for row in reader:
                hint: MappingHint = {
                    'objeto_origen': row.get('ObjetoOrigen', '').strip(),
                    'objeto_destino': row.get('ObjetoDestino', '').strip(),
                    'campo_origen': row.get('campoOrigen', '').strip(),
                    'campo_destino': row.get('campoDestino', '').strip(),
                }
                
                # Validate non-empty fields
                if all(hint.values()):
                    hints.append(hint)
                else:
                    LOGGER.warning("Skipping incomplete row: %s", row)
        
        LOGGER.info("Loaded %d mapping hints from CSV", len(hints))
        
    except Exception as e:
        LOGGER.error("Error reading mapping CSV %s: %s", csv_path, e)
    
    return hints


def create_orchestrator_graph() -> StateGraph:
    """Create the LangGraph orchestrator workflow.
    
    The workflow follows this sequence:
    1. scan: Scan the JEE project to extract EJB contracts
    2. document: Generate documentation using LLM analysis
    3. generate: Generate Quarkus hexagonal code
    4. compile: Compile the generated code
    5. fix (conditional): If compilation fails and attempts < max, try to fix
    6. End: Either successful compilation or max attempts reached
    
    Returns:
        Configured StateGraph ready for execution
    """
    # Create the graph with our state type
    graph = StateGraph(OrchestratorState)
    
    # Add nodes
    graph.add_node("scan", scan_project)
    graph.add_node("document", generate_documentation)
    graph.add_node("generate", generate_code)
    graph.add_node("compile", compile_code)
    graph.add_node("fix", fix_errors)
    
    # Add edges for the main flow
    graph.set_entry_point("scan")
    
    # scan -> document (if scan succeeds)
    graph.add_conditional_edges(
        "scan",
        _check_scan_result,
        {
            "continue": "document",
            "end": END,
        }
    )
    
    # document -> generate (if documentation succeeds)
    graph.add_conditional_edges(
        "document",
        _check_document_result,
        {
            "continue": "generate",
            "skip": "generate",  # Can skip documentation if it fails
            "end": END,
        }
    )
    
    # generate -> compile (if generation succeeds)
    graph.add_conditional_edges(
        "generate",
        _check_generate_result,
        {
            "continue": "compile",
            "end": END,
        }
    )
    
    # compile -> fix or end (conditional based on success/attempts)
    graph.add_conditional_edges(
        "compile",
        should_fix,
        {
            "fix": "fix",
            "end": END,
        }
    )
    
    # fix -> compile (loop back to verify fix)
    graph.add_edge("fix", "compile")
    
    return graph


def _check_scan_result(state: OrchestratorState) -> Literal["continue", "end"]:
    """Check if scan was successful."""
    current_step = state.get("current_step", "")
    
    if current_step == "scanned" and state.get("contract"):
        return "continue"
    
    LOGGER.error("Scan failed: %s", state.get("error_message", "Unknown error"))
    return "end"


def _check_document_result(state: OrchestratorState) -> Literal["continue", "skip", "end"]:
    """Check if documentation was successful."""
    current_step = state.get("current_step", "")
    
    if current_step == "documented":
        return "continue"
    
    if current_step == "document_failed":
        # Documentation is optional, we can continue without it
        LOGGER.warning("Documentation failed, continuing without it")
        return "skip"
    
    return "end"


def _check_generate_result(state: OrchestratorState) -> Literal["continue", "end"]:
    """Check if code generation was successful."""
    current_step = state.get("current_step", "")
    
    if current_step == "generated" and state.get("generated_files"):
        return "continue"
    
    LOGGER.error("Generation failed: %s", state.get("error_message", "Unknown error"))
    return "end"


def build_graph():
    """Build and compile the orchestrator graph.
    
    Returns:
        Compiled graph ready for invocation
    """
    graph = create_orchestrator_graph()
    return graph.compile()


async def run_orchestrator(
    project_path: str,
    facade_name: str,
    method_name: str | None = None,
    output_dir: str = "/data/output",
    base_package: str = "com.davivienda",
    max_fix_attempts: int = 3,
    mapping_csv_path: str | None = None,
    generation_hints: str | None = None,
) -> OrchestratorState:
    """Run the complete orchestration workflow.
    
    Args:
        project_path: Path to the JEE project to migrate
        facade_name: Name of the EJB facade interface
        method_name: Optional specific method to generate
        output_dir: Output directory for generated code
        base_package: Base Java package for generated code
        max_fix_attempts: Maximum number of fix attempts
        mapping_csv_path: Optional path to CSV with field mapping hints
        generation_hints: Optional user instructions for code generation
        
    Returns:
        Final state with results and any errors
    """
    LOGGER.info("Starting orchestration workflow")
    LOGGER.info("  Project: %s", project_path)
    LOGGER.info("  Facade: %s", facade_name)
    LOGGER.info("  Method: %s", method_name or "all")
    LOGGER.info("  Output: %s", output_dir)
    
    # Parse mapping hints from CSV if provided
    mapping_hints: list[MappingHint] | None = None
    if mapping_csv_path:
        LOGGER.info("  Mapping CSV: %s", mapping_csv_path)
        mapping_hints = _parse_mapping_csv(mapping_csv_path)
    
    # Build initial state
    initial_state: OrchestratorState = {
        "project_path": project_path,
        "facade_name": facade_name,
        "method_name": method_name,
        "output_dir": output_dir,
        "base_package": base_package,
        "mapping_csv_path": mapping_csv_path,
        "mapping_hints": mapping_hints,
        "generation_hints": generation_hints,
        "contract": None,
        "method": None,
        "documentation": None,
        "generated_files": [],
        "compile_success": False,
        "compile_errors": [],
        "fix_attempts": 0,
        "max_fix_attempts": max_fix_attempts,
        "current_step": "starting",
        "error_message": None,
    }
    
    # Build and run the graph
    graph = build_graph()
    
    final_state = await graph.ainvoke(initial_state)
    
    # Log final results
    if final_state.get("compile_success"):
        LOGGER.info("✅ Workflow completed successfully!")
        LOGGER.info("  Generated %d files", len(final_state.get("generated_files", [])))
    else:
        LOGGER.error("❌ Workflow completed with errors")
        LOGGER.error("  Fix attempts: %d/%d", 
                    final_state.get("fix_attempts", 0),
                    final_state.get("max_fix_attempts", 3))
        if final_state.get("compile_errors"):
            LOGGER.error("  Remaining errors: %d", len(final_state["compile_errors"]))
    
    return final_state
