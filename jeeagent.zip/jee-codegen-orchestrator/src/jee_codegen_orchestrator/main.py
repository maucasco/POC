"""Entry point for the MCP server."""
from __future__ import annotations

import argparse
import logging
import os
import sys

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
LOGGER = logging.getLogger(__name__)


def main():
    """Main entry point for the MCP server."""
    parser = argparse.ArgumentParser(
        description="JEE Codegen Orchestrator MCP Server"
    )
    parser.add_argument(
        "--transport",
        choices=["stdio", "sse", "streamable-http"],
        default="stdio",
        help="Transport mechanism (default: stdio for GitHub Copilot)",
    )
    parser.add_argument(
        "--host",
        default=os.environ.get("FASTMCP_HOST", "127.0.0.1"),
        help="Host for HTTP transports (default: 127.0.0.1)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=int(os.environ.get("FASTMCP_PORT", "8080")),
        help="Port for HTTP transports (default: 8080)",
    )
    parser.add_argument(
        "--cache-ttl",
        type=int,
        default=30,
        help="Cache TTL in minutes (default: 30)",
    )
    
    args = parser.parse_args()
    
    # Configure FastMCP settings via environment variables BEFORE importing
    # FastMCP uses FASTMCP_ prefix for its settings (pydantic-settings)
    os.environ["FASTMCP_HOST"] = args.host
    os.environ["FASTMCP_PORT"] = str(args.port)
    
    # Import here to avoid circular imports and allow config before import
    from .mcp_server import get_mcp_server
    from . import mcp_server as mcp_module
    
    # Configure module-level settings
    mcp_module._cache_ttl_minutes = args.cache_ttl
    
    # Pass host and port to the server factory
    mcp = get_mcp_server(host=args.host, port=args.port)
    
    LOGGER.info("Starting JEE Codegen Orchestrator MCP Server")
    LOGGER.info("  Transport: %s", args.transport)
    LOGGER.info("  Cache TTL: %d minutes", args.cache_ttl)
    
    if args.transport == "stdio":
        # Standard I/O for GitHub Copilot
        mcp.run(transport="stdio")
    elif args.transport == "sse":
        # Server-Sent Events for streaming
        LOGGER.info("  URL: http://%s:%d/sse", args.host, args.port)
        mcp.run(transport="sse")
    elif args.transport == "streamable-http":
        # Streamable HTTP for stateless clients
        LOGGER.info("  URL: http://%s:%d/mcp", args.host, args.port)
        mcp.run(transport="streamable-http")


if __name__ == "__main__":
    main()
