"""Tests for generator node mapping hints filtering."""
from __future__ import annotations

import sys
sys.path.insert(0, "/data/agente/quarkus-codegen-agent/src")

from jee_codegen_orchestrator.nodes.generator import _filter_mapping_hints_for_method
from quarkus_codegen_agent.models import (
    MethodSignature,
    MethodParameter,
    DtoDefinition,
    DtoField,
)


class TestFilterMappingHints:
    """Tests for filtering mapping hints by method types."""

    def test_filter_empty_hints(self):
        """Should return empty list when no hints provided."""
        method = MethodSignature(
            name="test",
            return_type="void",
            parameters=[],
        )
        
        result = _filter_mapping_hints_for_method(None, method)
        assert result == []
        
        result = _filter_mapping_hints_for_method([], method)
        assert result == []

    def test_filter_by_parameter_type(self):
        """Should include hints matching parameter types."""
        method = MethodSignature(
            name="testMethod",
            return_type="void",
            parameters=[
                MethodParameter(name="param", type_hint="ParametrosTO"),
            ],
        )
        
        hints = [
            {"objeto_origen": "ParametrosTO", "objeto_destino": "Request", "campo_origen": "a", "campo_destino": "b"},
            {"objeto_origen": "OtroTO", "objeto_destino": "Request", "campo_origen": "c", "campo_destino": "d"},
        ]
        
        result = _filter_mapping_hints_for_method(hints, method)
        
        assert len(result) == 1
        assert result[0]["objeto_origen"] == "ParametrosTO"

    def test_filter_by_return_type(self):
        """Should include hints matching return type."""
        method = MethodSignature(
            name="testMethod",
            return_type="ResultadoTO",
            parameters=[],
        )
        
        hints = [
            {"objeto_origen": "ResultadoTO", "objeto_destino": "Response", "campo_origen": "a", "campo_destino": "b"},
            {"objeto_origen": "OtroTO", "objeto_destino": "Request", "campo_origen": "c", "campo_destino": "d"},
        ]
        
        result = _filter_mapping_hints_for_method(hints, method)
        
        assert len(result) == 1
        assert result[0]["objeto_origen"] == "ResultadoTO"

    def test_filter_by_dto_name(self):
        """Should include hints matching DTO definition name."""
        dto = DtoDefinition(name="ConsultaVO", fields=[])
        method = MethodSignature(
            name="testMethod",
            return_type="void",
            parameters=[
                MethodParameter(name="consulta", type_hint="ConsultaVO", dto=dto),
            ],
        )
        
        hints = [
            {"objeto_origen": "ConsultaVO", "objeto_destino": "Request", "campo_origen": "x", "campo_destino": "y"},
        ]
        
        result = _filter_mapping_hints_for_method(hints, method)
        
        assert len(result) == 1

    def test_filter_includes_request_response_by_convention(self):
        """Should include hints for Request/Response DTOs by naming convention."""
        method = MethodSignature(
            name="insertarDatos",
            return_type="void",
            parameters=[],
        )
        
        hints = [
            {"objeto_origen": "SomeTO", "objeto_destino": "InsertarDatosRequest", "campo_origen": "a", "campo_destino": "b"},
            {"objeto_origen": "InsertarDatosResponse", "objeto_destino": "Result", "campo_origen": "c", "campo_destino": "d"},
            {"objeto_origen": "Unrelated", "objeto_destino": "Other", "campo_origen": "e", "campo_destino": "f"},
        ]
        
        result = _filter_mapping_hints_for_method(hints, method)
        
        assert len(result) == 2
        destinations = {h["objeto_destino"] for h in result}
        assert "InsertarDatosRequest" in destinations

    def test_filter_handles_generic_types(self):
        """Should extract base type from generic parameters."""
        method = MethodSignature(
            name="test",
            return_type="List<ResultadoTO>",
            parameters=[
                MethodParameter(name="items", type_hint="ArrayList<ItemTO>"),
            ],
        )
        
        hints = [
            {"objeto_origen": "ArrayList", "objeto_destino": "X", "campo_origen": "a", "campo_destino": "b"},
            {"objeto_origen": "ItemTO", "objeto_destino": "Y", "campo_origen": "c", "campo_destino": "d"},
            {"objeto_origen": "List", "objeto_destino": "Z", "campo_origen": "e", "campo_destino": "f"},
        ]
        
        result = _filter_mapping_hints_for_method(hints, method)
        
        # Should match ArrayList and List (base types extracted)
        assert len(result) >= 2

    def test_filter_handles_array_types(self):
        """Should handle array type syntax."""
        method = MethodSignature(
            name="test",
            return_type="ItemTO[]",
            parameters=[],
        )
        
        hints = [
            {"objeto_origen": "ItemTO", "objeto_destino": "X", "campo_origen": "a", "campo_destino": "b"},
        ]
        
        result = _filter_mapping_hints_for_method(hints, method)
        
        assert len(result) == 1
