"""Tests for documenter node."""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
import sys

sys.path.insert(0, "/data/agente/jee-codegen-orchestrator/src")
sys.path.insert(0, "/data/agente/jee-doc-agent/src")

from jee_codegen_orchestrator.nodes.documenter import (
    generate_documentation,
    _convert_method_from_dict,
    _format_documentation,
)
from jee_doc_agent.models import MethodDocumentation


class TestConvertMethodFromDict:
    """Tests for _convert_method_from_dict function."""

    def test_simple_method_conversion(self):
        """Should convert simple method dict to MethodSignature."""
        method_dict = {
            "name": "consultarDatos",
            "return_type": "ResultadoTO",
            "parameters": [],
        }
        
        result = _convert_method_from_dict(method_dict)
        
        assert result.name == "consultarDatos"
        assert result.return_type == "ResultadoTO"
        assert len(result.parameters) == 0

    def test_method_with_parameters(self):
        """Should convert method with parameters."""
        method_dict = {
            "name": "buscar",
            "return_type": "List<ItemTO>",
            "parameters": [
                {"name": "filtro", "type_hint": "FiltroVO"},
                {"name": "limite", "type_hint": "int"},
            ],
        }
        
        result = _convert_method_from_dict(method_dict)
        
        assert len(result.parameters) == 2
        assert result.parameters[0].name == "filtro"
        assert result.parameters[0].type_hint == "FiltroVO"
        assert result.parameters[1].name == "limite"

    def test_method_with_documentation(self):
        """Should include documentation fields."""
        method_dict = {
            "name": "procesar",
            "return_type": "void",
            "parameters": [],
            "documentation": "Procesa el registro",
            "manager_summary": "Realiza validaciones y guarda",
        }
        
        result = _convert_method_from_dict(method_dict)
        
        assert result.documentation == "Procesa el registro"
        assert result.manager_summary == "Realiza validaciones y guarda"

    def test_method_with_dto_fields(self):
        """Should create DTO when dto_fields present."""
        method_dict = {
            "name": "test",
            "return_type": "void",
            "parameters": [
                {
                    "name": "datos",
                    "type_hint": "DatosTO",
                    "dto_fields": [{"name": "id", "type": "Long"}],
                }
            ],
        }
        
        result = _convert_method_from_dict(method_dict)
        
        assert result.parameters[0].dto is not None
        assert result.parameters[0].dto.name == "DatosTO"

    def test_missing_fields_use_defaults(self):
        """Should use defaults for missing fields."""
        method_dict = {"name": "empty"}
        
        result = _convert_method_from_dict(method_dict)
        
        assert result.return_type == "void"
        assert len(result.parameters) == 0


class TestFormatDocumentation:
    """Tests for _format_documentation function."""

    def test_format_basic_documentation(self):
        """Should format basic documentation."""
        doc = MethodDocumentation(
            method_name="testMethod",
            interface_name="TestFacade",
            functional_description="Test description",
            raw_signature="void testMethod()",
        )
        
        result = _format_documentation(doc, "TestFacade")
        
        assert "# TestFacade.testMethod" in result
        assert "## Descripción Funcional" in result
        assert "Test description" in result
        assert "```java" in result
        assert "void testMethod()" in result

    def test_format_with_input_attributes(self):
        """Should format input attributes table."""
        doc = MethodDocumentation(
            method_name="test",
            interface_name="Test",
            functional_description="Test",
            raw_signature="void test()",
            input_attributes=[
                {"name": "param1", "type": "String", "required": True, "description": "First param"},
                {"name": "param2", "type": "Long", "required": False, "description": "Second param"},
            ],
        )
        
        result = _format_documentation(doc, "Test")
        
        assert "## Atributos de Entrada" in result
        assert "| Campo | Tipo | Requerido | Descripción |" in result
        assert "| param1 | String | Sí | First param |" in result
        assert "| param2 | Long | No | Second param |" in result

    def test_format_with_output_attributes(self):
        """Should format output attributes table."""
        doc = MethodDocumentation(
            method_name="test",
            interface_name="Test",
            functional_description="Test",
            raw_signature="ResultTO test()",
            output_attributes=[
                {"name": "resultado", "type": "String", "description": "Result value"},
            ],
        )
        
        result = _format_documentation(doc, "Test")
        
        assert "## Atributos de Salida" in result
        assert "| resultado | String | Result value |" in result

    def test_format_with_business_rules(self):
        """Should format business rules as list."""
        doc = MethodDocumentation(
            method_name="test",
            interface_name="Test",
            functional_description="Test",
            raw_signature="void test()",
            business_rules=["Rule 1", "Rule 2"],
        )
        
        result = _format_documentation(doc, "Test")
        
        assert "## Reglas de Negocio" in result
        assert "- Rule 1" in result
        assert "- Rule 2" in result

    def test_format_with_error_messages(self):
        """Should format error messages table."""
        doc = MethodDocumentation(
            method_name="test",
            interface_name="Test",
            functional_description="Test",
            raw_signature="void test()",
            error_messages=[
                {"code": "ERR001", "message": "Error message", "cause": "Invalid data", "solution": "Fix data"},
            ],
        )
        
        result = _format_documentation(doc, "Test")
        
        assert "## Errores Posibles" in result
        assert "| ERR001 | Error message | Invalid data | Fix data |" in result

    def test_format_with_consumption_tips(self):
        """Should format consumption tips as list."""
        doc = MethodDocumentation(
            method_name="test",
            interface_name="Test",
            functional_description="Test",
            raw_signature="void test()",
            consumption_tips=["Tip 1", "Tip 2"],
        )
        
        result = _format_documentation(doc, "Test")
        
        assert "## Tips de Consumo" in result
        assert "- Tip 1" in result
        assert "- Tip 2" in result

    def test_format_escapes_pipe_characters(self):
        """Should escape pipe characters in table cells."""
        doc = MethodDocumentation(
            method_name="test",
            interface_name="Test",
            functional_description="Test",
            raw_signature="void test()",
            input_attributes=[
                {"name": "val", "type": "String", "required": True, "description": "Value with | pipe"},
            ],
        )
        
        result = _format_documentation(doc, "Test")
        
        assert "Value with \\| pipe" in result


class TestGenerateDocumentation:
    """Tests for generate_documentation function."""

    @pytest.fixture
    def base_state(self):
        """Create base state for tests."""
        return {
            "project_path": "/data/test",
            "facade_name": "TestFacade",
            "output_path": "/data/output",
            "contract": {
                "interface_name": "TestFacade",
                "annotation": "@Remote",
                "file_path": "/TestFacade.java",
                "methods": [
                    {
                        "name": "testMethod",
                        "return_type": "void",
                        "parameters": [],
                    }
                ],
            },
            "method": {
                "name": "testMethod",
                "return_type": "void",
                "parameters": [],
            },
        }

    @pytest.mark.asyncio
    async def test_returns_error_without_contract(self):
        """Should return error when no contract."""
        state = {
            "project_path": "/test",
            "contract": None,
        }
        
        result = await generate_documentation(state)
        
        assert result["current_step"] == "document_failed"
        assert "No contract available" in result["error_message"]

    @pytest.mark.asyncio
    async def test_returns_error_without_methods(self):
        """Should return error when no methods to document."""
        state = {
            "project_path": "/test",
            "contract": {
                "interface_name": "TestFacade",
                "methods": [],
            },
            "method": None,
        }
        
        result = await generate_documentation(state)
        
        assert result["current_step"] == "document_failed"
        assert "No methods found" in result["error_message"]

    @pytest.mark.asyncio
    async def test_documents_specific_method(self, base_state):
        """Should document specific method when provided."""
        mock_doc = MethodDocumentation(
            method_name="testMethod",
            interface_name="TestFacade",
            functional_description="Test function",
            raw_signature="void testMethod()",
        )
        
        with patch("jee_codegen_orchestrator.nodes.documenter.get_settings") as mock_settings:
            mock_settings.return_value = MagicMock(
                llm_provider="openai",
                openai_api_key="test",
                openai_model="gpt-4",
                anthropic_api_key=None,
                anthropic_model=None,
            )
            
            with patch("jee_codegen_orchestrator.nodes.documenter.LLMAnalyzer") as MockAnalyzer:
                mock_analyzer = AsyncMock()
                mock_analyzer.analyze_method.return_value = mock_doc
                MockAnalyzer.return_value = mock_analyzer
                
                result = await generate_documentation(base_state)
        
        assert result["current_step"] == "documented"
        assert "testMethod" in result["documentation"]
        assert "Test function" in result["documentation"]

    @pytest.mark.asyncio
    async def test_documents_all_methods_when_no_specific(self, base_state):
        """Should document all methods when no specific method."""
        base_state["method"] = None
        base_state["contract"]["methods"] = [
            {"name": "method1", "return_type": "void", "parameters": []},
            {"name": "method2", "return_type": "String", "parameters": []},
        ]
        
        mock_doc1 = MethodDocumentation(
            method_name="method1",
            interface_name="TestFacade",
            functional_description="First method",
            raw_signature="void method1()",
        )
        mock_doc2 = MethodDocumentation(
            method_name="method2",
            interface_name="TestFacade",
            functional_description="Second method",
            raw_signature="String method2()",
        )
        
        with patch("jee_codegen_orchestrator.nodes.documenter.get_settings") as mock_settings:
            mock_settings.return_value = MagicMock(
                llm_provider="openai",
                openai_api_key="test",
                openai_model="gpt-4",
                anthropic_api_key=None,
                anthropic_model=None,
            )
            
            with patch("jee_codegen_orchestrator.nodes.documenter.LLMAnalyzer") as MockAnalyzer:
                mock_analyzer = AsyncMock()
                mock_analyzer.analyze_method.side_effect = [mock_doc1, mock_doc2]
                MockAnalyzer.return_value = mock_analyzer
                
                result = await generate_documentation(base_state)
        
        assert result["current_step"] == "documented"
        assert "method1" in result["documentation"]
        assert "method2" in result["documentation"]
        assert "---" in result["documentation"]  # Separator between methods

    @pytest.mark.asyncio
    async def test_handles_analyzer_exception(self, base_state):
        """Should handle analyzer exceptions."""
        with patch("jee_codegen_orchestrator.nodes.documenter.get_settings") as mock_settings:
            mock_settings.return_value = MagicMock(
                llm_provider="openai",
                openai_api_key="test",
                openai_model="gpt-4",
                anthropic_api_key=None,
                anthropic_model=None,
            )
            
            with patch("jee_codegen_orchestrator.nodes.documenter.LLMAnalyzer") as MockAnalyzer:
                mock_analyzer = AsyncMock()
                mock_analyzer.analyze_method.side_effect = Exception("LLM error")
                MockAnalyzer.return_value = mock_analyzer
                
                result = await generate_documentation(base_state)
        
        assert result["current_step"] == "document_failed"
        assert "LLM error" in result["error_message"]
