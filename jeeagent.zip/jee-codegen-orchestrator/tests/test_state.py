"""Tests for OrchestratorState and related models."""
from __future__ import annotations

from jee_codegen_orchestrator.state import (
    OrchestratorState,
    MappingHint,
    CompileError,
    FixResult,
)


class TestMappingHint:
    """Tests for MappingHint TypedDict."""

    def test_create_mapping_hint(self):
        """Should create a valid mapping hint."""
        hint: MappingHint = {
            "objeto_origen": "ParametrosTO",
            "objeto_destino": "Request",
            "campo_origen": "liquidacionVO.valorTotal",
            "campo_destino": "valorTotal",
        }
        
        assert hint["objeto_origen"] == "ParametrosTO"
        assert hint["objeto_destino"] == "Request"
        assert hint["campo_origen"] == "liquidacionVO.valorTotal"
        assert hint["campo_destino"] == "valorTotal"


class TestOrchestratorState:
    """Tests for OrchestratorState TypedDict."""

    def test_create_minimal_state(self):
        """Should create state with minimal fields."""
        state: OrchestratorState = {
            "project_path": "/path/to/project",
            "facade_name": "TestFacade",
            "output_dir": "/output",
            "base_package": "com.test",
        }
        
        assert state["project_path"] == "/path/to/project"
        assert state["facade_name"] == "TestFacade"

    def test_create_full_state(self):
        """Should create state with all fields."""
        state: OrchestratorState = {
            "project_path": "/path/to/project",
            "facade_name": "TestFacade",
            "method_name": "testMethod",
            "output_dir": "/output",
            "base_package": "com.test",
            "mapping_csv_path": "/path/to/mapping.csv",
            "mapping_hints": [
                {
                    "objeto_origen": "A",
                    "objeto_destino": "B",
                    "campo_origen": "x",
                    "campo_destino": "y",
                }
            ],
            "contract": {"interface_name": "TestFacade"},
            "method": {"name": "testMethod"},
            "documentation": "# Test Documentation",
            "generated_files": ["/path/to/file1.java", "/path/to/file2.java"],
            "compile_success": True,
            "compile_errors": [],
            "fix_attempts": 0,
            "max_fix_attempts": 3,
            "current_step": "completed",
            "error_message": None,
        }
        
        assert state["method_name"] == "testMethod"
        assert state["compile_success"] is True
        assert len(state["generated_files"]) == 2
        assert state["mapping_hints"] is not None
        assert len(state["mapping_hints"]) == 1


class TestCompileError:
    """Tests for CompileError dataclass."""

    def test_create_compile_error(self):
        """Should create a compile error."""
        error = CompileError(
            file_path="/path/to/File.java",
            line=10,
            column=15,
            message="cannot find symbol",
            error_type="error",
        )
        
        assert error.file_path == "/path/to/File.java"
        assert error.line == 10
        assert error.column == 15
        assert error.message == "cannot find symbol"
        assert error.error_type == "error"

    def test_parse_maven_error_line(self):
        """Should parse Maven compiler error format."""
        line = "[ERROR] /data/output/src/main/java/Test.java:[25,10] cannot find symbol"
        
        error = CompileError.from_maven_line(line, "/data/output")
        
        assert error is not None
        assert error.file_path == "/data/output/src/main/java/Test.java"
        assert error.line == 25
        assert error.column == 10
        assert "cannot find symbol" in error.message

    def test_parse_maven_warning_line(self):
        """Should parse Maven compiler warning format."""
        line = "[WARNING] /data/output/src/main/java/Test.java:[5,1] deprecated method"
        
        error = CompileError.from_maven_line(line, "/data/output")
        
        assert error is not None
        assert error.error_type == "warning"

    def test_parse_invalid_line_returns_none(self):
        """Should return None for non-matching lines."""
        line = "[INFO] Building project..."
        
        error = CompileError.from_maven_line(line, "/data/output")
        
        assert error is None


class TestFixResult:
    """Tests for FixResult dataclass."""

    def test_create_successful_fix(self):
        """Should create a successful fix result."""
        result = FixResult(
            success=True,
            fixed_files=["/path/to/Fixed.java"],
            remaining_errors=[],
            fix_description="Fixed missing import",
        )
        
        assert result.success is True
        assert len(result.fixed_files) == 1
        assert len(result.remaining_errors) == 0

    def test_create_failed_fix(self):
        """Should create a failed fix result."""
        remaining = CompileError(
            file_path="/path/to/File.java",
            line=10,
            column=5,
            message="type mismatch",
            error_type="error",
        )
        result = FixResult(
            success=False,
            fixed_files=[],
            remaining_errors=[remaining],
            fix_description="Could not resolve type mismatch",
        )
        
        assert result.success is False
        assert len(result.remaining_errors) == 1

    def test_default_values(self):
        """Should use default empty lists."""
        result = FixResult(success=True)
        
        assert result.fixed_files == []
        assert result.remaining_errors == []
        assert result.fix_description == ""
