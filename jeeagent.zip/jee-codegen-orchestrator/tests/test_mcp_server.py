"""Tests for MCP server tools."""
import pytest
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from pathlib import Path
from tempfile import TemporaryDirectory

import sys
sys.path.insert(0, "/data/agente/jee-codegen-orchestrator/src")

from jee_codegen_orchestrator.mcp_server import (
    _get_cache_key,
    _get_cached_contract,
    _set_cached_contract,
    _convert_mapping_hints,
    _contract_cache,
    _cache_stats,
    mcp,
)
from jee_codegen_orchestrator.mcp_models import (
    MappingHintInput,
    CachedContract,
)


class TestCacheKey:
    """Tests for cache key generation."""

    def test_generates_key(self):
        """Should generate consistent cache key."""
        key = _get_cache_key("/data/project", "TestFacade")
        assert key == "/data/project::TestFacade"

    def test_unique_keys(self):
        """Should generate unique keys for different inputs."""
        key1 = _get_cache_key("/data/project1", "Facade")
        key2 = _get_cache_key("/data/project2", "Facade")
        key3 = _get_cache_key("/data/project1", "OtherFacade")
        
        assert key1 != key2
        assert key1 != key3


class TestConvertMappingHints:
    """Tests for mapping hints conversion."""

    def test_converts_hints(self):
        """Should convert MCP hints to internal format."""
        hints = [
            MappingHintInput(
                source_object="PropuestaVO",
                target_object="PropuestaRequest",
                source_field="id",
                target_field="identificador",
            ),
        ]
        
        result = _convert_mapping_hints(hints)
        
        assert len(result) == 1
        assert result[0]["objeto_origen"] == "PropuestaVO"
        assert result[0]["objeto_destino"] == "PropuestaRequest"
        assert result[0]["campo_origen"] == "id"
        assert result[0]["campo_destino"] == "identificador"

    def test_empty_list(self):
        """Should handle empty list."""
        result = _convert_mapping_hints([])
        assert result == []


class TestContractCache:
    """Tests for contract caching."""

    def setup_method(self):
        """Clear cache before each test."""
        _contract_cache.clear()
        _cache_stats["hits"] = 0
        _cache_stats["misses"] = 0

    def test_set_and_get_cached(self):
        """Should cache and retrieve contract."""
        contract_data = {"interface_name": "TestFacade", "methods": []}
        
        _set_cached_contract("/data/test", "TestFacade", contract_data)
        result = _get_cached_contract("/data/test", "TestFacade")
        
        assert result is not None
        assert result["interface_name"] == "TestFacade"
        assert _cache_stats["hits"] == 1

    def test_cache_miss(self):
        """Should return None for cache miss."""
        result = _get_cached_contract("/data/nonexistent", "Unknown")
        
        assert result is None
        assert _cache_stats["misses"] == 1

    def test_expired_entry_removed(self):
        """Should remove expired entries."""
        key = _get_cache_key("/data/test", "TestFacade")
        now = datetime.now()
        
        # Insert expired entry directly
        _contract_cache[key] = CachedContract(
            project_path="/data/test",
            facade_name="TestFacade",
            contract_data={"test": True},
            scanned_at=now - timedelta(hours=1),
            expires_at=now - timedelta(minutes=30),
        )
        
        result = _get_cached_contract("/data/test", "TestFacade")
        
        assert result is None
        assert key not in _contract_cache


class TestMcpTools:
    """Tests for MCP tools registration."""

    def test_tools_registered(self):
        """Should have all expected tools registered."""
        tools = list(mcp._tool_manager._tools.keys())
        
        assert "migrate_facade_method" in tools
        assert "list_facades" in tools
        assert "validate_mapping_csv" in tools
        assert "get_cache_stats" in tools
        assert "clear_cache" in tools
        assert "get_migration_status" in tools


class TestValidateMappingCsv:
    """Tests for validate_mapping_csv tool."""

    @pytest.mark.asyncio
    async def test_file_not_found(self):
        """Should report error for missing file."""
        from jee_codegen_orchestrator.mcp_server import validate_mapping_csv
        
        ctx = MagicMock()
        result = await validate_mapping_csv(ctx, "/nonexistent/file.csv")
        
        assert "File not found" in result or "not found" in result.lower()

    @pytest.mark.asyncio
    async def test_valid_csv(self):
        """Should validate correct CSV."""
        from jee_codegen_orchestrator.mcp_server import validate_mapping_csv
        
        with TemporaryDirectory() as tmpdir:
            csv_path = Path(tmpdir) / "mapping.csv"
            csv_path.write_text(
                "ObjetoOrigen,ObjetoDestino,campoOrigen,campoDestino\n"
                "PropuestaVO,PropuestaRequest,id,identificador\n"
            )
            
            ctx = MagicMock()
            result = await validate_mapping_csv(ctx, str(csv_path))
            
            assert "✅ Yes" in result
            assert "PropuestaVO" in result


class TestGetCacheStats:
    """Tests for get_cache_stats tool."""

    def setup_method(self):
        """Clear cache before each test."""
        _contract_cache.clear()
        _cache_stats["hits"] = 0
        _cache_stats["misses"] = 0

    @pytest.mark.asyncio
    async def test_empty_cache_stats(self):
        """Should report empty cache."""
        from jee_codegen_orchestrator.mcp_server import get_cache_stats
        
        ctx = MagicMock()
        result = await get_cache_stats(ctx)
        
        assert "Entries:** 0" in result
        assert "Hit Rate:** 0" in result

    @pytest.mark.asyncio
    async def test_with_entries(self):
        """Should report cache entries."""
        from jee_codegen_orchestrator.mcp_server import get_cache_stats
        
        _set_cached_contract("/data/test", "TestFacade", {"test": True})
        _cache_stats["hits"] = 5
        _cache_stats["misses"] = 5
        
        ctx = MagicMock()
        result = await get_cache_stats(ctx)
        
        assert "Entries:** 1" in result
        assert "50" in result  # 50% hit rate


class TestClearCache:
    """Tests for clear_cache tool."""

    @pytest.mark.asyncio
    async def test_clears_cache(self):
        """Should clear all cached contracts."""
        from jee_codegen_orchestrator.mcp_server import clear_cache
        
        # Clear any entries from previous tests
        _contract_cache.clear()
        
        _set_cached_contract("/data/test1", "Facade1", {})
        _set_cached_contract("/data/test2", "Facade2", {})
        _cache_stats["hits"] = 10
        
        ctx = MagicMock()
        result = await clear_cache(ctx)
        
        assert "2 cached contracts" in result
        assert len(_contract_cache) == 0
        assert _cache_stats["hits"] == 0


class TestGetMigrationStatus:
    """Tests for get_migration_status tool."""

    @pytest.mark.asyncio
    async def test_not_found(self):
        """Should report not found for unknown run_id."""
        from jee_codegen_orchestrator.mcp_server import get_migration_status
        
        ctx = MagicMock()
        result = await get_migration_status(ctx, "unknown-id")
        
        assert "Not Found" in result

    @pytest.mark.asyncio
    async def test_active_migration(self):
        """Should return status for active migration."""
        from jee_codegen_orchestrator.mcp_server import (
            get_migration_status,
            _active_migrations,
        )
        from jee_codegen_orchestrator.mcp_models import MigrationProgress, MigrationStatus
        
        run_id = "test-run-123"
        _active_migrations[run_id] = MigrationProgress(
            run_id=run_id,
            status=MigrationStatus.GENERATING,
            step_name="generate",
            step_number=3,
            total_steps=5,
            message="Generating code",
        )
        
        ctx = MagicMock()
        result = await get_migration_status(ctx, run_id)
        
        assert "generating" in result.lower()
        assert "3/5" in result
        
        # Cleanup
        del _active_migrations[run_id]
