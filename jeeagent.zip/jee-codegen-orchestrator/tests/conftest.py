"""Pytest configuration and shared fixtures for jee-codegen-orchestrator tests."""
import sys
from pathlib import Path

import pytest

# Add source paths to Python path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
sys.path.insert(0, "/data/agente/quarkus-codegen-agent/src")
sys.path.insert(0, "/data/agente/jee-doc-agent/src")
sys.path.insert(0, "/data/agente/intepreter-jee-mcp-server/src")


@pytest.fixture
def sample_contract_dict():
    """Create a sample contract dictionary for tests."""
    return {
        "interface_name": "TestFacade",
        "annotation": "@Remote",
        "file_path": "/src/TestFacade.java",
        "related_manager_path": "/src/TestFacadeManager.java",
        "methods": [
            {
                "name": "consultarDatos",
                "return_type": "ResultadoTO",
                "parameters": [
                    {
                        "name": "filtro",
                        "type_hint": "FiltroVO",
                        "dto": {
                            "name": "FiltroVO",
                            "file_path": "/src/FiltroVO.java",
                            "fields": [
                                {"name": "id", "type_hint": "Long", "nested_dto": None},
                                {"name": "nombre", "type_hint": "String", "nested_dto": None},
                            ],
                        },
                        "dto_fields": None,
                    }
                ],
                "documentation": None,
                "manager_summary": None,
            },
            {
                "name": "insertarRegistro",
                "return_type": "Long",
                "parameters": [
                    {"name": "datos", "type_hint": "DatosTO", "dto": None, "dto_fields": None},
                ],
                "documentation": "Inserta un nuevo registro",
                "manager_summary": None,
            },
        ],
    }


@pytest.fixture
def sample_method_dict():
    """Create a sample method dictionary for tests."""
    return {
        "name": "consultarDatos",
        "return_type": "ResultadoTO",
        "parameters": [
            {
                "name": "filtro",
                "type_hint": "FiltroVO",
                "dto": {
                    "name": "FiltroVO",
                    "fields": [
                        {"name": "id", "type_hint": "Long"},
                        {"name": "nombre", "type_hint": "String"},
                    ],
                },
                "dto_fields": None,
            }
        ],
    }


@pytest.fixture
def sample_mapping_hints():
    """Create sample mapping hints."""
    return [
        {
            "objeto_origen": "FiltroVO",
            "objeto_destino": "ConsultarDatosRequest",
            "campo_origen": "id",
            "campo_destino": "identificador",
        },
        {
            "objeto_origen": "FiltroVO",
            "objeto_destino": "ConsultarDatosRequest",
            "campo_origen": "nombre",
            "campo_destino": "nombreCompleto",
        },
        {
            "objeto_origen": "ResultadoTO",
            "objeto_destino": "ConsultarDatosResponse",
            "campo_origen": "valor",
            "campo_destino": "valorTotal",
        },
    ]


@pytest.fixture
def sample_base_state(sample_contract_dict, sample_method_dict):
    """Create a sample orchestrator state for tests."""
    return {
        "project_path": "/data/test-project",
        "facade_name": "TestFacade",
        "method_name": "consultarDatos",
        "output_path": "/data/output",
        "base_package": "com.test",
        "contract": sample_contract_dict,
        "method": sample_method_dict,
        "documentation": None,
        "generated_files": [],
        "compile_success": False,
        "compile_errors": [],
        "fix_attempts": 0,
        "max_fix_attempts": 3,
        "current_step": "initialized",
        "error_message": None,
        "mapping_csv_path": None,
        "mapping_hints": [],
    }
