"""Tests for CLI module."""
import pytest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import AsyncMock, MagicMock, patch

from typer.testing import CliRunner

import sys
sys.path.insert(0, "/data/agente/jee-codegen-orchestrator/src")

from jee_codegen_orchestrator.cli import app


@pytest.fixture
def runner():
    """Create CLI runner."""
    return CliRunner()


@pytest.fixture
def temp_project():
    """Create temporary project directory."""
    with TemporaryDirectory() as tmpdir:
        yield tmpdir


class TestMethodCommand:
    """Tests for the 'method' command."""

    def test_help_displayed(self, runner):
        """Should display help text."""
        result = runner.invoke(app, ["method", "--help"])
        assert result.exit_code == 0
        assert "Generate Quarkus hexagonal code" in result.stdout

    def test_requires_project_path(self, runner):
        """Should require project path argument."""
        result = runner.invoke(app, ["method", "-i", "TestFacade"])
        assert result.exit_code != 0

    def test_requires_interface_option(self, runner, temp_project):
        """Should require interface option."""
        result = runner.invoke(app, ["method", temp_project])
        assert result.exit_code != 0
        assert "Missing option" in result.stdout or "required" in result.stdout.lower()

    def test_validates_project_path_exists(self, runner):
        """Should error if project path doesn't exist."""
        result = runner.invoke(app, [
            "method", "/nonexistent/path",
            "-i", "TestFacade",
        ])
        assert result.exit_code == 1
        assert "does not exist" in result.stdout

    def test_accepts_method_option(self, runner, temp_project):
        """Should accept optional method option."""
        with patch("jee_codegen_orchestrator.cli.asyncio.run") as mock_run:
            mock_run.return_value = {
                "compile_success": True,
                "generated_files": [],
            }
            
            result = runner.invoke(app, [
                "method", temp_project,
                "-i", "TestFacade",
                "-m", "consultarDatos",
            ])
            
            # Should have called orchestrator with method name
            call_kwargs = mock_run.call_args[0][0].__self__.__dict__ if hasattr(mock_run.call_args[0][0], '__self__') else {}

    def test_accepts_output_option(self, runner, temp_project):
        """Should accept output directory option."""
        with patch("jee_codegen_orchestrator.cli.asyncio.run") as mock_run:
            mock_run.return_value = {
                "compile_success": True,
                "generated_files": [],
            }
            
            result = runner.invoke(app, [
                "method", temp_project,
                "-i", "TestFacade",
                "-o", "/custom/output",
            ])
            
            assert "/custom/output" in result.stdout

    def test_accepts_package_option(self, runner, temp_project):
        """Should accept base package option."""
        with patch("jee_codegen_orchestrator.cli.asyncio.run") as mock_run:
            mock_run.return_value = {
                "compile_success": True,
                "generated_files": [],
            }
            
            result = runner.invoke(app, [
                "method", temp_project,
                "-i", "TestFacade",
                "-p", "com.mycompany",
            ])

    def test_accepts_max_retries_option(self, runner, temp_project):
        """Should accept max retries option."""
        with patch("jee_codegen_orchestrator.cli.asyncio.run") as mock_run:
            mock_run.return_value = {
                "compile_success": True,
                "generated_files": [],
            }
            
            result = runner.invoke(app, [
                "method", temp_project,
                "-i", "TestFacade",
                "--max-retries", "5",
            ])
            
            assert "Max retries: 5" in result.stdout

    def test_accepts_mapping_csv_option(self, runner, temp_project):
        """Should accept mapping CSV option."""
        # Create CSV file in project
        csv_path = Path(temp_project) / "mapping.csv"
        csv_path.write_text("ObjetoOrigen,ObjetoDestino,campoOrigen,campoDestino\n")
        
        with patch("jee_codegen_orchestrator.cli.asyncio.run") as mock_run:
            mock_run.return_value = {
                "compile_success": True,
                "generated_files": [],
            }
            
            result = runner.invoke(app, [
                "method", temp_project,
                "-i", "TestFacade",
                "--mapping-csv", "mapping.csv",
            ])
            
            assert "Mapping CSV:" in result.stdout

    def test_warns_for_missing_mapping_csv(self, runner, temp_project):
        """Should warn when mapping CSV not found."""
        with patch("jee_codegen_orchestrator.cli.asyncio.run") as mock_run:
            mock_run.return_value = {
                "compile_success": True,
                "generated_files": [],
            }
            
            result = runner.invoke(app, [
                "method", temp_project,
                "-i", "TestFacade",
                "--mapping-csv", "nonexistent.csv",
            ])
            
            assert "Warning: Mapping CSV not found" in result.stdout

    def test_reports_success(self, runner, temp_project):
        """Should report success when compilation passes."""
        with patch("jee_codegen_orchestrator.cli.asyncio.run") as mock_run:
            mock_run.return_value = {
                "compile_success": True,
                "generated_files": ["file1.java", "file2.java"],
            }
            
            result = runner.invoke(app, [
                "method", temp_project,
                "-i", "TestFacade",
            ])
            
            assert result.exit_code == 0
            assert "Migration completed successfully" in result.stdout
            assert "Generated 2 files" in result.stdout

    def test_reports_failure_with_errors(self, runner, temp_project):
        """Should report failure when compilation fails."""
        with patch("jee_codegen_orchestrator.cli.asyncio.run") as mock_run:
            mock_run.return_value = {
                "compile_success": False,
                "fix_attempts": 3,
                "compile_errors": [
                    {"file_path": "Test.java", "line": 10, "message": "Cannot resolve symbol"},
                ],
            }
            
            result = runner.invoke(app, [
                "method", temp_project,
                "-i", "TestFacade",
            ])
            
            assert result.exit_code == 1
            assert "Migration completed with errors" in result.stdout
            assert "Remaining compilation errors" in result.stdout

    def test_shows_generated_files(self, runner, temp_project):
        """Should show list of generated files."""
        files = [f"file{i}.java" for i in range(15)]
        
        with patch("jee_codegen_orchestrator.cli.asyncio.run") as mock_run:
            mock_run.return_value = {
                "compile_success": True,
                "generated_files": files,
            }
            
            result = runner.invoke(app, [
                "method", temp_project,
                "-i", "TestFacade",
            ])
            
            assert "Generated files:" in result.stdout
            assert "file0.java" in result.stdout
            assert "... and 5 more" in result.stdout  # Truncated to 10

    def test_handles_exception(self, runner, temp_project):
        """Should handle exceptions gracefully."""
        with patch("jee_codegen_orchestrator.cli.asyncio.run") as mock_run:
            mock_run.side_effect = Exception("Connection failed")
            
            result = runner.invoke(app, [
                "method", temp_project,
                "-i", "TestFacade",
            ])
            
            assert result.exit_code == 1
            assert "Connection failed" in result.stdout


class TestVerifyCommand:
    """Tests for the 'verify' command."""

    def test_help_displayed(self, runner):
        """Should display help text."""
        result = runner.invoke(app, ["verify", "--help"])
        assert result.exit_code == 0
        assert "Verify that the generated code compiles" in result.stdout

    def test_requires_pom_xml(self, runner, temp_project):
        """Should error if pom.xml not found."""
        result = runner.invoke(app, ["verify", temp_project])
        assert result.exit_code == 1
        assert "No pom.xml found" in result.stdout

    def test_runs_maven_compile(self, runner, temp_project):
        """Should run mvn compile."""
        # Create pom.xml
        (Path(temp_project) / "pom.xml").write_text("<project></project>")
        
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            
            result = runner.invoke(app, ["verify", temp_project])
            
            assert "Compilation successful" in result.stdout
            mock_run.assert_called_once()
            assert mock_run.call_args.args[0] == ["mvn", "compile"]

    def test_reports_compilation_failure(self, runner, temp_project):
        """Should report compilation failure."""
        (Path(temp_project) / "pom.xml").write_text("<project></project>")
        
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=1,
                stdout="BUILD FAILURE",
                stderr="Error details",
            )
            
            result = runner.invoke(app, ["verify", temp_project])
            
            assert result.exit_code == 1
            assert "Compilation failed" in result.stdout

    def test_handles_timeout(self, runner, temp_project):
        """Should handle compilation timeout."""
        import subprocess
        
        (Path(temp_project) / "pom.xml").write_text("<project></project>")
        
        with patch("subprocess.run") as mock_run:
            mock_run.side_effect = subprocess.TimeoutExpired("mvn", 120)
            
            result = runner.invoke(app, ["verify", temp_project])
            
            assert result.exit_code == 1
            assert "timed out" in result.stdout

    def test_handles_maven_not_found(self, runner, temp_project):
        """Should handle Maven not installed."""
        (Path(temp_project) / "pom.xml").write_text("<project></project>")
        
        with patch("subprocess.run") as mock_run:
            mock_run.side_effect = FileNotFoundError()
            
            result = runner.invoke(app, ["verify", temp_project])
            
            assert result.exit_code == 1
            assert "Maven not found" in result.stdout


class TestConfigCommand:
    """Tests for the 'config' command."""

    def test_shows_configuration(self, runner):
        """Should show configuration settings."""
        with patch("jee_codegen_orchestrator.cli.get_settings") as mock_settings:
            mock_settings.return_value = MagicMock(
                llm_provider="openai",
                anthropic_model="claude-3",
                mcp_server_path="/path/to/mcp",
                max_fix_attempts=3,
                output_base_dir="/output",
                anthropic_api_key="sk-12345678abcdefgh",
            )
            
            result = runner.invoke(app, ["config"])
            
            assert result.exit_code == 0
            assert "LLM Provider: openai" in result.stdout
            assert "Max Fix Attempts: 3" in result.stdout

    def test_masks_api_key(self, runner):
        """Should mask API key in output."""
        with patch("jee_codegen_orchestrator.cli.get_settings") as mock_settings:
            mock_settings.return_value = MagicMock(
                llm_provider="anthropic",
                anthropic_model="claude-3",
                mcp_server_path="/path",
                max_fix_attempts=3,
                output_base_dir="/output",
                anthropic_api_key="sk-12345678abcdefghijklmnop",
            )
            
            result = runner.invoke(app, ["config"])
            
            # Should show first 8 and last 4 chars
            assert "sk-12345..." in result.stdout
            assert "mnop" in result.stdout
            # Should NOT show full key
            assert "sk-12345678abcdefghijklmnop" not in result.stdout

    def test_shows_not_set_when_no_key(self, runner):
        """Should indicate when API key is not set."""
        with patch("jee_codegen_orchestrator.cli.get_settings") as mock_settings:
            mock_settings.return_value = MagicMock(
                llm_provider="anthropic",
                anthropic_model="claude-3",
                mcp_server_path="/path",
                max_fix_attempts=3,
                output_base_dir="/output",
                anthropic_api_key=None,
            )
            
            result = runner.invoke(app, ["config"])
            
            assert "NOT SET" in result.stdout
