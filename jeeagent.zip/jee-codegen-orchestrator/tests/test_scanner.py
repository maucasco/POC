"""Tests for scanner node."""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
import sys

sys.path.insert(0, "/data/agente/jee-codegen-orchestrator/src")
sys.path.insert(0, "/data/agente/quarkus-codegen-agent/src")

from jee_codegen_orchestrator.nodes.scanner import scan_project, _dto_to_dict
from quarkus_codegen_agent.models import (
    DtoDefinition,
    DtoField,
    EjbContract,
    MethodSignature,
    MethodParameter,
)


class TestDtoToDict:
    """Tests for _dto_to_dict conversion function."""

    def test_none_returns_none(self):
        """Should return None for None input."""
        assert _dto_to_dict(None) is None

    def test_simple_dto(self):
        """Should convert simple DTO to dict."""
        dto = DtoDefinition(
            name="TestTO",
            file_path="/src/TestTO.java",
            fields=[
                DtoField(name="id", type_hint="Long"),
                DtoField(name="nombre", type_hint="String"),
            ],
        )
        
        result = _dto_to_dict(dto)
        
        assert result["name"] == "TestTO"
        assert result["file_path"] == "/src/TestTO.java"
        assert len(result["fields"]) == 2
        assert result["fields"][0]["name"] == "id"
        assert result["fields"][0]["type_hint"] == "Long"

    def test_dto_without_file_path(self):
        """Should handle DTO without file_path."""
        dto = DtoDefinition(name="SimpleTO", fields=[])
        
        result = _dto_to_dict(dto)
        
        assert result["file_path"] is None

    def test_nested_dto(self):
        """Should convert nested DTOs recursively."""
        nested = DtoDefinition(name="NestedTO", fields=[
            DtoField(name="valor", type_hint="String"),
        ])
        dto = DtoDefinition(
            name="ParentTO",
            fields=[
                DtoField(name="nested", type_hint="NestedTO", nested_dto=nested),
            ],
        )
        
        result = _dto_to_dict(dto)
        
        nested_field = result["fields"][0]
        assert nested_field["nested_dto"] is not None
        assert nested_field["nested_dto"]["name"] == "NestedTO"
        assert len(nested_field["nested_dto"]["fields"]) == 1


class TestScanProject:
    """Tests for scan_project function."""

    @pytest.fixture
    def base_state(self):
        """Create base state for tests."""
        return {
            "project_path": "/data/test-project",
            "facade_name": "TestFacade",
            "method_name": None,
            "output_path": "/data/output",
        }

    @pytest.fixture
    def mock_contract(self):
        """Create mock EJB contract."""
        return EjbContract(
            interface_name="TestFacade",
            annotation="@Remote",
            file_path="/data/test-project/TestFacade.java",
            methods=[
                MethodSignature(
                    name="consultarDatos",
                    return_type="ResultadoTO",
                    parameters=[
                        MethodParameter(name="filtro", type_hint="FiltroVO"),
                    ],
                ),
                MethodSignature(
                    name="insertarRegistro",
                    return_type="Long",
                    parameters=[],
                ),
            ],
        )

    @pytest.mark.asyncio
    async def test_scan_finds_facade(self, base_state, mock_contract):
        """Should find the specified facade."""
        mock_result = MagicMock()
        mock_result.contracts = [mock_contract]
        
        with patch("jee_codegen_orchestrator.nodes.scanner.McpClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.scan_project.return_value = mock_result
            MockClient.return_value = mock_client
            
            result = await scan_project(base_state)
        
        assert result["current_step"] == "scanned"
        assert result["contract"]["interface_name"] == "TestFacade"
        assert len(result["contract"]["methods"]) == 2

    @pytest.mark.asyncio
    async def test_scan_returns_error_when_facade_not_found(self, base_state, mock_contract):
        """Should return error when facade not found."""
        mock_result = MagicMock()
        mock_result.contracts = [mock_contract]  # Has TestFacade, not OtherFacade
        
        base_state["facade_name"] = "OtherFacade"
        
        with patch("jee_codegen_orchestrator.nodes.scanner.McpClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.scan_project.return_value = mock_result
            MockClient.return_value = mock_client
            
            result = await scan_project(base_state)
        
        assert result["current_step"] == "scan_failed"
        assert "OtherFacade" in result["error_message"]

    @pytest.mark.asyncio
    async def test_scan_finds_specific_method(self, base_state, mock_contract):
        """Should find specific method when method_name provided."""
        base_state["method_name"] = "consultarDatos"
        mock_result = MagicMock()
        mock_result.contracts = [mock_contract]
        
        with patch("jee_codegen_orchestrator.nodes.scanner.McpClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.scan_project.return_value = mock_result
            MockClient.return_value = mock_client
            
            result = await scan_project(base_state)
        
        assert result["current_step"] == "scanned"
        assert result["method"] is not None
        assert result["method"]["name"] == "consultarDatos"

    @pytest.mark.asyncio
    async def test_scan_returns_error_when_method_not_found(self, base_state, mock_contract):
        """Should return error when method not found."""
        base_state["method_name"] = "nonExistentMethod"
        mock_result = MagicMock()
        mock_result.contracts = [mock_contract]
        
        with patch("jee_codegen_orchestrator.nodes.scanner.McpClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.scan_project.return_value = mock_result
            MockClient.return_value = mock_client
            
            result = await scan_project(base_state)
        
        assert result["current_step"] == "scan_failed"
        assert "nonExistentMethod" in result["error_message"]

    @pytest.mark.asyncio
    async def test_scan_handles_exception(self, base_state):
        """Should handle exceptions gracefully."""
        with patch("jee_codegen_orchestrator.nodes.scanner.McpClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.scan_project.side_effect = Exception("Connection failed")
            MockClient.return_value = mock_client
            
            result = await scan_project(base_state)
        
        assert result["current_step"] == "scan_failed"
        assert "Connection failed" in result["error_message"]

    @pytest.mark.asyncio
    async def test_scan_converts_parameters_with_dto(self, base_state):
        """Should convert parameters with DTO definitions."""
        dto = DtoDefinition(
            name="FiltroVO",
            file_path="/src/FiltroVO.java",
            fields=[DtoField(name="codigo", type_hint="String")],
        )
        contract = EjbContract(
            interface_name="TestFacade",
            annotation="@Remote",
            file_path="/TestFacade.java",
            methods=[
                MethodSignature(
                    name="buscar",
                    return_type="void",
                    parameters=[
                        MethodParameter(name="filtro", type_hint="FiltroVO", dto=dto),
                    ],
                ),
            ],
        )
        
        mock_result = MagicMock()
        mock_result.contracts = [contract]
        
        with patch("jee_codegen_orchestrator.nodes.scanner.McpClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.scan_project.return_value = mock_result
            MockClient.return_value = mock_client
            
            result = await scan_project(base_state)
        
        method = result["contract"]["methods"][0]
        param = method["parameters"][0]
        assert param["dto"] is not None
        assert param["dto"]["name"] == "FiltroVO"

    @pytest.mark.asyncio
    async def test_scan_includes_manager_path(self, base_state):
        """Should include related manager path."""
        contract = EjbContract(
            interface_name="TestFacade",
            annotation="@Remote",
            file_path="/TestFacade.java",
            related_manager_path="/TestFacadeManager.java",
            methods=[],
        )
        
        mock_result = MagicMock()
        mock_result.contracts = [contract]
        
        with patch("jee_codegen_orchestrator.nodes.scanner.McpClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.scan_project.return_value = mock_result
            MockClient.return_value = mock_client
            
            result = await scan_project(base_state)
        
        assert result["contract"]["related_manager_path"] == "/TestFacadeManager.java"


class TestScanProjectIntegration:
    """Integration-style tests for scan_project."""

    @pytest.mark.asyncio
    async def test_scan_all_methods_when_no_method_specified(self):
        """Should include all methods when no specific method requested."""
        contract = EjbContract(
            interface_name="MultiFacade",
            annotation="@Remote",
            file_path="/MultiFacade.java",
            methods=[
                MethodSignature(name="method1", return_type="void"),
                MethodSignature(name="method2", return_type="String"),
                MethodSignature(name="method3", return_type="int"),
            ],
        )
        
        mock_result = MagicMock()
        mock_result.contracts = [contract]
        
        state = {
            "project_path": "/test",
            "facade_name": "MultiFacade",
            "method_name": None,
            "output_path": "/output",
        }
        
        with patch("jee_codegen_orchestrator.nodes.scanner.McpClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.scan_project.return_value = mock_result
            MockClient.return_value = mock_client
            
            result = await scan_project(state)
        
        assert result["method"] is None  # No specific method
        assert len(result["contract"]["methods"]) == 3
