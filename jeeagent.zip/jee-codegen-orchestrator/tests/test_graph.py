"""Tests for CSV mapping parsing in graph.py."""
from __future__ import annotations

from pathlib import Path

import pytest

from jee_codegen_orchestrator.graph import _parse_mapping_csv


class TestParseMappingCSV:
    """Tests for CSV mapping file parsing."""

    def test_parse_valid_csv(self, tmp_path: Path):
        """Should parse a valid CSV file."""
        csv_content = """ObjetoOrigen,ObjetoDestino,campoOrigen,campoDestino
ParametrosTO,Request,codigo,codigo
ParametrosTO,Request,liquidacionVO.valor,valor
OtroTO,Response,resultado,resultado"""
        
        csv_file = tmp_path / "mapping.csv"
        csv_file.write_text(csv_content)
        
        hints = _parse_mapping_csv(str(csv_file))
        
        assert len(hints) == 3
        assert hints[0]["objeto_origen"] == "ParametrosTO"
        assert hints[0]["campo_origen"] == "codigo"
        assert hints[1]["campo_origen"] == "liquidacionVO.valor"

    def test_parse_csv_with_depth_3(self, tmp_path: Path):
        """Should parse CSV with deep nested paths."""
        csv_content = """ObjetoOrigen,ObjetoDestino,campoOrigen,campoDestino
ParamsTO,Req,a.b.c,x"""
        
        csv_file = tmp_path / "deep.csv"
        csv_file.write_text(csv_content)
        
        hints = _parse_mapping_csv(str(csv_file))
        
        assert len(hints) == 1
        assert hints[0]["campo_origen"] == "a.b.c"
        # Verify depth
        assert hints[0]["campo_origen"].count(".") == 2  # depth 3

    def test_parse_empty_csv(self, tmp_path: Path):
        """Should return empty list for CSV with only headers."""
        csv_content = "ObjetoOrigen,ObjetoDestino,campoOrigen,campoDestino\n"
        
        csv_file = tmp_path / "empty.csv"
        csv_file.write_text(csv_content)
        
        hints = _parse_mapping_csv(str(csv_file))
        
        assert hints == []

    def test_parse_csv_missing_header(self, tmp_path: Path):
        """Should return empty list for CSV with wrong headers."""
        csv_content = """WrongColumn1,WrongColumn2
value1,value2"""
        
        csv_file = tmp_path / "bad_header.csv"
        csv_file.write_text(csv_content)
        
        hints = _parse_mapping_csv(str(csv_file))
        
        assert hints == []

    def test_parse_csv_incomplete_rows(self, tmp_path: Path):
        """Should skip rows with missing values."""
        csv_content = """ObjetoOrigen,ObjetoDestino,campoOrigen,campoDestino
Complete,Complete,complete,complete
Incomplete,,incomplete,"""
        
        csv_file = tmp_path / "incomplete.csv"
        csv_file.write_text(csv_content)
        
        hints = _parse_mapping_csv(str(csv_file))
        
        assert len(hints) == 1
        assert hints[0]["objeto_origen"] == "Complete"

    def test_parse_nonexistent_file(self):
        """Should return empty list for non-existent file."""
        hints = _parse_mapping_csv("/nonexistent/path/mapping.csv")
        
        assert hints == []

    def test_parse_csv_strips_whitespace(self, tmp_path: Path):
        """Should strip whitespace from values."""
        csv_content = """ObjetoOrigen,ObjetoDestino,campoOrigen,campoDestino
  SpacedTO  ,  Request  ,  campo  ,  destino  """
        
        csv_file = tmp_path / "spaced.csv"
        csv_file.write_text(csv_content)
        
        hints = _parse_mapping_csv(str(csv_file))
        
        assert hints[0]["objeto_origen"] == "SpacedTO"
        assert hints[0]["objeto_destino"] == "Request"
        assert hints[0]["campo_origen"] == "campo"
        assert hints[0]["campo_destino"] == "destino"

    def test_parse_csv_utf8_encoding(self, tmp_path: Path):
        """Should handle UTF-8 encoded CSV with special characters."""
        csv_content = """ObjetoOrigen,ObjetoDestino,campoOrigen,campoDestino
ObjetoOrigenTO,SolicitudRequest,códigoDocumento,codigoDocumento
ObjetoOrigenTO,SolicitudRequest,añoFacturación,anoFacturacion"""
        
        csv_file = tmp_path / "utf8.csv"
        csv_file.write_text(csv_content, encoding="utf-8")
        
        hints = _parse_mapping_csv(str(csv_file))
        
        assert len(hints) == 2
        assert "código" in hints[0]["campo_origen"]
        assert "año" in hints[1]["campo_origen"]
