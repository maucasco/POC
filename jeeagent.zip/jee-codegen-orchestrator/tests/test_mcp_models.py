"""Tests for MCP server models."""
import pytest
from datetime import datetime, timedelta

from jee_codegen_orchestrator.mcp_models import (
    MigrationStatus,
    OasFragment,
    MappingHintInput,
    MigrationRequest,
    CompileError,
    GeneratedFileInfo,
    MigrationProgress,
    MigrationResult,
    FacadeInfo,
    ListFacadesResult,
    ValidationResult,
    CachedContract,
    CacheStats,
)


class TestMigrationStatus:
    """Tests for MigrationStatus enum."""

    def test_all_statuses(self):
        """Should have all expected statuses."""
        assert MigrationStatus.PENDING == "pending"
        assert MigrationStatus.SCANNING == "scanning"
        assert MigrationStatus.GENERATING == "generating"
        assert MigrationStatus.COMPILING == "compiling"
        assert MigrationStatus.COMPLETED == "completed"
        assert MigrationStatus.FAILED == "failed"


class TestOasFragment:
    """Tests for OasFragment model."""

    def test_minimal_fragment(self):
        """Should create fragment with defaults."""
        fragment = OasFragment()
        assert fragment.path is None
        assert fragment.tags == []

    def test_full_fragment(self):
        """Should create fragment with all fields."""
        fragment = OasFragment(
            path="/api/v1/propuestas",
            operation_id="consultarPropuesta",
            schema_name="PropuestaResponse",
            schema_definition={"type": "object", "properties": {}},
            tags=["propuestas"],
            summary="Consulta propuesta por ID",
        )
        assert fragment.path == "/api/v1/propuestas"
        assert fragment.operation_id == "consultarPropuesta"


class TestMappingHintInput:
    """Tests for MappingHintInput model."""

    def test_create_with_aliases(self):
        """Should create hint using Spanish aliases."""
        hint = MappingHintInput(
            ObjetoOrigen="PropuestaVO",
            ObjetoDestino="PropuestaRequest",
            campoOrigen="id",
            campoDestino="identificador",
        )
        assert hint.source_object == "PropuestaVO"
        assert hint.target_object == "PropuestaRequest"
        assert hint.source_field == "id"
        assert hint.target_field == "identificador"

    def test_create_with_english_names(self):
        """Should also work with English field names."""
        hint = MappingHintInput(
            source_object="PropuestaVO",
            target_object="PropuestaRequest",
            source_field="id",
            target_field="identificador",
        )
        assert hint.source_object == "PropuestaVO"


class TestMigrationRequest:
    """Tests for MigrationRequest model."""

    def test_minimal_request(self):
        """Should create request with required fields only."""
        request = MigrationRequest(
            project_path="/data/proyecto",
            facade_name="MiFacade",
        )
        assert request.project_path == "/data/proyecto"
        assert request.facade_name == "MiFacade"
        assert request.method_name is None
        assert request.output_dir == "/data/agente/output"
        assert request.base_package == "com.davivienda"
        assert request.max_fix_attempts == 3

    def test_full_request(self):
        """Should create request with all fields."""
        request = MigrationRequest(
            project_path="/data/proyecto",
            facade_name="MiFacade",
            method_name="consultarDatos",
            output_dir="/custom/output",
            base_package="com.mycompany",
            max_fix_attempts=5,
            mapping_hints=[
                MappingHintInput(
                    source_object="A",
                    target_object="B",
                    source_field="x",
                    target_field="y",
                )
            ],
            skip_documentation=True,
        )
        assert request.method_name == "consultarDatos"
        assert len(request.mapping_hints) == 1
        assert request.skip_documentation is True


class TestMigrationResult:
    """Tests for MigrationResult model."""

    def test_success_result(self):
        """Should create success result."""
        result = MigrationResult(
            success=True,
            status=MigrationStatus.COMPLETED,
            facade_name="TestFacade",
            started_at=datetime.now(),
            completed_at=datetime.now(),
            compile_success=True,
            total_files=10,
        )
        assert result.success is True
        assert result.status == MigrationStatus.COMPLETED

    def test_to_summary_success(self):
        """Should generate success summary."""
        result = MigrationResult(
            success=True,
            status=MigrationStatus.COMPLETED,
            facade_name="TestFacade",
            method_name="test",
            started_at=datetime.now(),
            completed_at=datetime.now(),
            duration_seconds=5.5,
            compile_success=True,
            total_files=10,
        )
        summary = result.to_summary()
        
        assert "TestFacade" in summary
        assert "✅ Success" in summary
        assert "5.5s" in summary
        assert "10" in summary

    def test_to_summary_failure(self):
        """Should generate failure summary."""
        result = MigrationResult(
            success=False,
            status=MigrationStatus.FAILED,
            facade_name="TestFacade",
            started_at=datetime.now(),
            compile_success=False,
            compile_errors=[
                CompileError(file_path="Test.java", message="Error"),
            ],
            fix_attempts=3,
            error_message="Compilation failed after 3 attempts",
        )
        summary = result.to_summary()
        
        assert "❌ Failed" in summary
        assert "1 errors" in summary
        assert "3" in summary
        assert "Compilation failed" in summary


class TestCachedContract:
    """Tests for CachedContract model."""

    def test_not_expired(self):
        """Should not be expired when within TTL."""
        now = datetime.now()
        cached = CachedContract(
            project_path="/test",
            facade_name="Test",
            contract_data={},
            scanned_at=now,
            expires_at=now + timedelta(minutes=30),
        )
        assert cached.is_expired() is False

    def test_expired(self):
        """Should be expired when past TTL."""
        now = datetime.now()
        cached = CachedContract(
            project_path="/test",
            facade_name="Test",
            contract_data={},
            scanned_at=now - timedelta(hours=1),
            expires_at=now - timedelta(minutes=30),
        )
        assert cached.is_expired() is True


class TestCacheStats:
    """Tests for CacheStats model."""

    def test_hit_rate_calculation(self):
        """Should calculate hit rate."""
        stats = CacheStats(
            total_entries=5,
            hit_count=80,
            miss_count=20,
            hit_rate=0.8,
        )
        assert stats.hit_rate == 0.8
        assert stats.total_entries == 5
