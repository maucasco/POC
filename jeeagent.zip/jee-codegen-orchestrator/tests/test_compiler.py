"""Tests for compiler node."""
from __future__ import annotations

from pathlib import Path
from unittest.mock import patch, MagicMock
import subprocess

import pytest

from jee_codegen_orchestrator.nodes.compiler import (
    compile_code,
    should_fix,
    _parse_maven_errors,
    _error_to_dict,
)
from jee_codegen_orchestrator.state import OrchestratorState, CompileError


class TestCompileCode:
    """Tests for compile_code function."""

    @pytest.mark.asyncio
    async def test_compile_success(self, tmp_path: Path):
        """Should detect successful compilation."""
        # Create a minimal pom.xml
        pom_content = """<?xml version="1.0"?>
<project>
    <modelVersion>4.0.0</modelVersion>
    <groupId>test</groupId>
    <artifactId>test</artifactId>
    <version>1.0</version>
</project>"""
        (tmp_path / "pom.xml").write_text(pom_content)
        
        state: OrchestratorState = {
            "project_path": "/path",
            "facade_name": "Test",
            "output_dir": str(tmp_path),
            "base_package": "com.test",
            "current_step": "generated",
        }
        
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0,
                stdout="BUILD SUCCESS",
                stderr="",
            )
            
            result = await compile_code(state)
            
            assert result["compile_success"] is True
            assert result["compile_errors"] == []
            assert result["current_step"] == "compiled"

    @pytest.mark.asyncio
    async def test_compile_failure(self, tmp_path: Path):
        """Should detect compilation failure."""
        (tmp_path / "pom.xml").write_text("<project/>")
        
        state: OrchestratorState = {
            "project_path": "/path",
            "facade_name": "Test",
            "output_dir": str(tmp_path),
            "base_package": "com.test",
            "current_step": "generated",
        }
        
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=1,
                stdout="""[ERROR] /src/Test.java:[10,5] cannot find symbol""",
                stderr="",
            )
            
            result = await compile_code(state)
            
            assert result["compile_success"] is False
            assert result["current_step"] == "compile_failed"

    @pytest.mark.asyncio
    async def test_no_pom_file(self, tmp_path: Path):
        """Should fail if no pom.xml exists."""
        state: OrchestratorState = {
            "project_path": "/path",
            "facade_name": "Test",
            "output_dir": str(tmp_path),
            "base_package": "com.test",
            "current_step": "generated",
        }
        
        result = await compile_code(state)
        
        assert result["compile_success"] is False
        assert "No pom.xml" in result["compile_errors"][0]
        assert result["current_step"] == "compile_failed"

    @pytest.mark.asyncio
    async def test_compile_timeout(self, tmp_path: Path):
        """Should handle compilation timeout."""
        (tmp_path / "pom.xml").write_text("<project/>")
        
        state: OrchestratorState = {
            "project_path": "/path",
            "facade_name": "Test",
            "output_dir": str(tmp_path),
            "base_package": "com.test",
            "current_step": "generated",
        }
        
        with patch("subprocess.run") as mock_run:
            mock_run.side_effect = subprocess.TimeoutExpired(cmd="mvn", timeout=120)
            
            result = await compile_code(state)
            
            assert result["compile_success"] is False
            assert "timed out" in result["compile_errors"][0]


class TestParseMavenErrors:
    """Tests for Maven error parsing."""

    def test_parse_single_error(self):
        """Should parse a single compilation error."""
        output = "[ERROR] /data/output/src/main/java/com/test/Service.java:[25,15] cannot find symbol"
        
        errors = _parse_maven_errors(output, "/data/output")
        
        assert len(errors) == 1
        assert errors[0].line == 25
        assert errors[0].column == 15
        assert "cannot find symbol" in errors[0].message

    def test_parse_multiple_errors(self):
        """Should parse multiple compilation errors."""
        output = """[INFO] Compiling...
[ERROR] /data/output/src/main/java/Test1.java:[10,5] error one
[ERROR] /data/output/src/main/java/Test2.java:[20,10] error two
[INFO] BUILD FAILURE"""
        
        errors = _parse_maven_errors(output, "/data/output")
        
        assert len(errors) == 2
        assert "Test1.java" in errors[0].file_path
        assert "Test2.java" in errors[1].file_path

    def test_parse_no_errors(self):
        """Should return empty list when no errors."""
        output = """[INFO] Compiling...
[INFO] BUILD SUCCESS"""
        
        errors = _parse_maven_errors(output, "/data/output")
        
        assert errors == []

    def test_parse_error_without_column(self):
        """Should parse errors without column number."""
        output = "[ERROR] /data/output/Test.java:[10] some error"
        
        errors = _parse_maven_errors(output, "/data/output")
        
        assert len(errors) == 1
        assert errors[0].line == 10
        assert errors[0].column == 0

    def test_parse_alternate_error_format(self):
        """Should parse alternate error format."""
        output = "/data/output/Test.java:[10,5] error: cannot find symbol"
        
        errors = _parse_maven_errors(output, "/data/output")
        
        assert len(errors) == 1
        assert errors[0].line == 10


class TestErrorToDict:
    """Tests for error conversion."""

    def test_converts_error_to_dict(self):
        """Should convert CompileError to dictionary."""
        error = CompileError(
            file_path="/path/to/File.java",
            line=25,
            column=10,
            message="cannot find symbol",
            error_type="error",
        )
        
        result = _error_to_dict(error)
        
        assert result == {
            "file_path": "/path/to/File.java",
            "line": 25,
            "column": 10,
            "message": "cannot find symbol",
            "error_type": "error",
        }


class TestShouldFix:
    """Tests for fix decision logic."""

    def test_should_fix_on_failure_with_attempts(self):
        """Should return 'fix' when compilation fails and attempts remain."""
        state: OrchestratorState = {
            "project_path": "/path",
            "facade_name": "Test",
            "output_dir": "/output",
            "base_package": "com.test",
            "compile_success": False,
            "compile_errors": [{"message": "error"}],
            "fix_attempts": 1,
            "max_fix_attempts": 3,
            "current_step": "compile_failed",
        }
        
        result = should_fix(state)
        
        assert result == "fix"

    def test_should_end_on_success(self):
        """Should return 'end' when compilation succeeds."""
        state: OrchestratorState = {
            "project_path": "/path",
            "facade_name": "Test",
            "output_dir": "/output",
            "base_package": "com.test",
            "compile_success": True,
            "compile_errors": [],
            "fix_attempts": 0,
            "max_fix_attempts": 3,
            "current_step": "compiled",
        }
        
        result = should_fix(state)
        
        assert result == "end"

    def test_should_end_on_max_attempts(self):
        """Should return 'end' when max attempts reached."""
        state: OrchestratorState = {
            "project_path": "/path",
            "facade_name": "Test",
            "output_dir": "/output",
            "base_package": "com.test",
            "compile_success": False,
            "compile_errors": [{"message": "error"}],
            "fix_attempts": 3,
            "max_fix_attempts": 3,
            "current_step": "compile_failed",
        }
        
        result = should_fix(state)
        
        assert result == "end"

    def test_should_fix_with_no_explicit_max(self):
        """Should use default max attempts when not specified."""
        state: OrchestratorState = {
            "project_path": "/path",
            "facade_name": "Test",
            "output_dir": "/output",
            "base_package": "com.test",
            "compile_success": False,
            "compile_errors": [{"message": "error"}],
            "fix_attempts": 0,
            "current_step": "compile_failed",
        }
        
        result = should_fix(state)
        
        assert result == "fix"
