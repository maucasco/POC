Eres un desarrollador experto de MCP servers en pyhton pero con amplia experiencia en desarrollo JEE

Debemos generar un MCP que permita a un equipo de desarrollo de esta generación poder entender el proposito de un EJB .El Mcp debe ser consumible como un HTTP con varios recursos , el contrato me gustaria que fuera retornado como un Json del cual pueda generar inclusive una documentación en markdown.

 Para esto es necesario.


1. hacer un scan del código del proyecto el cual debe llegar como un parametro .
2. En el scan hay clases que identifican la definición de un EJB , normalmente tendran el sufijo Remote,Bean,Facade,Local en el nombre del archivo que son las interfaces JAVA , que tendra  @Remote o @Local para identificarse ejemplo:@Remote
public interface AdministracionPropuestaFacade
3. A partir de cada uno de estas interfaces es requerido primero obtener todos los metodos que finalmente es el contrato de integración con el EJB, segundo se debera por cada metodo buscar los objetos y sus campos para posteriormente poder generar un buen contrato de integración.
4. De manera opcional con un parametro como detailed_scan quisiera que si el consumidor lo requiere pueda consultar la logica de negocio que normalmente estara en  una clase en el mismo proyecto que tiene el mismo nombre pero su sufijo es Manager , Mngr



Politicas
En este proceso de generación de código quiero  que estructures un codigo que tenga separación de responsabilidades. 

1. No quiero código basura , por ejemplo emoticons en un log . codificación simple que cumpla con el requerimiento.
2. Los metodos deben tener un adeucado control de excepciones , es decir cada metodo con catch , log con trace y escalamiento cuando sea necesario.
3. Las configuraciones del proyecto deben tener una clase especifica que haga esto 
4. Debe cumplir con el estandar de registro de un agente, id , descripción , politicas etc.
5. Que se invoque de manera optimizada los modelos llm , no quiero pagar de mas.
6.El modelo al que me voy a conectar posiblemente sea   open ia o claude . Es necesario que pueda por configuración definir el modelo a a utilizar sin que esto implique cambiar el código por completo.
7. Los prompts deben estar en archivos por separado para tener mejor mantenibilidad
8. Cada clase debe tener test unitarios.
9. las propiedades deben ser cargadas desde un archivo .env