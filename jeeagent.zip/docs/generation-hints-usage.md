# Uso de Generation Hints

El parámetro `generation_hints` permite al usuario proporcionar instrucciones personalizadas para guiar la generación de código durante la migración de EJB a Quarkus.

## Características

- **Prioridad máxima**: Las instrucciones del usuario tienen la máxima prioridad sobre las convenciones por defecto
- **Flexibilidad**: Permite adaptar la generación a requisitos específicos del proyecto
- **Sin ejemplos específicos**: Las instrucciones deben ser generales y aplicables a cualquier método

## Cómo Usar

### Desde GitHub Copilot (MCP)

```
@workspace migra el método consultarPeriodo de PreliquidacionFacade con estas instrucciones: 
"Usar los nombres de campos exactos del EJB sin traducir. 
Los campos de tipo Calendar deben mapearse a LocalDateTime en lugar de LocalDate.
No incluir campo usuario en los Request."
```

### Desde CLI (jee-orchestrate)

El CLI aún no soporta este parámetro directamente. Se agregará en futuras versiones.

### Desde Python (API directa)

```python
from jee_codegen_orchestrator.graph import run_orchestrator

state = await run_orchestrator(
    project_path="/path/to/jee/project",
    facade_name="PreliquidacionConsultaFacade",
    method_name="consultarPeriodo",
    output_dir="/path/to/output",
    generation_hints="Usar nombres de campos exactos del EJB sin traducir a inglés"
)
```

## Ejemplos de Instrucciones Útiles

### Nomenclatura de Campos

```text
"Mantener los nombres de campos exactamente como están definidos en el EJB, sin modificarlos ni traducirlos"
```

```text
"Traducir todos los nombres de campos del español al inglés siguiendo convención camelCase"
```

### Mapeo de Tipos

```text
"Los campos de tipo Calendar en el EJB deben mapearse a LocalDateTime, no LocalDate"
```

```text
"Usar BigDecimal para todos los campos numéricos monetarios, incluso si el EJB usa Double"
```

### Campos Especiales

```text
"No incluir campos de tipo UserTO en los Request. Estos se manejan por seguridad en el backend"
```

```text
"Agregar campo 'auditInfo' de tipo AuditVO en todos los Response"
```

### Convenciones de Mappers

```text
"Los métodos del Mapper deben usar prefijo 'convertir' en lugar de 'to'"
```

```text
"Usar MapStruct annotations en lugar de métodos estáticos para los mappers"
```

### Documentación

```text
"Generar todos los comentarios Javadoc en inglés"
```

```text
"Incluir ejemplos de uso en los comentarios Javadoc de cada método público"
```

## Mejores Prácticas

### ✅ Hacer

- Ser específico y claro en las instrucciones
- Usar instrucciones generales aplicables a cualquier método
- Combinar múltiples instrucciones separadas por puntos o saltos de línea
- Enfocarse en convenciones, no en casos particulares

### ❌ Evitar

- Mencionar nombres de campos específicos de un caso de prueba particular
- Incluir ejemplos de código concreto con nombres reales de clases
- Instrucciones contradictorias
- Instrucciones demasiado largas o complejas

## Buenas vs Malas Instrucciones

### ✅ Buena (General)

```text
"Los nombres de campos deben mantenerse inalterados del contrato EJB original"
```

### ❌ Mala (Específica)

```text
"El campo listaLecturasDia debe ser List<LecturaDia> no List<LeafMessageVO>"
```

---

### ✅ Buena (Abstracta)

```text
"Las fechas deben mapearse a LocalDateTime para preservar información de hora"
```

### ❌ Mala (Caso particular)

```text
"La fecha fechaSesion de UserTO debe ser LocalDateTime"
```

---

### ✅ Buena (Convención)

```text
"Usar comentarios Javadoc en español para todos los métodos públicos"
```

### ❌ Mala (Implementación)

```text
"El método consultarPeriodo debe tener este Javadoc: ..."
```

## Cómo Funciona Internamente

1. El parámetro `generation_hints` se pasa al MCP tool `migrate_facade_method`
2. Se propaga a través del `OrchestratorState` en el grafo LangGraph
3. El nodo `generator` lo pasa al `CodeGenerator`
4. El `CodeGenerator` lo inyecta en cada llamada al LLM con máxima prioridad
5. El LLM genera código siguiendo las instrucciones del usuario sobre las convenciones por defecto

## Limitaciones Actuales

- Solo afecta la generación de código (nodo `generator`), no la documentación
- No valida si las instrucciones son contradictorias
- No persiste las instrucciones para futuras ejecuciones

## Futuras Mejoras

- Soporte en CLI con flag `--hints` o `--instructions`
- Archivo de configuración `.ejbmigration.yaml` para instrucciones persistentes
- Validación de instrucciones contradictorias
- Aplicación de hints también en el nodo de documentación
- Templates de instrucciones comunes para reusar
