# Diagramas de Arquitectura - JEE to Quarkus Migration Agent

## 1. Visión General del Sistema

```mermaid
graph TB
    subgraph "🎯 Cliente"
        GC[GitHub Copilot]
        CLI[CLI Terminal]
    end

    subgraph "🔌 MCP Server"
        ORC[JEE Codegen Orchestrator<br/>Puerto 8080]
    end

    subgraph "🤖 Agentes Especializados"
        INT[Interpreter JEE MCP<br/>Escaneo de Contratos]
        DOC[JEE Doc Agent<br/>Documentación]
        GEN[Quarkus Codegen Agent<br/>Generación de Código]
    end

    subgraph "🧠 LLM Providers"
        ANT[Anthropic Claude]
        OAI[OpenAI GPT]
    end

    subgraph "📁 Recursos"
        JEE[(Proyecto JEE<br/>EJBs Legacy)]
        OUT[(Output<br/>Quarkus Code)]
    end

    GC -->|MCP Protocol| ORC
    CLI -->|Commands| ORC
    
    ORC -->|Scan| INT
    ORC -->|Document| DOC
    ORC -->|Generate| GEN
    
    INT -->|Lee| JEE
    DOC -->|Analiza| ANT
    DOC -->|Analiza| OAI
    GEN -->|Genera| OUT
    GEN -->|Usa| ANT
    GEN -->|Usa| OAI

    style ORC fill:#e1f5fe
    style INT fill:#fff3e0
    style DOC fill:#f3e5f5
    style GEN fill:#e8f5e9
```

## 2. Flujo de Migración Detallado

```mermaid
flowchart LR
    subgraph "📥 Input"
        A[Proyecto JEE]
        B[Facade Name]
        C[Method Name]
    end

    subgraph "1️⃣ SCAN"
        D[Detectar @Remote/@Local]
        E[Extraer Métodos]
        F[Parsear DTOs]
        G[Leer Manager Logic]
    end

    subgraph "2️⃣ DOCUMENT"
        H[Análisis LLM]
        I[Generar Descripción]
        J[Tablas Entrada/Salida]
        K[Mapeo de Errores]
    end

    subgraph "3️⃣ GENERATE"
        L[Domain Layer]
        M[Application Layer]
        N[Infrastructure Layer]
        O[Tests & OpenAPI]
    end

    subgraph "4️⃣ COMPILE"
        P{mvn compile}
        Q[Parsear Errores]
    end

    subgraph "5️⃣ FIX"
        R[Análisis LLM]
        S[Aplicar Corrección]
        T{Retry < 3?}
    end

    subgraph "📤 Output"
        U[Código Quarkus<br/>Compilado ✅]
    end

    A --> D
    B --> D
    C --> D
    D --> E --> F --> G
    G --> H --> I --> J --> K
    K --> L --> M --> N --> O
    O --> P
    P -->|Error| Q --> R --> S --> T
    T -->|Sí| P
    T -->|No| U
    P -->|OK| U

    style P fill:#ffeb3b
    style U fill:#4caf50,color:#fff
```

## 3. Arquitectura Hexagonal Generada

```mermaid
graph TB
    subgraph "🌐 Infrastructure Layer"
        subgraph "Adapters IN"
            REST[REST Resource<br/>@Path @GET @POST]
        end
        subgraph "Adapters OUT"  
            RMI[RMI Adapter<br/>EJB Client WebLogic]
        end
        MAP[Mappers<br/>DTO Transformations]
    end

    subgraph "⚙️ Application Layer"
        SVC[Service<br/>@ApplicationScoped]
    end

    subgraph "💎 Domain Layer"
        subgraph "Ports IN"
            UC[UseCase Interface]
        end
        subgraph "Ports OUT"
            PORT[RmiPort Interface]
        end
        subgraph "Model"
            REQ[Request DTO]
            RES[Response DTO]
        end
    end

    subgraph "🏛️ Legacy JEE"
        EJB[EJB Facade<br/>@Remote]
    end

    REST -->|HTTP Request| SVC
    SVC -->|implements| UC
    SVC -->|uses| PORT
    RMI -->|implements| PORT
    RMI -->|RMI Call| EJB
    MAP -.->|transforms| REQ
    MAP -.->|transforms| RES

    style REST fill:#bbdefb
    style RMI fill:#ffccbc
    style SVC fill:#c8e6c9
    style UC fill:#fff9c4
    style PORT fill:#fff9c4
    style EJB fill:#ef9a9a
```

## 4. Estructura de Archivos Generados

```mermaid
graph LR
    subgraph "📁 output/"
        POM[pom.xml]
        subgraph "src/main/java"
            subgraph "domain/"
                MODEL[model/<br/>*Request.java<br/>*Response.java]
                PIN[port/in/<br/>*UseCase.java]
                POUT[port/out/<br/>*RmiPort.java]
            end
            subgraph "application/"
                SERVICE[service/<br/>*Service.java]
            end
            subgraph "infrastructure/"
                AREST[adapter/in/rest/<br/>*Resource.java]
                ARMI[adapter/out/rmi/<br/>*RmiAdapter.java]
                MAPPER[mapper/<br/>*Mapper.java]
            end
        end
        subgraph "src/test/java"
            TEST[*Test.java]
        end
        subgraph "src/main/resources"
            OAS[openapi/<br/>*.json]
        end
    end

    style MODEL fill:#fff9c4
    style PIN fill:#fff9c4
    style POUT fill:#fff9c4
    style SERVICE fill:#c8e6c9
    style AREST fill:#bbdefb
    style ARMI fill:#ffccbc
    style MAPPER fill:#e1bee7
```

## 5. Comunicación MCP

```mermaid
sequenceDiagram
    participant C as GitHub Copilot
    participant M as MCP Server
    participant S as Scanner
    participant D as Documenter
    participant G as Generator
    participant X as Compiler
    participant L as LLM

    C->>M: migrate_facade_method(project, facade, method)
    activate M
    
    M->>S: scan_ejb_contracts(project)
    S->>S: Parse Java files
    S-->>M: EJB Contract JSON
    
    M->>D: generate_documentation(contract)
    D->>L: Analyze business logic
    L-->>D: Functional description
    D-->>M: Markdown documentation
    
    M->>G: generate_quarkus_code(contract, docs)
    G->>L: Generate hexagonal code
    L-->>G: Java classes
    G->>G: Write files
    G-->>M: Generated files list
    
    M->>X: mvn compile
    alt Compilation Error
        X-->>M: Errors list
        M->>L: Fix compilation errors
        L-->>M: Fixed code
        M->>X: mvn compile (retry)
    end
    X-->>M: Success
    
    M-->>C: Migration complete ✅
    deactivate M
```

## 6. Despliegue Docker

```mermaid
graph TB
    subgraph "🐳 Docker Container"
        subgraph "Runtime"
            PY[Python 3.12]
            JV[Java 21]
            MV[Maven 3.9]
        end
        
        subgraph "Applications"
            MCP[MCP Server :8080]
            AGT[Agents]
        end
    end

    subgraph "📂 Volumes"
        V1[/data/jee-projects<br/>Read Only]
        V2[/data/output<br/>Read/Write]
        V3[~/.m2<br/>Maven Cache]
    end

    subgraph "🔐 Environment"
        E1[ANTHROPIC_API_KEY]
        E2[LLM_PROVIDER]
        E3[MCP_PORT]
    end

    V1 -->|mount| MCP
    V2 -->|mount| MCP
    V3 -->|mount| MV
    E1 --> AGT
    E2 --> AGT
    E3 --> MCP

    style MCP fill:#e1f5fe
    style PY fill:#fff9c4
    style JV fill:#ffccbc
    style MV fill:#c8e6c9
```

---

## Visualización

Para ver estos diagramas renderizados:

1. **GitHub**: Los archivos `.md` con Mermaid se renderizan automáticamente
2. **VS Code**: Instalar extensión "Markdown Preview Mermaid Support"
3. **Online**: Copiar el código Mermaid a [mermaid.live](https://mermaid.live)
