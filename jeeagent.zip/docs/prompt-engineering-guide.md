# Guía de Prompt Engineering para JEE → Quarkus

## 🎯 Objetivo

Estructurar prompts "ganadores" que aprovechen el **detailed_scan** del interpreter-jee-mcp-server para generar código Quarkus con alta precisión (85%+ compilación directa).

---

## 📊 Detailed Scan: Diferencias Clave

### `detailed_scan=False` (Actual en Orchestrator)
```python
MethodSignature(
    name="consultarParametro",
    return_type="Map<String, String>",
    parameters=[
        MethodParameter(
            name="filtro",
            type_hint="FiltroVO",
            dto=None,              # ❌ Sin estructura
            dto_fields=None        # ❌ Sin campos
        )
    ],
    documentation="Consulta ...",
    manager_summary=None           # ❌ Sin lógica de negocio
)
```

### `detailed_scan=True` (Recomendado)
```python
MethodSignature(
    name="consultarParametro",
    return_type="Map<String, String>",
    parameters=[
        MethodParameter(
            name="filtro",
            type_hint="FiltroVO",
            dto=DtoDefinition(
                name="FiltroVO",
                file_path="/src/.../FiltroVO.java",
                fields=[
                    DtoField(
                        name="codigoParametro",
                        type_hint="String",
                        nested_dto=None
                    ),
                    DtoField(
                        name="configuracion",
                        type_hint="ConfiguracionVO",
                        nested_dto=DtoDefinition(  # ✅ Anidado hasta nivel 3
                            name="ConfiguracionVO",
                            fields=[...]
                        )
                    )
                ]
            ),
            dto_fields=[...]  # Legacy flat
        )
    ],
    documentation="Consulta parámetro de configuración",
    manager_summary="""           # ✅ Resumen LLM de lógica
    El método consultarParametro busca en la base de datos PARAMETROS
    usando el código proporcionado. Valida que el código no sea nulo
    y retorna un Map con clave=nombre del parámetro, valor=valor configurado.
    Lanza ParametroNoEncontradoException si no existe.
    """
)
```

**Información adicional con detailed_scan:**
- ✅ Campos completos de cada DTO (nombre, tipo)
- ✅ DTOs anidados recursivos (hasta 3 niveles)
- ✅ Resumen de lógica de negocio del Manager
- ✅ Path al Manager para consultas adicionales
- ✅ Excepciones lanzadas (en manager_summary)
- ✅ Validaciones de negocio (en manager_summary)

---

## 🏆 Anatomía de un Prompt Ganador

### 1. **Estructura Clara con Secciones Jerárquicas**

```prompt
# TÍTULO PRINCIPAL EN MAYÚSCULAS

## 🚨 REGLA CRÍTICA (destacada con emoji)
**Texto en negrita para reglas obligatorias**

## Contexto Específico del Dominio
Descripción del escenario...

## 📋 Información Disponible en el Contexto
Lista de variables que recibirás:
- `{variable_name}`: Descripción precisa
- `{manager_summary}`: Lógica de negocio del Manager
- `{dto_fields}`: Campos del DTO con tipos

## ✅ Patrones Correctos (con ejemplos de código)
```java
// Ejemplo concreto de código correcto
public class Ejemplo { ... }
```

## ❌ Anti-Patrones (con ejemplos de código)
```java
// Ejemplo concreto de código incorrecto con explicación
public class MalEjemplo { ... }  // ❌ Razón específica
```

## Algoritmo de Decisión (paso a paso)
1. **Paso 1**: Si condición X → hacer Y
2. **Paso 2**: Si condición Z → hacer W
3. **Validación final**: Verificar que...

## Salida Esperada (formato exacto)
```
Formato preciso del código a generar
```
```

### 2. **Aprovechar manager_summary para Inferencia de Tipos**

**❌ Prompt sin manager_summary (Actual):**
```prompt
Genera un RmiAdapter que invoque el método EJB.

Método: {method.name}
Parámetros: {method.parameters}
```

**✅ Prompt con manager_summary (Mejorado):**
```prompt
## 📖 CONTEXTO DE NEGOCIO (desde Manager)

{manager_summary}

## 🎯 INFERENCIA DE TIPOS AUTOMÁTICA

**IMPORTANTE**: El manager_summary contiene información crítica:

1. **Excepciones lanzadas** → Agregar try-catch específicos
   - Busca palabras: "lanza", "throws", "exception"
   - Ejemplo: "lanza ParametroNoEncontradoException" 
     → Agregar `catch (ParametroNoEncontradoException e)`

2. **Validaciones de negocio** → Reflejar en código
   - Busca palabras: "valida", "verifica", "debe ser"
   - Ejemplo: "valida que el código no sea nulo"
     → Agregar `if (request.codigo() == null) throw ...`

3. **Fuentes de datos** → Inferir tipo de retorno
   - Busca palabras: "base de datos", "tabla", "consulta"
   - Ejemplo: "consulta tabla PARAMETROS con clave compuesta"
     → Si retorna Map, probablemente Map<String, String>

4. **Colecciones** → Inferir ArrayList vs List
   - Busca palabras: "lista de", "array", "conjunto"
   - Ejemplo: "retorna lista de configuraciones activas"
     → Si EJB retorna ArrayList<T>, preservar ArrayList

## 💡 EJEMPLO CONCRETO

Si manager_summary dice:
```
El método busca en la tabla PARAMETROS_CONFIG donde CODIGO = filtro.codigoParametro.
Retorna Map con entradas (nombreParametro, valorParametro).
Lanza ParametroNoEncontradoException si no hay resultados.
```

Entonces el RmiAdapter debe:
```java
try {
    // Inferir que ejbResponse es Map<String, String> (no Object)
    Map<String, String> ejbResponse = facade.consultarParametro(filtro);
    
    // Convertir con el Mapper correcto
    return ConsultarParametroMapper.toApiResponse(ejbResponse);
    
} catch (ParametroNoEncontradoException e) {  // ✅ Excepción específica
    LOG.error("Parámetro no encontrado", e);
    throw new NotFoundException("Parámetro no existe");
}
```
```

### 3. **Usar dto.fields para Mappers Precisos**

**❌ Prompt sin dto.fields (Actual):**
```prompt
Genera un Mapper que convierta FiltroRequest a FiltroVO.

Request: {method_pascal}Request
VO: FiltroVO
```

**✅ Prompt con dto.fields (Mejorado):**
```prompt
## 📋 CAMPOS DEL DTO (de detailed_scan)

**FiltroRequest** (campos del API):
{request_fields_parsed}

**FiltroVO** (campos del EJB - de dto.fields):
{% for field in dto.fields %}
- `{{ field.name }}`: {{ field.type_hint }}
  {% if field.nested_dto %}
  └─ Nested: {{ field.nested_dto.name }} con {{ field.nested_dto.fields|length }} campos
  {% endif %}
{% endfor %}

## 🎯 ESTRATEGIA DE MAPEO AUTOMÁTICO

**REGLA 1: Mapeo por nombre similar**
Para cada campo en Request:
1. Buscar campo en VO con nombre idéntico (case-sensitive)
2. Si no existe, buscar con camelCase/snake_case alternativo
3. Si no existe, buscar en nested_dto recursivamente

**REGLA 2: Conversión de tipos**
- Request: `String codigo` + VO: `Integer codigo` → `Integer.parseInt(request.codigo())`
- Request: `LocalDate fecha` + VO: `Date fecha` → `Date.from(request.fecha().atStartOfDay(ZoneId.systemDefault()).toInstant())`

**REGLA 3: Objetos anidados**
Si VO tiene campo `configuracion: ConfiguracionVO` con nested_dto:
```java
ConfiguracionVO config = new ConfiguracionVO();
{% for nested_field in field.nested_dto.fields %}
config.set{{ nested_field.name|capitalize }}(request.{{ nested_field.name }}());
{% endfor %}
vo.setConfiguracion(config);
```

## 💡 EJEMPLO GENERADO

Dado:
- Request.codigo: String
- FiltroVO.codigoParametro: String (de dto.fields)

Mapper debe:
```java
public static FiltroVO toFiltroVO(ConsultarParametroRequest request) {
    FiltroVO vo = new FiltroVO();
    vo.setCodigoParametro(request.codigo());  // ✅ Mapeo correcto
    return vo;
}
```
```

### 4. **Tablas de Decisión para Casos Complejos**

```prompt
## 🎯 DETECCIÓN AUTOMÁTICA DEL MÉTODO HTTP

**Analiza el Request record y decide:**

| Condición | GET | POST |
|-----------|-----|------|
| Request tiene ≤ 3 campos primitivos | ✅ | ❌ |
| Request tiene List<T> o Map<K,V> | ❌ | ✅ |
| Request tiene objetos anidados | ❌ | ✅ |
| Request tiene > 3 campos | ❌ | ✅ |
| Método es "consultar*" o "get*" | ✅ | ❌ |
| Método es "crear*", "actualizar*", "eliminar*" | ❌ | ✅ |

**Algoritmo:**
```
if request.campos.length <= 3 AND all(campo.isPrimitive for campo in request.campos):
    if method.name.startswith("consultar") OR method.name.startswith("get"):
        return GET
return POST
```

**Expansión de QueryParams para GET:**
```java
// Request: ConsultarParametroRequest(String codigo, Integer version)
@GET
@Path("/consultar-parametro")
public Uni<ConsultarParametroResponse> consultarParametro(
    @QueryParam("codigo") String codigo,      // ✅ Expandido
    @QueryParam("version") Integer version    // ✅ Expandido
) {
    var request = new ConsultarParametroRequest(codigo, version);
    return useCase.consultarParametro(request);
}
```
```

### 5. **Contexto Enriquecido con Código Real**

```prompt
## 📄 CÓDIGO DEL REQUEST GENERADO

{request_code}

## 🔍 CAMPOS PARSEADOS

{request_fields_parsed}

## 🎯 USO EN GENERACIÓN

**Para RmiAdapter:**
1. Parsear {request_code} con regex `record \w+\((.*?)\)`
2. Extraer tipos exactos: `String codigo, Integer version, LocalDate fecha`
3. **CRÍTICO**: Inferir tipo de ejbResponse desde:
   - manager_summary (si menciona "Map", "List", "Array")
   - method.return_type (preservar genéricos completos)
   - Campos del response DTO (si existe en dto.fields)

**Ejemplo:**
Si manager_summary dice "retorna lista de configuraciones" 
Y method.return_type = "ArrayList<ConfiguracionVO>"
Entonces:
```java
// ✅ CORRECTO - tipo específico con genérico completo
ArrayList<ConfiguracionVO> ejbResponse = facade.listarConfiguraciones(vo);

// ❌ INCORRECTO - simplificado o genérico
Object ejbResponse = facade.listarConfiguraciones(vo);  // ❌ Object
List<ConfiguracionVO> ejbResponse = ...;  // ❌ Cambió ArrayList a List
```
```

---

## 📈 Métricas de un Prompt Ganador

### Checklist de Calidad

```markdown
✅ **Estructura Clara**
- [ ] Título descriptivo con emoji
- [ ] Secciones organizadas jerárquicamente
- [ ] Reglas críticas destacadas con 🚨

✅ **Contexto Completo**
- [ ] Explica QUÉ variables recibirás del detailed_scan
- [ ] Documenta CÓMO usar manager_summary
- [ ] Lista TODAS las propiedades de dto.fields disponibles

✅ **Ejemplos Concretos**
- [ ] ✅ Código correcto con explicación
- [ ] ❌ Código incorrecto con razón específica
- [ ] 💡 Casos edge documentados

✅ **Decisiones Algorítmicas**
- [ ] Tablas de decisión para múltiples condiciones
- [ ] Pasos numerados para lógica compleja
- [ ] Validaciones finales explícitas

✅ **Inferencia de Tipos**
- [ ] Reglas para detectar Object vs tipos específicos
- [ ] Preservación de genéricos (Map<K,V> no Map)
- [ ] Preservación de implementaciones (ArrayList no List)

✅ **Validación Pre/Post**
- [ ] Qué validar ANTES de generar
- [ ] Qué validar DESPUÉS de generar
- [ ] Qué logs/warnings emitir
```

### Antes vs Después

| Aspecto | Prompt Débil | Prompt Ganador |
|---------|--------------|----------------|
| **Contexto** | "Genera código" | "Usa {manager_summary} para inferir excepciones" |
| **Tipos** | "Retorna Response" | "Si EJB retorna ArrayList<T>, preservar ArrayList (no List)" |
| **Ejemplos** | Sin ejemplos | 3+ ejemplos (correcto/incorrecto/edge) |
| **Decisiones** | Ambiguo | Tabla de decisión con condiciones exactas |
| **Validación** | Ninguna | Pre: validar contexto, Post: validar imports |
| **Campos DTO** | "Mapea campos" | "Usa dto.fields[i].nested_dto para anidados" |

---

## 🔧 Implementación Práctica

### Paso 1: Habilitar detailed_scan

```python
# En: jee-codegen-orchestrator/src/.../nodes/scanner.py

# ❌ Actual
scan_result = await client.scan_project(
    project_path,
    detailed_scan=False,  # Sin manager_summary ni dto.fields
)

# ✅ Mejorado
scan_result = await client.scan_project(
    project_path,
    detailed_scan=True,   # Con toda la información
)
```

### Paso 2: Actualizar Prompts para Usar Información

```prompt
# En: quarkus-codegen-agent/src/.../prompts/rmi_adapter_method.prompt

## 📖 CONTEXTO DE NEGOCIO

{% if method.manager_summary %}
**Lógica del Manager:**
{{ method.manager_summary }}

**Análisis automático:**
{% if "lanza" in method.manager_summary or "throws" in method.manager_summary %}
⚠️ Este método lanza excepciones - agregar try-catch específicos
{% endif %}
{% if "Map" in method.return_type %}
🔍 Retorna Map - inferir genéricos desde manager_summary
{% endif %}
{% else %}
⚠️ Sin manager_summary (detailed_scan=False) - inferir solo desde tipos
{% endif %}

## 📋 DTOs DISPONIBLES

{% for param in method.parameters %}
**{{ param.name }}: {{ param.type_hint }}**
{% if param.dto %}
Campos:
  {% for field in param.dto.fields %}
  - {{ field.name }}: {{ field.type_hint }}
    {% if field.nested_dto %}
    └─ Nested: {{ field.nested_dto.name }}
    {% endif %}
  {% endfor %}
{% else %}
  ⚠️ Sin dto.fields (detailed_scan=False)
{% endif %}
{% endfor %}
```

### Paso 3: Validar con Métricas

```python
# En: code_generator.py - método _validate_generated_code

def _validate_generated_code(...) -> tuple[bool, list[str]]:
    errors = []
    
    # Validación 1: Uso de Object cuando hay manager_summary
    if component_type == "rmi_adapter":
        if method.manager_summary and "Object ejbResponse" in code:
            errors.append(
                "❌ Uso de Object cuando manager_summary está disponible. "
                "El resumen indica tipo específico."
            )
    
    # Validación 2: Mapeo sin usar dto.fields
    if component_type == "mapper":
        for param in method.parameters:
            if param.dto and param.dto.fields:
                # Verificar que el mapper usa los campos reales
                for field in param.dto.fields:
                    if field.name not in code:
                        errors.append(
                            f"⚠️ Campo '{field.name}' de {param.dto.name} "
                            f"no aparece en el mapper (disponible en dto.fields)"
                        )
    
    return len(errors) == 0, errors
```

---

## 📚 Ejemplos Reales

### Ejemplo 1: Método con Manager Summary

**Entrada del detailed_scan:**
```python
MethodSignature(
    name="consultarConfiguracionActiva",
    return_type="ConfiguracionVO",
    parameters=[
        MethodParameter(
            name="codigo",
            type_hint="String",
            dto=None
        )
    ],
    manager_summary="""
    Consulta la tabla CONFIG_PARAMETROS donde ACTIVO=1 y CODIGO=codigo.
    Retorna ConfiguracionVO con campos: codigoConfig, nombreConfig, valorConfig.
    Lanza ConfiguracionNoEncontradaException si no hay configuración activa.
    Si el código es nulo, lanza IllegalArgumentException.
    """
)
```

**Prompt mejorado para RmiAdapter:**
```prompt
## 🎯 ANÁLISIS DEL MANAGER SUMMARY

Lógica de negocio detectada:
- ✅ Tabla: CONFIG_PARAMETROS
- ✅ Filtro: ACTIVO=1 AND CODIGO={codigo}
- ✅ Excepciones: ConfiguracionNoEncontradaException, IllegalArgumentException
- ✅ Tipo retorno: ConfiguracionVO (no Object)
- ✅ Validación: codigo no nulo

**Inferencias para el código:**

1. **Tipo de ejbResponse:**
```java
// ✅ CORRECTO - tipo explícito del manager_summary
ConfiguracionVO ejbResponse = facade.consultarConfiguracionActiva(codigo);
```

2. **Manejo de excepciones:**
```java
try {
    ConfiguracionVO ejbResponse = facade.consultarConfiguracionActiva(codigo);
    return Uni.createFrom().item(ConsultarConfiguracionActivaMapper.toApiResponse(ejbResponse));
    
} catch (ConfiguracionNoEncontradaException e) {  // ✅ Específica
    LOG.error("Configuración no encontrada para codigo: {}", codigo, e);
    return Uni.createFrom().failure(new NotFoundException("Configuración no existe"));
    
} catch (IllegalArgumentException e) {  // ✅ Específica
    LOG.error("Código inválido: {}", codigo, e);
    return Uni.createFrom().failure(new BadRequestException("Código null"));
}
```

3. **Validación previa (opcional):**
```java
// Basado en "Si el código es nulo, lanza IllegalArgumentException"
if (request.codigo() == null) {
    return Uni.createFrom().failure(new BadRequestException("Código requerido"));
}
```
```

### Ejemplo 2: Mapper con DTO Anidado

**Entrada del detailed_scan:**
```python
MethodParameter(
    name="solicitud",
    type_hint="SolicitudProcesoVO",
    dto=DtoDefinition(
        name="SolicitudProcesoVO",
        fields=[
            DtoField(
                name="codigoSolicitud",
                type_hint="String",
                nested_dto=None
            ),
            DtoField(
                name="datosAdicionales",
                type_hint="DatosAdicionalesVO",
                nested_dto=DtoDefinition(
                    name="DatosAdicionalesVO",
                    fields=[
                        DtoField(name="observaciones", type_hint="String"),
                        DtoField(name="prioridad", type_hint="Integer")
                    ]
                )
            ),
            DtoField(
                name="adjuntos",
                type_hint="List<AdjuntoVO>",
                nested_dto=DtoDefinition(
                    name="AdjuntoVO",
                    fields=[
                        DtoField(name="nombreArchivo", type_hint="String"),
                        DtoField(name="tipoMime", type_hint="String")
                    ]
                )
            )
        ]
    )
)
```

**Prompt mejorado para Mapper:**
```prompt
## 📋 ESTRUCTURA COMPLETA DEL DTO (de dto.fields)

**SolicitudProcesoVO:**
```
└─ codigoSolicitud: String
└─ datosAdicionales: DatosAdicionalesVO
     └─ observaciones: String
     └─ prioridad: Integer
└─ adjuntos: List<AdjuntoVO>
     └─ nombreArchivo: String
     └─ tipoMime: String
```

## 🎯 ESTRATEGIA DE MAPEO ANIDADO

**NIVEL 1**: Campos primitivos directos
```java
vo.setCodigoSolicitud(request.codigoSolicitud());  // String → String
```

**NIVEL 2**: Objeto anidado (DatosAdicionalesVO)
```java
if (request.datosAdicionales() != null) {
    DatosAdicionalesVO datos = new DatosAdicionalesVO();
    datos.setObservaciones(request.datosAdicionales().observaciones());
    datos.setPrioridad(request.datosAdicionales().prioridad());
    vo.setDatosAdicionales(datos);
}
```

**NIVEL 3**: Lista de objetos (List<AdjuntoVO>)
```java
if (request.adjuntos() != null && !request.adjuntos().isEmpty()) {
    List<AdjuntoVO> adjuntosVO = request.adjuntos().stream()
        .map(adj -> {
            AdjuntoVO adjVO = new AdjuntoVO();
            adjVO.setNombreArchivo(adj.nombreArchivo());
            adjVO.setTipoMime(adj.tipoMime());
            return adjVO;
        })
        .collect(Collectors.toList());
    vo.setAdjuntos(adjuntosVO);
}
```

## ✅ CÓDIGO FINAL GENERADO

```java
public static SolicitudProcesoVO toSolicitudProcesoVO(ProcesarSolicitudRequest request) {
    SolicitudProcesoVO vo = new SolicitudProcesoVO();
    
    // Nivel 1: Primitivos
    vo.setCodigoSolicitud(request.codigoSolicitud());
    
    // Nivel 2: Anidado
    if (request.datosAdicionales() != null) {
        DatosAdicionalesVO datos = new DatosAdicionalesVO();
        datos.setObservaciones(request.datosAdicionales().observaciones());
        datos.setPrioridad(request.datosAdicionales().prioridad());
        vo.setDatosAdicionales(datos);
    }
    
    // Nivel 3: Lista
    if (request.adjuntos() != null) {
        List<AdjuntoVO> adjuntosVO = request.adjuntos().stream()
            .map(adj -> {
                AdjuntoVO adjVO = new AdjuntoVO();
                adjVO.setNombreArchivo(adj.nombreArchivo());
                adjVO.setTipoMime(adj.tipoMime());
                return adjVO;
            })
            .collect(Collectors.toList());
        vo.setAdjuntos(adjuntosVO);
    }
    
    return vo;
}
```
```

---

## 🚀 Resultado Esperado

Con detailed_scan + prompts ganadores:

| Métrica | detailed_scan=False | detailed_scan=True + Prompts Mejorados |
|---------|---------------------|----------------------------------------|
| **Inferencia de tipos** | 60% correctos (Object frecuente) | **95%+ correctos** (tipos específicos) |
| **Imports correctos** | 70% (domain.model vs infrastructure) | **98%+** (validación automática) |
| **Mappers precisos** | 50% (inventan campos) | **90%+** (usan dto.fields reales) |
| **Manejo de excepciones** | 30% (genérico Exception) | **85%+** (específico del manager) |
| **Compilación directa** | 0-10% | **85%+** (target del proyecto) |
| **Errores promedio** | 16 por método | **0-1 por método** |

---

## 📝 Acción Inmediata

1. **Habilitar detailed_scan** en [scanner.py](../jee-codegen-orchestrator/src/jee_codegen_orchestrator/nodes/scanner.py):
   ```python
   detailed_scan=True  # Línea 60
   ```

2. **Actualizar prompts críticos** con secciones de manager_summary y dto.fields:
   - [rmi_adapter_method.prompt](../quarkus-codegen-agent/src/quarkus_codegen_agent/prompts/rmi_adapter_method.prompt)
   - [mapper.prompt](../quarkus-codegen-agent/src/quarkus_codegen_agent/prompts/mapper.prompt)
   - [ejb_facade_method.prompt](../quarkus-codegen-agent/src/quarkus_codegen_agent/prompts/ejb_facade_method.prompt)

3. **Agregar validaciones** de uso de información detallada en `_validate_generated_code()`

4. **Probar con proyecto real** y medir mejora en métricas

---

**¿Listo para implementar?** Empieza por habilitar `detailed_scan=True` y actualiza el primer prompt (rmi_adapter_method) con estas estrategias.
