# Configuración MCP Server para GitHub Copilot Coding Agent

## Endpoint del Servidor

```
URL: http://<host>:9000/sse
Transport: SSE (Server-Sent Events)
```

## Configuración en GitHub Copilot

### Opción 1: Archivo `.github/copilot/mcp.json` (en tu repositorio)

```json
{
  "mcpServers": {
    "jee-codegen-orchestrator": {
      "type": "sse",
      "url": "http://localhost:9000/sse",
      "description": "JEE to Quarkus migration orchestrator"
    }
  }
}
```

### Opción 2: Settings de VS Code (para desarrollo local)

```json
{
  "github.copilot.chat.mcpServers": {
    "jee-codegen-orchestrator": {
      "type": "sse", 
      "url": "http://localhost:9000/sse"
    }
  }
}
```

## Tools Disponibles

### 1. `migrate_facade_method`
Migra un método de facade EJB a arquitectura hexagonal Quarkus.

**Parámetros requeridos:**
- `project_path`: Ruta absoluta al proyecto JEE origen
- `facade_name`: Nombre de la interface facade (ej: `AdministracionPropuestaFacade`)
- `output_dir`: Ruta absoluta para el código generado

**Parámetros opcionales:**
- `method_name`: Método específico a migrar (null = todos)
- `base_package`: Package base Java (default: `com.davivienda`)
- `max_fix_attempts`: Intentos de corrección de compilación (0-10, default: 3)
- `mapping_hints`: Lista de mapeos de campos
- `skip_documentation`: Omitir generación de documentación

**Ejemplo de invocación:**
```
Migra el método consultarLecturasScada del facade PreliquidacionMasivaFacade 
del proyecto en /data/jee-projects/facturacion.negocio 
al directorio /data/output
```

### 2. `list_facades`
Lista todos los facades EJB en un proyecto JEE.

**Parámetros:**
- `project_path`: Ruta absoluta al proyecto JEE

### 3. `validate_mapping_csv`
Valida un archivo CSV de mapeo de campos.

**Parámetros:**
- `csv_path`: Ruta al archivo CSV

### 4. `get_cache_stats`
Obtiene estadísticas del cache de contratos.

### 5. `clear_cache`
Limpia el cache de contratos EJB.

### 6. `get_migration_status`
Obtiene el estado de una migración en progreso.

**Parámetros:**
- `run_id`: ID de la ejecución de migración

## Volúmenes Docker (para rutas dentro del contenedor)

Cuando el servidor corre en Docker, las rutas se mapean así:

| Host Path | Container Path | Modo |
|-----------|----------------|------|
| `/data/agente/jee-projects` | `/data/jee-projects` | read-only |
| `/data/agente/output` | `/data/output` | read-write |

**Importante:** Cuando invoques los tools desde Copilot, usa las rutas del **host** si el agente tiene acceso directo al filesystem, o las rutas del **contenedor** si el agente está dentro del mismo entorno Docker.

## Ejemplo de Prompt para Copilot Agent

```
Usando el servidor MCP jee-codegen-orchestrator:

1. Lista los facades disponibles en /data/jee-projects/facturacion.negocio
2. Migra el facade PreliquidacionMasivaFacade al directorio /data/output
3. Muestra el resultado de la migración
```

## Verificar Conectividad

```bash
# Verificar que el servidor responde
curl -s -N --max-time 3 http://localhost:9000/sse

# Debería devolver:
# event: endpoint
# data: /messages/?session_id=<uuid>
```

## Health Check

El servidor no tiene endpoint `/health`. Para verificar salud, usa el endpoint SSE.
