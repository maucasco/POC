#!/bin/bash
# JEE Codegen Orchestrator - Wrapper Script
# Este script activa el entorno virtual y ejecuta el orquestador

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_PATH="$SCRIPT_DIR/.venv"

# Verificar que el entorno virtual existe
if [ ! -d "$VENV_PATH" ]; then
    echo "❌ Error: Virtual environment not found at $VENV_PATH"
    echo "   Run: python -m venv $VENV_PATH && pip install -e jee-codegen-orchestrator"
    exit 1
fi

# Activar el entorno virtual y ejecutar el comando
source "$VENV_PATH/bin/activate"

# Si no hay argumentos, mostrar ayuda
if [ $# -eq 0 ]; then
    echo "🚀 JEE to Quarkus Migration Orchestrator"
    echo ""
    echo "Usage: $0 <command> [options]"
    echo ""
    echo "Commands:"
    echo "  method   Generate Quarkus code for an EJB facade method"
    echo "  verify   Verify compilation of generated code"
    echo "  config   Show current configuration"
    echo ""
    echo "Examples:"
    echo "  $0 method /path/to/jee-project -i FacadeName -m methodName"
    echo "  $0 method /path/to/jee-project -i FacadeName -m methodName --max-retries 3"
    echo "  $0 verify /data/agente/output"
    echo "  $0 config"
    echo ""
    jee-orchestrate --help
else
    jee-orchestrate "$@"
fi
