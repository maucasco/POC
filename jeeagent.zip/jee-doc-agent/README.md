# JEE Documentation Agent

Agente documentador funcional JEE que consume el servidor MCP `intepreter-jee-mcp-server` para generar documentación técnica completa de contratos EJB.

## Características

- 📋 **Escaneo de proyectos**: Detecta interfaces EJB con anotaciones `@Remote`/`@Local`
- 📝 **Documentación funcional**: Interpreta la lógica del Manager usando LLM
- 📊 **Tablas descriptivas**: Atributos de entrada y salida estructurados
- ⚠️ **Mapeo de errores**: Documenta excepciones y mensajes de error
- 💡 **Tips de consumo**: Recomendaciones prácticas para integración
- 🔌 **MCP stdio**: Comunicación eficiente via subprocess

## Instalación

```bash
cd jee-doc-agent
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Configuración

Crear archivo `.env`:

```env
# MCP Server (stdio - se lanza automáticamente)
MCP_SERVER_COMMAND=/data/agente/.venv/bin/python
MCP_SERVER_ARGS=-m,src.main
MCP_SERVER_CWD=/data/agente/intepreter-jee-mcp-server

# LLM Provider: openai | anthropic
LLM_PROVIDER=openai
OPENAI_API_KEY=sk-your-key
OPENAI_MODEL=gpt-4o-mini

# Alternativa Anthropic
ANTHROPIC_API_KEY=sk-ant-your-key
ANTHROPIC_MODEL=claude-3-5-sonnet-20241022

# Directorio de salida
OUTPUT_DIR=./output
```

## Uso

### 1. Escanear un proyecto

Muestra los contratos EJB encontrados sin generar documentación:

```bash
jee-doc scan /path/to/java/project
```

### 2. Generar documentación completa

Genera documentación Markdown para todos los métodos:

```bash
jee-doc doc /path/to/java/project

# Con directorio de salida personalizado
jee-doc doc /path/to/java/project -o ./mi-documentacion

# Filtrar por nombre de método
jee-doc doc /path/to/java/project -f "administrar"
```

### 3. Documentar un método específico

```bash
jee-doc method /path/to/java/project \
  -i PreliquidacionRegistroFacade \
  -m calcularTarifa

# Guardar en archivo
jee-doc method /path/to/java/project \
  -i PreliquidacionRegistroFacade \
  -m calcularTarifa \
  -o metodo.md
```

### 4. Listar métodos disponibles

```bash
# Todos los métodos
jee-doc list-methods /path/to/java/project

# Filtrar por interface
jee-doc list-methods /path/to/java/project -i PreliquidacionRegistro
```

## Estructura de la Documentación Generada

Cada método documentado incluye:

### 1. Descripción Funcional
Interpretación de la lógica de negocio basada en el código del Manager.

### 2. Tabla de Atributos de Entrada
| Nombre | Tipo | Requerido | Descripción |
|--------|------|-----------|-------------|
| `param1` | `TipoDTO` | ✅ | Descripción del parámetro |

### 3. Tabla de Atributos de Salida
| Nombre | Tipo | Descripción |
|--------|------|-------------|
| `result` | `ReturnType` | Lo que retorna el método |

### 4. Mapeo de Errores
| Código | Mensaje | Causa | Solución |
|--------|---------|-------|----------|
| `ApplicationException` | Error de negocio | Validación fallida | Verificar datos |

### 5. Tips de Consumo
- Verificar parámetros antes de invocar
- Manejar excepciones apropiadamente
- Considerar transaccionalidad

## Arquitectura

```
jee-doc-agent/
├── src/jee_doc_agent/
│   ├── cli.py           # Interfaz de línea de comandos (Typer)
│   ├── config.py        # Configuración desde .env
│   ├── models.py        # Modelos Pydantic
│   ├── mcp_client.py    # Cliente MCP stdio (subprocess)
│   ├── llm_analyzer.py  # Análisis con LLM (OpenAI/Anthropic)
│   └── doc_generator.py # Generador de Markdown
├── output/              # Documentación generada
└── .env                 # Variables de entorno
```

## Flujo de Trabajo

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│  jee-doc CLI    │────▶│  MCP Server      │────▶│  Java Project   │
│  (este agente)  │     │  (stdio)         │     │  (EJB source)   │
└────────┬────────┘     └──────────────────┘     └─────────────────┘
         │
         ▼
┌─────────────────┐     ┌──────────────────┐
│  LLM Analyzer   │────▶│  Markdown Docs   │
│  (OpenAI/Claude)│     │  (output)        │
└─────────────────┘     └──────────────────┘
```

## Requisitos

- Python 3.11+
- MCP Server `intepreter-jee-mcp-server` (se ejecuta automáticamente)
- API key de OpenAI o Anthropic

## Licencia

MIT
