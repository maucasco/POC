"""Pytest configuration and shared fixtures for jee-doc-agent tests."""
import sys
from pathlib import Path

import pytest

# Add source path to Python path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


@pytest.fixture
def sample_method_signature():
    """Create a sample MethodSignature for tests."""
    from jee_doc_agent.models import MethodSignature, MethodParameter, DtoDefinition, DataField
    
    dto = DtoDefinition(
        name="FiltroVO",
        file_path="/src/FiltroVO.java",
        fields=[
            DataField(name="id", type_hint="Long"),
            DataField(name="nombre", type_hint="String"),
        ],
    )
    
    return MethodSignature(
        name="consultarDatos",
        return_type="List<ResultadoTO>",
        parameters=[
            MethodParameter(name="filtro", type_hint="FiltroVO", dto=dto),
        ],
    )


@pytest.fixture
def sample_ejb_contract():
    """Create a sample EjbContract for tests."""
    from jee_doc_agent.models import EjbContract, MethodSignature
    
    return EjbContract(
        interface_name="TestFacade",
        annotation="@Remote",
        file_path="/src/TestFacade.java",
        related_manager_path="/src/TestFacadeManager.java",
        methods=[
            MethodSignature(name="consultarDatos", return_type="ResultadoTO"),
            MethodSignature(name="insertarRegistro", return_type="Long"),
        ],
    )


@pytest.fixture
def sample_method_documentation():
    """Create a sample MethodDocumentation for tests."""
    from jee_doc_agent.models import MethodDocumentation
    
    return MethodDocumentation(
        method_name="consultarDatos",
        interface_name="TestFacade",
        functional_description="Consulta los datos según el filtro proporcionado",
        raw_signature="public List<ResultadoTO> consultarDatos(FiltroVO filtro)",
        input_attributes=[
            {
                "name": "filtro",
                "type": "FiltroVO",
                "required": True,
                "description": "Filtro de consulta",
            }
        ],
        output_attributes=[
            {
                "name": "resultado",
                "type": "List<ResultadoTO>",
                "description": "Lista de resultados",
            }
        ],
        business_rules=["El filtro debe tener al menos un criterio"],
        error_messages=[
            {
                "code": "ERR001",
                "message": "Filtro inválido",
                "cause": "Filtro vacío",
                "solution": "Proporcionar al menos un criterio",
            }
        ],
        consumption_tips=["Usar paginación para grandes volúmenes"],
    )


@pytest.fixture
def sample_interface_documentation():
    """Create a sample InterfaceDocumentation for tests."""
    from jee_doc_agent.models import InterfaceDocumentation, MethodDocumentation
    
    method_doc = MethodDocumentation(
        method_name="testMethod",
        interface_name="TestFacade",
        functional_description="Test method description",
        raw_signature="void testMethod()",
    )
    
    return InterfaceDocumentation(
        interface_name="TestFacade",
        annotation="@Remote",
        file_path="/src/TestFacade.java",
        manager_path="/src/TestFacadeManager.java",
        methods=[method_doc],
        generated_at="2024-01-15T10:00:00",
    )
