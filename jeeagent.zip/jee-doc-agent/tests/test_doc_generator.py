"""Tests for DocumentationGenerator."""
import pytest
from datetime import datetime
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

from jee_doc_agent.doc_generator import DocumentationGenerator
from jee_doc_agent.config import Settings
from jee_doc_agent.models import (
    EjbContract,
    MethodSignature,
    MethodDocumentation,
    InterfaceDocumentation,
    ProjectScanResponse,
)


@pytest.fixture
def mock_settings():
    """Create mock settings."""
    settings = MagicMock(spec=Settings)
    settings.output_dir = Path("/tmp/test_output")
    settings.openai_model = "gpt-4"
    settings.openai_api_key = "test-key"
    settings.mcp_server_path = "/test/path"
    return settings


@pytest.fixture
def generator(mock_settings):
    """Create DocumentationGenerator with mocked dependencies."""
    with patch("jee_doc_agent.doc_generator.MCPClient"):
        with patch("jee_doc_agent.doc_generator.LLMAnalyzer"):
            gen = DocumentationGenerator(mock_settings)
            return gen


class TestDocumentationGenerator:
    """Tests for DocumentationGenerator class."""

    def test_init(self, mock_settings):
        """Should initialize with settings."""
        with patch("jee_doc_agent.doc_generator.MCPClient"):
            with patch("jee_doc_agent.doc_generator.LLMAnalyzer"):
                gen = DocumentationGenerator(mock_settings)
                assert gen.settings == mock_settings


class TestExtractMethodNames:
    """Tests for _extract_method_names method."""

    def test_extract_method_from_headers(self, generator):
        """Should extract method names from markdown headers."""
        markdown = """
# TestFacade

## Índice de Métodos

- [consultarDatos](#consultardatos)
- [insertarRegistro](#insertarregistro)

---

## consultarDatos

### Firma del Método

```java
public List<ItemTO> consultarDatos(FiltroVO filtro)
```

---

## insertarRegistro

### Firma del Método

```java
public Long insertarRegistro(DatosTO datos)
```

---
"""
        methods = generator._extract_method_names(markdown)
        
        assert "consultarDatos" in methods
        assert "insertarRegistro" in methods
        assert len(methods) == 2

    def test_ignore_non_method_headers(self, generator):
        """Should ignore headers that are not method names."""
        markdown = """
# MiFacade

## Índice de Métodos

## Descripción Funcional

## Firma del Método

## myMethod

---
"""
        methods = generator._extract_method_names(markdown)
        
        # Only myMethod should be extracted (lowercase first letter pattern)
        assert "myMethod" in methods
        # These start with uppercase or are special sections
        assert "Índice de Métodos" not in methods
        assert "Descripción Funcional" not in methods
        assert "Firma del Método" not in methods

    def test_empty_markdown(self, generator):
        """Should return empty set for empty markdown."""
        methods = generator._extract_method_names("")
        assert methods == set()


class TestRenderMarkdown:
    """Tests for _render_markdown method."""

    def test_render_basic_interface(self, generator):
        """Should render interface header correctly."""
        interface_doc = InterfaceDocumentation(
            interface_name="TestFacade",
            annotation="@Remote",
            file_path="/src/TestFacade.java",
            methods=[],
            generated_at="2024-01-15T10:00:00",
        )
        
        markdown = generator._render_markdown(interface_doc)
        
        assert "# TestFacade" in markdown
        assert "**Anotación:** `@Remote`" in markdown
        assert "**Archivo fuente:** `/src/TestFacade.java`" in markdown
        assert "**Generado:** 2024-01-15T10:00:00" in markdown

    def test_render_with_manager_path(self, generator):
        """Should include manager path when present."""
        interface_doc = InterfaceDocumentation(
            interface_name="TestFacade",
            annotation="@Remote",
            file_path="/src/TestFacade.java",
            manager_path="/src/TestManager.java",
            methods=[],
            generated_at="2024-01-15T10:00:00",
        )
        
        markdown = generator._render_markdown(interface_doc)
        
        assert "**Manager:** `/src/TestManager.java`" in markdown

    def test_render_toc(self, generator):
        """Should render table of contents."""
        method_doc = MethodDocumentation(
            method_name="consultarDatos",
            interface_name="TestFacade",
            functional_description="Consulta datos",
            raw_signature="void consultarDatos()",
        )
        interface_doc = InterfaceDocumentation(
            interface_name="TestFacade",
            annotation="@Remote",
            file_path="/src/TestFacade.java",
            methods=[method_doc],
            generated_at="2024-01-15T10:00:00",
        )
        
        markdown = generator._render_markdown(interface_doc)
        
        assert "## Índice de Métodos" in markdown
        assert "[consultarDatos](#consultardatos)" in markdown


class TestRenderMethodMarkdown:
    """Tests for _render_method_markdown method."""

    def test_render_method_header(self, generator):
        """Should render method header and signature."""
        method = MethodDocumentation(
            method_name="testMethod",
            interface_name="TestFacade",
            functional_description="Test description",
            raw_signature="public void testMethod()",
        )
        
        lines = generator._render_method_markdown(method)
        content = "\n".join(lines)
        
        assert "## testMethod" in content
        assert "### Firma del Método" in content
        assert "```java" in content
        assert "public void testMethod()" in content

    def test_render_functional_description(self, generator):
        """Should render functional description."""
        method = MethodDocumentation(
            method_name="test",
            interface_name="Test",
            functional_description="Esta función realiza una consulta importante",
            raw_signature="void test()",
        )
        
        lines = generator._render_method_markdown(method)
        content = "\n".join(lines)
        
        assert "### Descripción Funcional" in content
        assert "Esta función realiza una consulta importante" in content

    def test_render_business_rules(self, generator):
        """Should render business rules as numbered list."""
        method = MethodDocumentation(
            method_name="test",
            interface_name="Test",
            functional_description="Test",
            raw_signature="void test()",
            business_rules=[
                "Validar que el monto sea positivo",
                "Verificar permisos del usuario",
            ],
        )
        
        lines = generator._render_method_markdown(method)
        content = "\n".join(lines)
        
        assert "### Reglas de Negocio" in content
        assert "1. Validar que el monto sea positivo" in content
        assert "2. Verificar permisos del usuario" in content

    def test_render_input_attributes_table(self, generator):
        """Should render input attributes as table."""
        method = MethodDocumentation(
            method_name="test",
            interface_name="Test",
            functional_description="Test",
            raw_signature="void test(String param)",
            input_attributes=[
                {
                    "name": "param",
                    "type": "String",
                    "required": True,
                    "description": "Parámetro de entrada",
                    "validations": ["No vacío"],
                }
            ],
        )
        
        lines = generator._render_method_markdown(method)
        content = "\n".join(lines)
        
        assert "### Atributos de Entrada" in content
        assert "| Nombre | Tipo | Requerido | Descripción | Validaciones |" in content
        assert "| `param` | `String` | ✅ | Parámetro de entrada | No vacío |" in content

    def test_render_output_attributes_table(self, generator):
        """Should render output attributes as table."""
        method = MethodDocumentation(
            method_name="test",
            interface_name="Test",
            functional_description="Test",
            raw_signature="Long test()",
            output_attributes=[
                {"name": "resultado", "type": "Long", "description": "ID generado"}
            ],
        )
        
        lines = generator._render_method_markdown(method)
        content = "\n".join(lines)
        
        assert "### Atributos de Salida" in content
        assert "| `resultado` | `Long` | ID generado |" in content

    def test_render_error_messages_table(self, generator):
        """Should render error messages as table."""
        method = MethodDocumentation(
            method_name="test",
            interface_name="Test",
            functional_description="Test",
            raw_signature="void test()",
            error_messages=[
                {
                    "code": "ERR001",
                    "message": "Error de validación",
                    "cause": "Datos inválidos",
                    "solution": "Verificar datos",
                }
            ],
        )
        
        lines = generator._render_method_markdown(method)
        content = "\n".join(lines)
        
        assert "### Mapeo de Errores" in content
        assert "| `ERR001` | Error de validación | Datos inválidos | Verificar datos |" in content

    def test_render_consumption_tips(self, generator):
        """Should render consumption tips as numbered list."""
        method = MethodDocumentation(
            method_name="test",
            interface_name="Test",
            functional_description="Test",
            raw_signature="void test()",
            consumption_tips=[
                "Usar conexión segura",
                "Implementar retry logic",
            ],
        )
        
        lines = generator._render_method_markdown(method)
        content = "\n".join(lines)
        
        assert "### Tips de Consumo" in content
        assert "1. Usar conexión segura" in content
        assert "2. Implementar retry logic" in content

    def test_render_dto_details(self, generator):
        """Should render DTO details with fields table."""
        method = MethodDocumentation(
            method_name="test",
            interface_name="Test",
            functional_description="Test",
            raw_signature="void test()",
            dto_details=[
                {
                    "name": "PersonaTO",
                    "file_path": "/src/PersonaTO.java",
                    "fields": [
                        {
                            "name": "nombre",
                            "type": "String",
                            "required": True,
                            "validations": ["@NotNull"],
                            "description": "Nombre completo",
                        }
                    ],
                }
            ],
        )
        
        lines = generator._render_method_markdown(method)
        content = "\n".join(lines)
        
        assert "### Detalle de DTOs" in content
        assert "#### PersonaTO" in content
        assert "*Archivo:* `/src/PersonaTO.java`" in content
        assert "| `nombre` | `String` | ✅ | @NotNull | Nombre completo |" in content


class TestMergeDocumentation:
    """Tests for _merge_documentation method."""

    def test_merge_adds_new_method(self, generator):
        """Should add new method to existing documentation."""
        existing_content = """# TestFacade

**Anotación:** `@Remote`
**Archivo fuente:** `/src/TestFacade.java`
**Generado:** 2024-01-15T10:00:00

---

## Índice de Métodos

- [existingMethod](#existingmethod)

---

## existingMethod

### Descripción Funcional

Existing method description

---
"""
        new_method = MethodDocumentation(
            method_name="newMethod",
            interface_name="TestFacade",
            functional_description="New method description",
            raw_signature="void newMethod()",
        )
        new_doc = InterfaceDocumentation(
            interface_name="TestFacade",
            annotation="@Remote",
            file_path="/src/TestFacade.java",
            methods=[new_method],
            generated_at="2024-01-16T10:00:00",
        )
        
        merged = generator._merge_documentation(existing_content, new_doc)
        
        # Should contain both methods in TOC
        assert "[existingMethod](#existingmethod)" in merged
        assert "[newMethod](#newmethod)" in merged
        # Should contain new method documentation
        assert "## newMethod" in merged
        assert "New method description" in merged

    def test_merge_skips_existing_method(self, generator):
        """Should skip methods that already exist."""
        existing_content = """# TestFacade

## Índice de Métodos

- [existingMethod](#existingmethod)

---

## existingMethod

### Descripción Funcional

Original description

---
"""
        existing_method = MethodDocumentation(
            method_name="existingMethod",
            interface_name="TestFacade",
            functional_description="New description (should not appear)",
            raw_signature="void existingMethod()",
        )
        new_doc = InterfaceDocumentation(
            interface_name="TestFacade",
            annotation="@Remote",
            file_path="/src/TestFacade.java",
            methods=[existing_method],
            generated_at="2024-01-16T10:00:00",
        )
        
        merged = generator._merge_documentation(existing_content, new_doc)
        
        # Should keep original description
        assert "Original description" in merged
        # Should NOT have duplicate method entries
        assert merged.count("## existingMethod") == 1

    def test_merge_returns_original_if_no_new_methods(self, generator):
        """Should return original content if all methods exist."""
        existing_content = """# TestFacade

## Índice de Métodos

- [method1](#method1)

---

## method1

---
"""
        existing_method = MethodDocumentation(
            method_name="method1",
            interface_name="TestFacade",
            functional_description="Description",
            raw_signature="void method1()",
        )
        new_doc = InterfaceDocumentation(
            interface_name="TestFacade",
            annotation="@Remote",
            file_path="/src/TestFacade.java",
            methods=[existing_method],
            generated_at="2024-01-16T10:00:00",
        )
        
        merged = generator._merge_documentation(existing_content, new_doc)
        
        # Should be essentially the same (just timestamp updated)
        assert "## method1" in merged


class TestInsertMethodsIntoMarkdown:
    """Tests for _insert_methods_into_markdown method."""

    def test_insert_updates_toc(self, generator):
        """Should update table of contents with new methods."""
        existing = """## Índice de Métodos

- [method1](#method1)

---
"""
        new_method = MethodDocumentation(
            method_name="method2",
            interface_name="Test",
            functional_description="Test",
            raw_signature="void method2()",
        )
        
        result = generator._insert_methods_into_markdown(
            existing, [new_method], "Test"
        )
        
        assert "[method2](#method2)" in result

    def test_insert_adds_method_content(self, generator):
        """Should add method documentation content."""
        existing = """## Índice de Métodos

- [method1](#method1)

---

## method1

---
"""
        new_method = MethodDocumentation(
            method_name="newMethod",
            interface_name="Test",
            functional_description="New method functionality",
            raw_signature="void newMethod()",
        )
        
        result = generator._insert_methods_into_markdown(
            existing, [new_method], "Test"
        )
        
        assert "## newMethod" in result
        assert "New method functionality" in result
