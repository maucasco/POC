"""Tests for jee-doc-agent models."""
import pytest
from pydantic import ValidationError

from jee_doc_agent.models import (
    DataField,
    DtoDefinition,
    MethodParameter,
    MethodSignature,
    EjbContract,
    ProjectScanResponse,
    MethodDocumentation,
    InterfaceDocumentation,
)


class TestDataField:
    """Tests for DataField model."""

    def test_required_fields(self):
        """Should require name and type_hint."""
        field = DataField(name="campo1", type_hint="String")
        assert field.name == "campo1"
        assert field.type_hint == "String"
        assert field.description is None

    def test_with_description(self):
        """Should accept optional description."""
        field = DataField(
            name="cantidad", 
            type_hint="int", 
            description="Cantidad de registros"
        )
        assert field.description == "Cantidad de registros"

    def test_missing_required_field_raises_error(self):
        """Should raise ValidationError for missing required fields."""
        with pytest.raises(ValidationError):
            DataField(name="test")  # missing type_hint


class TestDtoDefinition:
    """Tests for DtoDefinition model."""

    def test_minimal_dto(self):
        """Should create DTO with just name."""
        dto = DtoDefinition(name="ConsultaVO")
        assert dto.name == "ConsultaVO"
        assert dto.file_path is None
        assert dto.fields == []

    def test_dto_with_fields(self):
        """Should create DTO with fields."""
        fields = [
            DataField(name="id", type_hint="Long"),
            DataField(name="nombre", type_hint="String"),
        ]
        dto = DtoDefinition(
            name="PersonaTO",
            file_path="/src/model/PersonaTO.java",
            fields=fields,
        )
        assert len(dto.fields) == 2
        assert dto.file_path == "/src/model/PersonaTO.java"


class TestMethodParameter:
    """Tests for MethodParameter model."""

    def test_simple_parameter(self):
        """Should create parameter with type hint."""
        param = MethodParameter(name="valor", type_hint="String")
        assert param.name == "valor"
        assert param.type_hint == "String"
        assert param.dto is None

    def test_parameter_with_dto(self):
        """Should support nested DTO definition."""
        dto = DtoDefinition(name="ParametrosVO")
        param = MethodParameter(
            name="parametros",
            type_hint="ParametrosVO",
            dto=dto,
        )
        assert param.dto is not None
        assert param.dto.name == "ParametrosVO"


class TestMethodSignature:
    """Tests for MethodSignature model."""

    def test_void_method_no_params(self):
        """Should create method with void return and no params."""
        method = MethodSignature(name="init", return_type="void")
        assert method.name == "init"
        assert method.return_type == "void"
        assert method.parameters == []

    def test_method_with_parameters(self):
        """Should create method with parameters."""
        params = [
            MethodParameter(name="id", type_hint="Long"),
            MethodParameter(name="datos", type_hint="DatosTO"),
        ]
        method = MethodSignature(
            name="buscar",
            return_type="ResultadoTO",
            parameters=params,
        )
        assert len(method.parameters) == 2
        assert method.return_type == "ResultadoTO"

    def test_method_with_documentation(self):
        """Should accept documentation and manager_summary."""
        method = MethodSignature(
            name="consultar",
            return_type="List<ItemTO>",
            documentation="Consulta todos los items",
            manager_summary="Realiza query a la BD",
        )
        assert method.documentation == "Consulta todos los items"
        assert method.manager_summary == "Realiza query a la BD"


class TestEjbContract:
    """Tests for EjbContract model."""

    def test_minimal_contract(self):
        """Should create contract with required fields."""
        contract = EjbContract(
            interface_name="MiServicioFacade",
            annotation="@Remote",
            file_path="/src/ejb/MiServicioFacade.java",
        )
        assert contract.interface_name == "MiServicioFacade"
        assert contract.annotation == "@Remote"
        assert contract.methods == []
        assert contract.related_manager_path is None

    def test_contract_with_methods(self):
        """Should create contract with methods."""
        methods = [
            MethodSignature(name="crear", return_type="Long"),
            MethodSignature(name="eliminar", return_type="void"),
        ]
        contract = EjbContract(
            interface_name="CrudFacade",
            annotation="@Local",
            file_path="/src/CrudFacade.java",
            methods=methods,
            related_manager_path="/src/CrudManager.java",
        )
        assert len(contract.methods) == 2
        assert contract.related_manager_path == "/src/CrudManager.java"


class TestProjectScanResponse:
    """Tests for ProjectScanResponse model."""

    def test_empty_scan(self):
        """Should create response with no contracts."""
        response = ProjectScanResponse(
            agent_id="test-agent",
            contracts=[],
        )
        assert response.agent_id == "test-agent"
        assert response.contracts == []
        assert response.markdown is None

    def test_scan_with_contracts(self):
        """Should create response with contracts."""
        contracts = [
            EjbContract(
                interface_name="Facade1",
                annotation="@Remote",
                file_path="/Facade1.java",
            ),
        ]
        response = ProjectScanResponse(
            agent_id="scanner-001",
            contracts=contracts,
            markdown="# Resumen\n...",
        )
        assert len(response.contracts) == 1
        assert response.markdown is not None


class TestMethodDocumentation:
    """Tests for MethodDocumentation model."""

    def test_minimal_documentation(self):
        """Should create documentation with required fields."""
        doc = MethodDocumentation(
            method_name="consultar",
            interface_name="ConsultaFacade",
            functional_description="Consulta registros filtrados",
            raw_signature="public List<ItemTO> consultar(FiltroVO filtro)",
        )
        assert doc.method_name == "consultar"
        assert doc.interface_name == "ConsultaFacade"
        assert doc.input_attributes == []
        assert doc.output_attributes == []
        assert doc.error_messages == []
        assert doc.consumption_tips == []
        assert doc.business_rules == []
        assert doc.dto_details == []

    def test_full_documentation(self):
        """Should create documentation with all fields."""
        doc = MethodDocumentation(
            method_name="insertarPropuesta",
            interface_name="PropuestaFacade",
            functional_description="Inserta una nueva propuesta comercial",
            raw_signature="public Long insertarPropuesta(PropuestaTO propuesta)",
            input_attributes=[
                {"name": "propuesta", "type": "PropuestaTO", "required": True}
            ],
            output_attributes=[
                {"name": "id", "type": "Long", "description": "ID generado"}
            ],
            error_messages=[
                {"code": "ERR001", "message": "Propuesta inválida"}
            ],
            consumption_tips=["Validar datos antes de enviar"],
            business_rules=["El monto no puede ser negativo"],
            dto_details=[
                {"name": "PropuestaTO", "fields": [{"name": "monto", "type": "BigDecimal"}]}
            ],
        )
        assert len(doc.input_attributes) == 1
        assert len(doc.output_attributes) == 1
        assert len(doc.error_messages) == 1
        assert len(doc.consumption_tips) == 1
        assert len(doc.business_rules) == 1
        assert len(doc.dto_details) == 1


class TestInterfaceDocumentation:
    """Tests for InterfaceDocumentation model."""

    def test_interface_doc_creation(self):
        """Should create interface documentation."""
        method_doc = MethodDocumentation(
            method_name="test",
            interface_name="TestFacade",
            functional_description="Test method",
            raw_signature="void test()",
        )
        interface_doc = InterfaceDocumentation(
            interface_name="TestFacade",
            annotation="@Remote",
            file_path="/TestFacade.java",
            methods=[method_doc],
            generated_at="2024-01-15T10:30:00",
        )
        assert interface_doc.interface_name == "TestFacade"
        assert len(interface_doc.methods) == 1
        assert interface_doc.manager_path is None
