"""MCP Client for consuming the JEE Interpreter MCP Server via stdio."""
from __future__ import annotations

import json
import logging
import subprocess
from typing import Any

from jee_doc_agent.config import Settings
from jee_doc_agent.models import EjbContract, ProjectScanResponse

LOGGER = logging.getLogger(__name__)


class MCPClient:
    """Client for the JEE MCP Server using stdio transport."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.server_path = settings.mcp_server_path
        self.python_path = settings.mcp_python_path
        self._request_id = 0

    def _start_server(self) -> subprocess.Popen:
        """Start the MCP server as a subprocess."""
        LOGGER.info("Starting MCP server from: %s", self.server_path)
        
        process = subprocess.Popen(
            [self.python_path, "-m", "src.main", "--stdio"],
            cwd=self.server_path,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )
        
        # Initialize the MCP connection
        init_id = self._send_request(process, "initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "jee-doc-agent", "version": "1.0.0"}
        })
        
        # Read initialization response
        self._read_response(process, expected_id=init_id)
        
        # Send initialized notification
        self._send_notification(process, "notifications/initialized", {})
        
        return process

    def _stop_server(self, process: subprocess.Popen) -> None:
        """Stop the MCP server subprocess."""
        try:
            process.terminate()
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()

    def _send_request(self, process: subprocess.Popen, method: str, params: dict[str, Any]) -> int:
        """Send a JSON-RPC request to the MCP server."""
        self._request_id += 1
        request = {
            "jsonrpc": "2.0",
            "id": self._request_id,
            "method": method,
            "params": params,
        }
        
        request_json = json.dumps(request)
        LOGGER.debug("Sending request: %s", request_json)
        
        if process.stdin:
            process.stdin.write(request_json + "\n")
            process.stdin.flush()
        
        return self._request_id

    def _send_notification(self, process: subprocess.Popen, method: str, params: dict[str, Any]) -> None:
        """Send a JSON-RPC notification (no id, no response expected)."""
        notification = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
        }
        
        notification_json = json.dumps(notification)
        LOGGER.debug("Sending notification: %s", notification_json)
        
        if process.stdin:
            process.stdin.write(notification_json + "\n")
            process.stdin.flush()

    def _read_response(self, process: subprocess.Popen, expected_id: int | None = None) -> dict[str, Any]:
        """Read a JSON-RPC response from the MCP server."""
        if not process.stdout:
            raise RuntimeError("Server stdout not available")
        
        while True:
            line = process.stdout.readline()
            if not line:
                stderr = process.stderr.read() if process.stderr else ""
                raise RuntimeError(f"No response from MCP server. Stderr: {stderr}")
            
            LOGGER.debug("Received: %s", line.strip())
            
            try:
                parsed = json.loads(line.strip())
            except json.JSONDecodeError:
                continue
            
            # If this is a notification (no id), skip it
            if "id" not in parsed:
                LOGGER.debug("Skipping notification: %s", parsed.get("method", "unknown"))
                continue
            
            # If we're waiting for a specific id, check it matches
            if expected_id is not None and parsed.get("id") != expected_id:
                LOGGER.debug("Skipping response with id %s, waiting for %s", parsed.get("id"), expected_id)
                continue
            
            return parsed

    async def scan_project(
        self,
        project_path: str,
        detailed_scan: bool = False,
    ) -> ProjectScanResponse:
        """Scan a Java EE project for EJB contracts."""
        LOGGER.info("Scanning project: %s (detailed=%s)", project_path, detailed_scan)
        
        process = self._start_server()
        
        try:
            # Call the scan tool
            request_id = self._send_request(process, "tools/call", {
                "name": "scan_ejb_contracts",
                "arguments": {
                    "project_path": project_path,
                    "detailed_scan": detailed_scan,
                },
            })
            
            response = self._read_response(process, expected_id=request_id)
            return self._parse_response(response)
            
        finally:
            self._stop_server(process)

    def _parse_response(self, response: dict[str, Any]) -> ProjectScanResponse:
        """Parse MCP response into ProjectScanResponse."""
        if "error" in response:
            raise ValueError(f"MCP error: {response['error']}")
        
        if "result" not in response:
            raise ValueError("No result in MCP response")
        
        return self._extract_scan_result(response["result"])

    def _extract_scan_result(self, result: dict[str, Any]) -> ProjectScanResponse:
        """Extract ProjectScanResponse from MCP result."""
        # Handle nested structure
        if "structuredContent" in result:
            return ProjectScanResponse(**result["structuredContent"])
        
        # Handle content array format
        if "content" in result and isinstance(result["content"], list):
            for item in result["content"]:
                if item.get("type") == "text":
                    try:
                        data = json.loads(item.get("text", "{}"))
                        return ProjectScanResponse(**data)
                    except json.JSONDecodeError:
                        continue
        
        # Direct format
        return ProjectScanResponse(**result)

    async def get_method_details(
        self,
        contract: EjbContract,
        method_name: str,
    ) -> dict[str, Any] | None:
        """Get detailed information for a specific method."""
        for method in contract.methods:
            if method.name == method_name:
                return {
                    "method": method,
                    "contract": contract,
                    "manager_path": contract.related_manager_path,
                }
        return None
