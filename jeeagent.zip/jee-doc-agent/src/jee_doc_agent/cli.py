"""Command-line interface for the JEE Documentation Agent."""
from __future__ import annotations

import asyncio
from datetime import datetime
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich.markdown import Markdown

from jee_doc_agent.config import get_settings
from jee_doc_agent.doc_generator import DocumentationGenerator
from jee_doc_agent.mcp_client import MCPClient

app = typer.Typer(
    name="jee-doc",
    help="Agente documentador funcional JEE - Genera documentación técnica desde contratos EJB",
    add_completion=False,
)
console = Console()


@app.command("scan")
def scan_project(
    project_path: str = typer.Argument(
        ..., help="Ruta absoluta al proyecto JEE a escanear"
    ),
) -> None:
    """Escanea un proyecto JEE y muestra los contratos EJB encontrados."""
    settings = get_settings()
    client = MCPClient(settings)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("Escaneando proyecto...", total=None)
        result = asyncio.run(client.scan_project(project_path))

    console.print(f"\n[bold green]✓[/] Encontrados {len(result.contracts)} contratos EJB\n")

    for contract in result.contracts:
        table = Table(title=f"📋 {contract.interface_name}", show_header=True)
        table.add_column("Propiedad", style="cyan")
        table.add_column("Valor", style="white")

        table.add_row("Anotación", contract.annotation)
        table.add_row("Archivo", contract.file_path)
        table.add_row("Manager", contract.related_manager_path or "No encontrado")
        table.add_row("Métodos", str(len(contract.methods)))

        console.print(table)
        console.print()

        # List methods
        if contract.methods:
            method_table = Table(title="Métodos", show_header=True)
            method_table.add_column("#", style="dim")
            method_table.add_column("Nombre", style="green")
            method_table.add_column("Retorno", style="yellow")
            method_table.add_column("Parámetros", style="white")

            for i, method in enumerate(contract.methods, 1):
                params = ", ".join([p.name for p in method.parameters])
                method_table.add_row(
                    str(i),
                    method.name,
                    method.return_type,
                    params[:50] + "..." if len(params) > 50 else params,
                )

            console.print(method_table)
            console.print()


@app.command("doc")
def generate_documentation(
    project_path: str = typer.Argument(
        ..., help="Ruta absoluta al proyecto JEE"
    ),
    output: Optional[Path] = typer.Option(
        None, "--output", "-o", help="Directorio de salida para la documentación"
    ),
    method_filter: Optional[str] = typer.Option(
        None, "--filter", "-f", help="Filtrar métodos por nombre (búsqueda parcial)"
    ),
) -> None:
    """Genera documentación funcional completa en Markdown."""
    settings = get_settings()
    generator = DocumentationGenerator(settings)

    console.print(f"\n[bold]Generando documentación para:[/] {project_path}\n")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Procesando contratos EJB...", total=None)
        
        try:
            docs = asyncio.run(
                generator.generate_project_documentation(
                    project_path,
                    output_path=output,
                    method_filter=method_filter,
                )
            )
        except Exception as e:
            console.print(f"\n[bold red]Error:[/] {e}")
            raise typer.Exit(1)

    output_dir = output or settings.output_dir
    console.print(f"\n[bold green]✓[/] Documentación generada exitosamente!")
    console.print(f"[dim]Archivos guardados en:[/] {output_dir.absolute()}\n")

    for doc in docs:
        console.print(f"  📄 {doc.interface_name}_documentation.md ({len(doc.methods)} métodos)")


@app.command("method")
def document_method(
    project_path: str = typer.Argument(..., help="Ruta absoluta al proyecto JEE"),
    interface: str = typer.Option(..., "--interface", "-i", help="Nombre de la interface EJB"),
    method: str = typer.Option(..., "--method", "-m", help="Nombre del método a documentar"),
    output: Optional[Path] = typer.Option(
        None, "--output", "-o", help="Archivo de salida (opcional)"
    ),
    merge: bool = typer.Option(
        True, "--merge/--no-merge", help="Merge con documentación existente (default: True)"
    ),
) -> None:
    """Genera documentación para un método específico."""
    settings = get_settings()
    generator = DocumentationGenerator(settings)

    console.print(f"\n[bold]Documentando:[/] {interface}.{method}\n")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("Analizando método...", total=None)
        
        try:
            doc = asyncio.run(
                generator.generate_method_documentation(project_path, interface, method)
            )
        except Exception as e:
            console.print(f"\n[bold red]Error:[/] {e}")
            raise typer.Exit(1)

    if not doc:
        console.print(f"[bold red]Error:[/] Método {interface}.{method} no encontrado")
        raise typer.Exit(1)

    # Render to markdown
    lines = _render_single_method(doc)
    method_markdown = "\n".join(lines)

    # Determine output path
    if output:
        output_file = output
    else:
        # Use default output directory with interface name
        output_dir = settings.output_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{interface}_documentation.md"
    
    if merge and output_file.exists():
        # Merge with existing documentation
        existing_content = output_file.read_text(encoding="utf-8")
        
        # Check if method already exists
        from jee_doc_agent.doc_generator import DocumentationGenerator
        existing_methods = generator._extract_method_names(existing_content)
        
        if doc.method_name in existing_methods:
            console.print(f"[yellow]⚠ Método {doc.method_name} ya existe en la documentación, saltando[/]")
        else:
            # Create a minimal InterfaceDocumentation for merge
            from jee_doc_agent.models import InterfaceDocumentation
            from datetime import datetime
            temp_doc = InterfaceDocumentation(
                interface_name=interface,
                annotation="",
                file_path="",
                manager_path=None,
                methods=[doc],
                generated_at=datetime.now().isoformat(),
            )
            merged_content = generator._merge_documentation(existing_content, temp_doc)
            output_file.write_text(merged_content, encoding="utf-8")
            console.print(f"\n[bold green]✓[/] Documentación mergeada en: {output_file}")
    else:
        # Create new file or overwrite (no merge)
        if not output_file.exists():
            # Create header for new file
            from datetime import datetime
            header_lines = [
                f"# {interface}",
                "",
                f"**Generado:** {datetime.now().isoformat()}",
                "",
                "---",
                "",
                "## Índice de Métodos",
                "",
                f"- [{doc.method_name}](#{doc.method_name.lower()})",
                "",
                "---",
                "",
            ]
            full_content = "\n".join(header_lines) + method_markdown + "\n\n---\n"
        else:
            full_content = method_markdown
        
        output_file.parent.mkdir(parents=True, exist_ok=True)
        output_file.write_text(full_content, encoding="utf-8")
        console.print(f"\n[bold green]✓[/] Documentación guardada en: {output_file}")


@app.command("list-methods")
def list_methods(
    project_path: str = typer.Argument(..., help="Ruta absoluta al proyecto JEE"),
    interface: Optional[str] = typer.Option(
        None, "--interface", "-i", help="Filtrar por interface específica"
    ),
) -> None:
    """Lista todos los métodos disponibles en el proyecto."""
    settings = get_settings()
    client = MCPClient(settings)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("Escaneando...", total=None)
        result = asyncio.run(client.scan_project(project_path))

    contracts = result.contracts
    if interface:
        contracts = [c for c in contracts if interface.lower() in c.interface_name.lower()]

    if not contracts:
        console.print("[yellow]No se encontraron contratos[/]")
        return

    for contract in contracts:
        console.print(f"\n[bold cyan]{contract.interface_name}[/] ({contract.annotation})")
        for method in contract.methods:
            params = ", ".join([f"{p.type_hint} {p.name}" for p in method.parameters])
            console.print(f"  • [green]{method.name}[/]({params[:60]}{'...' if len(params) > 60 else ''})")
            console.print(f"    [dim]→ {method.return_type}[/]")


def _render_single_method(doc) -> list[str]:
    """Render a single method documentation."""
    from jee_doc_agent.doc_generator import DocumentationGenerator
    settings = get_settings()
    generator = DocumentationGenerator(settings)
    return generator._render_method_markdown(doc)


@app.callback()
def main():
    """JEE Documentation Agent - Genera documentación funcional desde contratos EJB."""
    pass


if __name__ == "__main__":
    app()
