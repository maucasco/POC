"""Pydantic models for the documentation agent."""
from __future__ import annotations

from pathlib import Path
from typing import List, Optional

from pydantic import BaseModel, Field


class DataField(BaseModel):
    """DTO field description."""
    name: str
    type_hint: str
    description: str | None = None


class DtoDefinition(BaseModel):
    """DTO definition with fields."""
    name: str
    file_path: str | None = None
    fields: List[DataField] = Field(default_factory=list)


class MethodParameter(BaseModel):
    """Method parameter with optional DTO resolution."""
    name: str
    type_hint: str
    dto: DtoDefinition | None = None


class MethodSignature(BaseModel):
    """EJB method signature."""
    name: str
    return_type: str
    parameters: List[MethodParameter] = Field(default_factory=list)
    documentation: str | None = None
    manager_summary: str | None = None


class EjbContract(BaseModel):
    """EJB interface contract."""
    interface_name: str
    annotation: str
    file_path: str
    methods: List[MethodSignature] = Field(default_factory=list)
    related_manager_path: str | None = None


class ProjectScanResponse(BaseModel):
    """Response from the MCP server scan."""
    agent_id: str
    contracts: List[EjbContract]
    markdown: str | None = None


class MethodDocumentation(BaseModel):
    """Generated documentation for a single method."""
    method_name: str
    interface_name: str
    functional_description: str = Field(
        description="Descripción funcional interpretando la lógica del manager"
    )
    input_attributes: List[dict] = Field(
        default_factory=list,
        description="Tabla de atributos de entrada"
    )
    output_attributes: List[dict] = Field(
        default_factory=list,
        description="Tabla de atributos de salida"
    )
    error_messages: List[dict] = Field(
        default_factory=list,
        description="Mapeo de mensajes de error"
    )
    consumption_tips: List[str] = Field(
        default_factory=list,
        description="Tips importantes de consumo"
    )
    raw_signature: str = Field(
        description="Firma original del método"
    )
    business_rules: List[str] = Field(
        default_factory=list,
        description="Reglas de negocio extraídas del código"
    )
    dto_details: List[dict] = Field(
        default_factory=list,
        description="Detalles de DTOs con sus campos"
    )


class InterfaceDocumentation(BaseModel):
    """Documentation for an entire EJB interface."""
    interface_name: str
    annotation: str
    file_path: str
    manager_path: str | None = None
    methods: List[MethodDocumentation] = Field(default_factory=list)
    generated_at: str = Field(description="Timestamp de generación")
