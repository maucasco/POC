"""Configuration settings for the JEE Documentation Agent."""
from __future__ import annotations

import logging
import os
import sys
from functools import lru_cache
from pathlib import Path
from typing import Literal

from dotenv import load_dotenv
from pydantic import BaseModel, Field

# Load environment variables
ENV_PATH = Path(__file__).resolve().parents[3] / ".env"
if ENV_PATH.exists():
    load_dotenv(ENV_PATH)
else:
    load_dotenv()


class Settings(BaseModel):
    """Application configuration loaded from environment."""

    mcp_server_path: str = Field(
        default="/app/intepreter-jee-mcp-server",
        description="Ruta al proyecto del servidor MCP interpreter"
    )
    mcp_python_path: str = Field(
        default=os.getenv("MCP_PYTHON_PATH", sys.executable),
        description="Ruta al intérprete Python para el servidor MCP"
    )
    llm_provider: Literal["openai", "anthropic"] = Field(
        default="openai",
        description="Proveedor LLM para análisis de código"
    )
    openai_api_key: str | None = Field(default=None)
    openai_model: str = Field(default="gpt-4o-mini")
    anthropic_api_key: str | None = Field(default=None)
    anthropic_model: str = Field(default="claude-3-5-sonnet-20241022")
    output_dir: Path = Field(default=Path("./docs"))
    log_level: str = Field(default="INFO")
    max_tokens: int = Field(default=4096)

    @classmethod
    def from_env(cls) -> "Settings":
        """Load settings from environment variables."""
        return cls(
            mcp_server_path=os.getenv("MCP_SERVER_PATH", "/app/intepreter-jee-mcp-server"),
            mcp_python_path=os.getenv("MCP_PYTHON_PATH", sys.executable),
            llm_provider=os.getenv("LLM_PROVIDER", "openai"),
            openai_api_key=os.getenv("OPENAI_API_KEY"),
            openai_model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            anthropic_api_key=os.getenv("ANTHROPIC_API_KEY"),
            anthropic_model=os.getenv("ANTHROPIC_MODEL", "claude-3-5-sonnet-20241022"),
            output_dir=Path(os.getenv("OUTPUT_DIR", "./docs")),
            log_level=os.getenv("LOG_LEVEL", "INFO"),
        )

    def get_api_key(self) -> str:
        """Return the API key for the configured provider."""
        if self.llm_provider == "openai":
            if not self.openai_api_key:
                raise ValueError("OPENAI_API_KEY not configured")
            return self.openai_api_key
        if not self.anthropic_api_key:
            raise ValueError("ANTHROPIC_API_KEY not configured")
        return self.anthropic_api_key

    def get_model(self) -> str:
        """Return the model name for the configured provider."""
        if self.llm_provider == "openai":
            return self.openai_model
        return self.anthropic_model


def configure_logging(settings: Settings) -> None:
    """Configure logging based on settings."""
    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return cached settings instance."""
    settings = Settings.from_env()
    configure_logging(settings)
    return settings
