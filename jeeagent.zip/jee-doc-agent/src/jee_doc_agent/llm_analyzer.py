"""LLM-powered analysis for Java code interpretation."""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

from jee_doc_agent.config import Settings
from jee_doc_agent.models import MethodSignature, MethodDocumentation, DtoDefinition

LOGGER = logging.getLogger(__name__)

# Regex patterns for Java parsing
FIELD_PATTERN = re.compile(
    r"(?:@\w+(?:\([^)]*\))?\s+)*"  # Annotations
    r"(?:private|protected|public)\s+"
    r"(?:static\s+)?(?:final\s+)?"
    r"(?P<type>[\w<>\[\],\s]+?)\s+"
    r"(?P<name>\w+)\s*(?:=|;)",
    re.MULTILINE
)
IMPORT_PATTERN = re.compile(r"import\s+([\w.]+);")


class LLMAnalyzer:
    """Analyzes Java code using LLM to generate functional documentation."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._client = None
        self._dto_cache: dict[str, str] = {}

    def _get_client(self):
        """Lazy initialization of the LLM client."""
        if self._client is not None:
            return self._client

        if self.settings.llm_provider == "openai":
            from openai import OpenAI
            self._client = OpenAI(api_key=self.settings.get_api_key())
        else:
            from anthropic import Anthropic
            self._client = Anthropic(api_key=self.settings.get_api_key())
        
        return self._client

    async def analyze_method(
        self,
        method: MethodSignature,
        interface_name: str,
        manager_path: str | None,
    ) -> MethodDocumentation:
        """Analyze a method and generate comprehensive documentation."""
        LOGGER.info("Analyzing method: %s.%s", interface_name, method.name)

        # Read manager code if available
        manager_code = ""
        manager_imports: list[str] = []
        manager_javadoc: dict = {}
        inline_comments: list[str] = []
        
        if manager_path:
            manager_imports = self._extract_imports(manager_path)
            
            # Extract Javadoc for the method
            try:
                manager_content = Path(manager_path).read_text(encoding="utf-8", errors="ignore")
                manager_javadoc = self._extract_javadoc_for_method(manager_content, method.name)
            except Exception as e:
                LOGGER.warning("Error extracting Javadoc: %s", e)
            
            # Read manager method code (includes Javadoc prepended)
            manager_code = self._read_manager_method(manager_path, method.name)
            
            # Extract inline comments from the method code
            inline_comments = self._extract_inline_comments(manager_code)

        # Collect DTO source code for enriched analysis
        dto_sources = self._collect_dto_sources(method, manager_path, manager_imports)
        
        # Build the analysis prompt with enriched information
        prompt = self._build_analysis_prompt(
            method, interface_name, manager_code, dto_sources, manager_javadoc, inline_comments
        )

        # Call LLM for analysis
        analysis = await self._call_llm(prompt)

        # Parse the LLM response into structured documentation
        return self._parse_analysis(analysis, method, interface_name, dto_sources)

    def _extract_imports(self, file_path: str) -> list[str]:
        """Extract all import statements from a Java file."""
        try:
            path = Path(file_path)
            if not path.exists():
                return []
            content = path.read_text(encoding="utf-8", errors="ignore")
            return IMPORT_PATTERN.findall(content)
        except Exception as e:
            LOGGER.warning("Error extracting imports from %s: %s", file_path, e)
            return []

    def _extract_javadoc_for_method(self, content: str, method_name: str) -> dict:
        """Extract Javadoc comment for a specific method.
        
        Returns dict with:
            - description: Main description
            - params: Dict of param name -> description
            - returns: Return description
            - throws: List of exception descriptions
        """
        javadoc_info = {
            "description": "",
            "params": {},
            "returns": "",
            "throws": [],
        }
        
        # Strategy: Find the method signature first, then look backwards for the Javadoc
        # This ensures we get the Javadoc that's immediately before THIS method
        
        # Find the method signature
        method_sig_pattern = rf'(?:public|private|protected)\s+[\w<>\[\],\s]+\s+{re.escape(method_name)}\s*\('
        method_match = re.search(method_sig_pattern, content)
        
        if not method_match:
            LOGGER.debug("Method not found: %s", method_name)
            return javadoc_info
        
        # Look backwards from the method to find its Javadoc
        # Get the content before the method signature
        content_before_method = content[:method_match.start()]
        
        # Find the last Javadoc comment before this method
        # Must not have another method/class declaration between the Javadoc and our method
        javadoc_pattern = r'/\*\*(.*?)\*/'
        all_javadocs = list(re.finditer(javadoc_pattern, content_before_method, re.DOTALL))
        
        if not all_javadocs:
            LOGGER.debug("No Javadoc found for method: %s", method_name)
            return javadoc_info
        
        # Get the last Javadoc before the method
        last_javadoc = all_javadocs[-1]
        javadoc_raw = last_javadoc.group(0)
        
        # Verify there's no other method declaration between this Javadoc and our method
        between_content = content_before_method[last_javadoc.end():]
        # If there's another method declaration between, this Javadoc is not for our method
        if re.search(r'(?:public|private|protected)\s+[\w<>\[\],\s]+\s+\w+\s*\(', between_content):
            LOGGER.debug("Javadoc belongs to another method, not %s", method_name)
            return javadoc_info
        
        # Also check it's not a class-level Javadoc (followed by class declaration)
        if re.search(r'(?:public|private|protected)?\s*(?:abstract|final)?\s*class\s+', between_content):
            LOGGER.debug("Javadoc is class-level, not method-level for %s", method_name)
            return javadoc_info
        
        # Clean the Javadoc: remove /** */ and leading asterisks
        javadoc_clean = re.sub(r'^/\*\*\s*', '', javadoc_raw)
        javadoc_clean = re.sub(r'\s*\*/$', '', javadoc_clean)
        javadoc_clean = re.sub(r'^\s*\*\s?', '', javadoc_clean, flags=re.MULTILINE)
        
        # Split into main description and tags
        parts = re.split(r'(?=@\w+)', javadoc_clean, maxsplit=1)
        
        if parts:
            javadoc_info["description"] = parts[0].strip()
        
        # Parse tags
        if len(parts) > 1:
            tags_section = parts[1]
            
            # Parse @param tags
            param_matches = re.findall(r'@param\s+(\w+)\s+(.*?)(?=@|\Z)', tags_section, re.DOTALL)
            for param_name, param_desc in param_matches:
                javadoc_info["params"][param_name] = param_desc.strip()
            
            # Parse @return tag
            return_match = re.search(r'@returns?\s+(.*?)(?=@|\Z)', tags_section, re.DOTALL)
            if return_match:
                javadoc_info["returns"] = return_match.group(1).strip()
            
            # Parse @throws/@exception tags
            throws_matches = re.findall(r'@(?:throws|exception)\s+(\w+)\s+(.*?)(?=@|\Z)', tags_section, re.DOTALL)
            for exc_type, exc_desc in throws_matches:
                javadoc_info["throws"].append({
                    "type": exc_type,
                    "description": exc_desc.strip()
                })
        
        if javadoc_info["description"]:
            LOGGER.info("Extracted Javadoc for %s: %s...", method_name, javadoc_info["description"][:60])
        return javadoc_info

    def _extract_inline_comments(self, code: str) -> list[str]:
        """Extract meaningful inline comments from Java code.
        
        Filters out TODOs, FIXMEs, debug comments, and code artifacts.
        Returns up to 20 significant comments that describe business logic.
        """
        comments: list[str] = []
        
        # Skip patterns for irrelevant comments
        skip_patterns = [
            r'^\s*$',  # Empty
            r'^TODO',
            r'^FIXME',
            r'^XXX',
            r'^HACK',
            r'^DEBUG',
            r'^\d+',  # Just numbers
            r'^[\{\}\(\)\;]',  # Code artifacts
            r'^import\s',
            r'^package\s',
            r'^\*\s*@',  # Javadoc tags
            r'auto-generated',
            r'generated by',
            r'non-javadoc',
            r'\(non-Javadoc\)',
        ]
        
        skip_regex = re.compile('|'.join(skip_patterns), re.IGNORECASE)
        
        # Extract single-line comments //
        single_line = re.findall(r'//\s*(.+?)$', code, re.MULTILINE)
        for comment in single_line:
            clean = comment.strip()
            if len(clean) > 10 and not skip_regex.search(clean):
                comments.append(clean)
        
        # Extract multi-line comments /* */ (but not Javadoc /** */)
        multi_line = re.findall(r'/\*(?!\*)([^*]|\*(?!/))*\*/', code, re.DOTALL)
        for match in multi_line:
            if isinstance(match, tuple):
                match = match[0] if match else ''
            # Clean up the comment
            clean = re.sub(r'^\s*\*\s?', '', str(match), flags=re.MULTILINE)
            clean = clean.strip()
            if len(clean) > 10 and not skip_regex.search(clean):
                # Split into lines and take meaningful ones
                for line in clean.split('\n'):
                    line = line.strip()
                    if len(line) > 10 and not skip_regex.search(line):
                        comments.append(line)
        
        # Deduplicate and limit
        seen = set()
        unique_comments = []
        for c in comments:
            if c not in seen:
                seen.add(c)
                unique_comments.append(c)
        
        return unique_comments[:20]  # Limit to 20 comments

    def _collect_dto_sources(
        self,
        method: MethodSignature,
        manager_path: str | None,
        imports: list[str],
    ) -> dict[str, dict]:
        """Collect source code and field info for all DTOs referenced in the method."""
        dto_sources: dict[str, dict] = {}
        already_processed: set[str] = set()
        
        # Get base directory from manager path
        base_dir = None
        if manager_path:
            base_dir = Path(manager_path).parent.parent.parent.parent.parent  # Go up to src/main/java
        
        # Collect DTOs from parameters
        for param in method.parameters:
            if param.dto and param.dto.file_path:
                dto_info = self._read_dto_full(param.dto.file_path, param.dto.name)
                if dto_info:
                    dto_sources[param.dto.name] = dto_info
                    already_processed.add(param.dto.name)
                    
                    # Use already parsed fields to find nested DTOs
                    if param.dto.fields and base_dir:
                        for field in param.dto.fields:
                            field_types = self._extract_all_types_from_generic(field.type_hint, field.name)
                            for ft in field_types:
                                if ft not in already_processed and ft not in self._get_skip_types():
                                    nested_dto = self._find_and_read_dto(ft, base_dir, imports)
                                    if nested_dto:
                                        dto_sources[ft] = nested_dto
                                        already_processed.add(ft)
                                        LOGGER.debug("Found nested DTO from field: %s", ft)
                                        # Recursively find deeper nested DTOs
                                        if base_dir:
                                            deeper = self._extract_nested_dtos(
                                                nested_dto.get("content", ""),
                                                base_dir,
                                                imports,
                                                already_processed,
                                                current_depth=1,
                                                max_depth=3,
                                            )
                                            dto_sources.update(deeper)
                    
                    # Also extract from content as fallback
                    if base_dir:
                        nested = self._extract_nested_dtos(
                            dto_info.get("content", ""),
                            base_dir,
                            imports,
                            already_processed,
                        )
                        dto_sources.update(nested)
            elif param.type_hint and base_dir:
                # Try to find DTO by type name
                clean_type = self._clean_type_name(param.type_hint)
                if clean_type and clean_type not in self._get_skip_types() and clean_type not in already_processed:
                    dto_info = self._find_and_read_dto(clean_type, base_dir, imports)
                    if dto_info:
                        dto_sources[clean_type] = dto_info
                        already_processed.add(clean_type)
                        # Also search for nested DTOs in this one
                        if base_dir:
                            nested = self._extract_nested_dtos(
                                dto_info.get("content", ""),
                                base_dir,
                                imports,
                                already_processed,
                            )
                            dto_sources.update(nested)

        # Try to find return type DTO
        if method.return_type and base_dir:
            return_type = self._clean_type_name(method.return_type)
            if return_type and return_type[0].isupper() and return_type not in self._get_skip_types():
                if return_type not in already_processed:
                    dto_info = self._find_and_read_dto(return_type, base_dir, imports)
                    if dto_info:
                        dto_sources[return_type] = dto_info
                        already_processed.add(return_type)
                        # Search for nested DTOs in return type
                        nested = self._extract_nested_dtos(
                            dto_info.get("content", ""),
                            base_dir,
                            imports,
                            already_processed,
                        )
                        dto_sources.update(nested)

        LOGGER.info("Collected %d DTOs for method analysis", len(dto_sources))
        return dto_sources

    def _read_dto_full(self, file_path: str, dto_name: str) -> dict | None:
        """Read DTO source code and extract field information."""
        try:
            path = Path(file_path)
            if not path.exists():
                LOGGER.debug("DTO file not found: %s", file_path)
                return None
            
            content = path.read_text(encoding="utf-8", errors="ignore")
            fields = self._extract_dto_fields_detailed(content)
            
            return {
                "name": dto_name,
                "file_path": file_path,
                "content": content[:2500] if len(content) > 2500 else content,
                "fields": fields,
            }
        except Exception as e:
            LOGGER.warning("Error reading DTO file %s: %s", file_path, e)
            return None

    def _find_and_read_dto(
        self,
        type_name: str,
        base_dir: Path,
        imports: list[str],
    ) -> dict | None:
        """Find and read a DTO by its type name using imports."""
        clean_name = self._clean_type_name(type_name)
        if not clean_name:
            return None
        
        # Check cache
        cache_key = f"{base_dir}:{clean_name}"
        if cache_key in self._dto_cache:
            cached = self._dto_cache[cache_key]
            if cached:
                return self._read_dto_full(cached, clean_name)
            return None
        
        # Try to find from imports
        for imp in imports:
            if imp.endswith(f".{clean_name}"):
                # Convert import to file path
                relative_path = imp.replace(".", "/") + ".java"
                # Try multiple base directories (handle multi-module projects)
                search_bases = [
                    base_dir,
                    base_dir.parent,
                    base_dir.parent.parent,  # Go up further for multi-module
                ]
                # Also try to find src/main/java roots
                for parent in base_dir.parents:
                    if (parent / "src" / "main" / "java").exists():
                        search_bases.append(parent / "src" / "main" / "java")
                    if parent.name == "src":
                        break
                
                for src_base in search_bases:
                    file_path = src_base / relative_path
                    if file_path.exists():
                        self._dto_cache[cache_key] = str(file_path)
                        return self._read_dto_full(str(file_path), clean_name)
        
        # Try glob search as fallback within the project
        for file_path in base_dir.rglob(f"{clean_name}.java"):
            self._dto_cache[cache_key] = str(file_path)
            return self._read_dto_full(str(file_path), clean_name)
        
        # Also try from project root (go up until we find pom.xml or src)
        project_root = base_dir
        for parent in base_dir.parents:
            if (parent / "pom.xml").exists() or (parent / "build.gradle").exists():
                project_root = parent
                break
        
        if project_root != base_dir:
            for file_path in project_root.rglob(f"{clean_name}.java"):
                self._dto_cache[cache_key] = str(file_path)
                return self._read_dto_full(str(file_path), clean_name)
        
        self._dto_cache[cache_key] = ""
        return None

    def _extract_nested_dtos(
        self,
        dto_content: str,
        base_dir: Path,
        imports: list[str],
        already_processed: set[str] | None = None,
        current_depth: int = 0,
        max_depth: int = 3,
    ) -> dict[str, dict]:
        """Extract nested DTO references from a DTO source recursively.
        
        Args:
            dto_content: Source code of the DTO
            base_dir: Base directory for searching DTO files
            imports: List of import statements from the parent file
            already_processed: Set of DTO names already processed (prevents infinite loops)
            current_depth: Current recursion depth
            max_depth: Maximum recursion depth (default 3)
        """
        if current_depth >= max_depth:
            LOGGER.debug("Max DTO depth reached (%d), stopping recursion", max_depth)
            return {}
        
        if already_processed is None:
            already_processed = set()
        
        nested: dict[str, dict] = {}
        
        # Extract imports from this DTO file
        dto_imports = IMPORT_PATTERN.findall(dto_content)
        all_imports = list(set(imports + dto_imports))
        
        # Extract field types that might be DTOs
        for match in FIELD_PATTERN.finditer(dto_content):
            field_type = match.group("type").strip()
            field_name = match.group("name").strip()
            
            # Extract all potential DTO types (including from generics like List<MyDTO>)
            # Also try to infer from field name for legacy code without generics
            potential_types = self._extract_all_types_from_generic(field_type, field_name)
            
            for clean_type in potential_types:
                # Skip primitive types and common Java types
                if not clean_type or clean_type in self._get_skip_types():
                    continue
                
                # Skip if already processed (prevents infinite recursion)
                if clean_type in already_processed or clean_type in nested:
                    continue
                
                already_processed.add(clean_type)
                
                # Try to read nested DTO
                dto_info = self._find_and_read_dto(clean_type, base_dir, all_imports)
                if dto_info:
                    nested[clean_type] = dto_info
                    LOGGER.debug("Found nested DTO: %s at depth %d", clean_type, current_depth)
                    
                    # RECURSE into this DTO to find more nested DTOs
                    deeper_nested = self._extract_nested_dtos(
                        dto_info.get("content", ""),
                        base_dir,
                        all_imports,
                        already_processed,
                        current_depth + 1,
                        max_depth,
                    )
                    nested.update(deeper_nested)
        
        return nested

    def _extract_dto_fields_detailed(self, dto_content: str) -> list[dict]:
        """Extract detailed field information from DTO source code."""
        fields = []
        lines = dto_content.split('\n')
        
        current_javadoc = ""
        for i, line in enumerate(lines):
            # Capture javadoc comments
            if '/**' in line:
                current_javadoc = ""
                j = i
                while j < len(lines) and '*/' not in lines[j]:
                    current_javadoc += lines[j] + "\n"
                    j += 1
                if j < len(lines):
                    current_javadoc += lines[j]
            
            # Match field declarations
            match = FIELD_PATTERN.search(line)
            if match:
                field_type = match.group("type").strip()
                field_name = match.group("name").strip()
                
                # Extract description from javadoc
                description = ""
                if current_javadoc:
                    doc_match = re.search(r'\*\s*(.+?)(?:\n|\*/)', current_javadoc)
                    if doc_match:
                        description = doc_match.group(1).strip()
                
                # Check for validation annotations in surrounding lines
                validations = []
                context_start = max(0, i - 3)
                context_lines = "\n".join(lines[context_start:i+1])
                
                if '@NotNull' in context_lines or '@NotEmpty' in context_lines:
                    validations.append("Requerido")
                if '@NotBlank' in context_lines:
                    validations.append("No puede estar vacío")
                size_match = re.search(r'@Size\(([^)]+)\)', context_lines)
                if size_match:
                    validations.append(f"Tamaño: {size_match.group(1)}")
                pattern_match = re.search(r'@Pattern\(([^)]+)\)', context_lines)
                if pattern_match:
                    validations.append(f"Patrón: {pattern_match.group(1)}")
                
                fields.append({
                    "name": field_name,
                    "type": field_type,
                    "description": description,
                    "validations": validations,
                    "required": len(validations) > 0 and "Requerido" in validations,
                })
                current_javadoc = ""
        
        return fields

    def _clean_type_name(self, type_name: str) -> str:
        """Clean a type name removing generics, arrays, and modifiers.
        
        Returns the first/primary type found. For extracting all types
        from generics, use _extract_all_types_from_generic instead.
        """
        if not type_name:
            return ""
        # Remove 'public', 'private', etc
        type_name = re.sub(r'^(public|private|protected|static|final)\s+', '', type_name.strip())
        # Get base type from generics: List<MyDTO> -> MyDTO
        # Handle nested generics like ArrayList<List<MyDTO>> -> MyDTO
        while '<' in type_name:
            generic_match = re.search(r'<([^<>]+)>', type_name)
            if generic_match:
                inner = generic_match.group(1)
                # Handle Map<K,V> - take the value type
                if ',' in inner:
                    inner = inner.split(',')[-1].strip()
                type_name = inner
            else:
                # Nested generics - extract innermost
                break
        # Remove array brackets
        type_name = type_name.replace("[]", "").strip()
        return type_name

    def _extract_all_types_from_generic(self, type_name: str, field_name: str = "") -> list[str]:
        """Extract all potential DTO type names from a generic type declaration.
        
        Also attempts to infer DTO types from field names for legacy code
        that uses raw types like ArrayList without generics.
        
        Examples:
            - "ProPropuestaDocumentoVO" -> ["ProPropuestaDocumentoVO"]
            - "List<ProPropuestaDocumentoVO>" -> ["ProPropuestaDocumentoVO"]
            - "Map<String, ProDocumentoVO>" -> ["ProDocumentoVO"]
            - "ArrayList<List<MyDTO>>" -> ["MyDTO"]
            - "ArrayList" with field "listadoPropuestaVO" -> ["PropuestaVO"]
        """
        types: list[str] = []
        
        if not type_name:
            return types
        
        # Clean up the type name
        clean = type_name.strip()
        clean = re.sub(r'^(public|private|protected|static|final)\s+', '', clean)
        clean = clean.replace("[]", "")
        
        # If no generics, return the base type if it looks like a DTO
        if '<' not in clean:
            base_type = clean.split()[-1] if ' ' in clean else clean
            if base_type and len(base_type) > 1 and base_type[0].isupper():
                # If it's a collection without generic, try to infer from field name
                if base_type in {'ArrayList', 'List', 'Set', 'Collection', 'HashSet'}:
                    inferred = self._infer_dto_from_field_name(field_name)
                    if inferred:
                        types.append(inferred)
                elif base_type not in self._get_skip_types():
                    types.append(base_type)
            return types
        
        # Extract all types inside generics (handles nested generics)
        # Find all word sequences that look like class names (start with uppercase)
        # Common DTO patterns: ends with VO, TO, DTO, or contains them
        dto_pattern = re.compile(r'\b([A-Z][a-zA-Z0-9]*(?:VO|TO|DTO|Entity|Bean)?)\b')
        inner_types = dto_pattern.findall(clean)
        
        for t in inner_types:
            if t not in self._get_skip_types() and t not in types:
                types.append(t)
        
        return types

    def _infer_dto_from_field_name(self, field_name: str) -> str | None:
        """Infer DTO type from field name patterns common in legacy Java code.
        
        Examples:
            - "listadoProPropuestaDocumentoVO" -> "ProPropuestaDocumentoVO"
            - "listPropuestaTO" -> "PropuestaTO"
            - "propuestasVO" -> "PropuestaVO" (singular)
        """
        if not field_name:
            return None
        
        # Pattern: listado<DtoName> or lista<DtoName> or list<DtoName>
        patterns = [
            r'listado([A-Z][a-zA-Z0-9]*(?:VO|TO|DTO))',  # listadoProPropuestaVO
            r'lista([A-Z][a-zA-Z0-9]*(?:VO|TO|DTO))',     # listaPropuestaVO
            r'list([A-Z][a-zA-Z0-9]*(?:VO|TO|DTO))',      # listPropuestaVO
            r'([A-Z][a-zA-Z0-9]*(?:VO|TO|DTO))s$',        # PropuestasVO -> PropuestaVO
        ]
        
        for pattern in patterns:
            match = re.search(pattern, field_name)
            if match:
                dto_name = match.group(1)
                # Handle plural: remove trailing 's' before VO/TO/DTO
                if dto_name.endswith('sVO'):
                    dto_name = dto_name[:-3] + 'VO'
                elif dto_name.endswith('sTO'):
                    dto_name = dto_name[:-3] + 'TO'
                elif dto_name.endswith('sDTO'):
                    dto_name = dto_name[:-4] + 'DTO'
                return dto_name
        
        return None

    def _get_skip_types(self) -> set[str]:
        """Return set of types to skip when looking for DTOs."""
        return {
            'String', 'Integer', 'Long', 'Double', 'Float', 'Boolean', 'Byte', 'Short',
            'int', 'long', 'double', 'float', 'boolean', 'byte', 'short', 'char',
            'Date', 'LocalDate', 'LocalDateTime', 'Timestamp', 'BigDecimal', 'BigInteger',
            'List', 'ArrayList', 'Set', 'HashSet', 'Map', 'HashMap', 'Collection',
            'Object', 'Class', 'Void', 'void', 'Calendar', 'Connection', 'Exception'
        }

    def _read_manager_method(self, manager_path: str, method_name: str) -> str:
        """Read the manager class and extract relevant method implementation with Javadoc."""
        try:
            path = Path(manager_path)
            if not path.exists():
                LOGGER.warning("Manager file not found: %s", manager_path)
                return ""
            
            content = path.read_text(encoding="utf-8", errors="ignore")
            
            # Extract Javadoc for the method first
            javadoc = self._extract_javadoc_for_method(content, method_name)
            
            # Try to extract the specific method
            method_code = self._extract_method_code(content, method_name)
            
            # Prepend Javadoc as a formatted comment if available
            javadoc_section = ""
            if javadoc["description"]:
                javadoc_section = f"/* DOCUMENTACIÓN JAVADOC DEL DESARROLLADOR:\n * {javadoc['description']}\n"
                if javadoc["params"]:
                    for p_name, p_desc in javadoc["params"].items():
                        javadoc_section += f" * @param {p_name} {p_desc}\n"
                if javadoc["returns"]:
                    javadoc_section += f" * @return {javadoc['returns']}\n"
                for t in javadoc["throws"]:
                    javadoc_section += f" * @throws {t['type']} {t['description']}\n"
                javadoc_section += " */\n"
            
            if method_code:
                return javadoc_section + method_code
            
            # Return a portion of the file if method not found
            return content[:6000]
        except Exception as e:
            LOGGER.warning("Error reading manager: %s", e)
            return ""

    def _extract_method_code(self, content: str, method_name: str) -> str:
        """Extract a specific method from Java source code."""
        import re
        
        # Pattern to find method definition
        # Handles public/private/protected, return types, and method body
        pattern = rf'((?:public|private|protected)\s+[\w<>\[\],\s]+\s+{method_name}\s*\([^)]*\)[^{{]*\{{)'
        
        match = re.search(pattern, content)
        if not match:
            return ""
        
        start = match.start()
        
        # Find matching closing brace
        brace_count = 0
        in_method = False
        end = start
        
        for i, char in enumerate(content[start:], start):
            if char == '{':
                brace_count += 1
                in_method = True
            elif char == '}':
                brace_count -= 1
                if in_method and brace_count == 0:
                    end = i + 1
                    break
        
        method_code = content[start:end]
        
        # Limit size
        if len(method_code) > 4000:
            method_code = method_code[:4000] + "\n// ... (truncated)"
        
        return method_code

    def _build_analysis_prompt(
        self,
        method: MethodSignature,
        interface_name: str,
        manager_code: str,
        dto_sources: dict[str, dict],
        manager_javadoc: dict | None = None,
        inline_comments: list[str] | None = None,
    ) -> str:
        """Build the prompt for LLM analysis with enriched DTO information and Javadoc."""
        
        # Build Javadoc section if available
        javadoc_section = ""
        if manager_javadoc and manager_javadoc.get("description"):
            javadoc_section = f"""
## 📖 Documentación Javadoc del Desarrollador

**Descripción original del desarrollador:**
> {manager_javadoc.get('description', 'No disponible')}

"""
            if manager_javadoc.get("params"):
                javadoc_section += "**Parámetros documentados:**\n"
                for p_name, p_desc in manager_javadoc["params"].items():
                    javadoc_section += f"- `{p_name}`: {p_desc}\n"
                javadoc_section += "\n"
            
            if manager_javadoc.get("returns"):
                javadoc_section += f"**Retorno documentado:** {manager_javadoc['returns']}\n\n"
            
            if manager_javadoc.get("throws"):
                javadoc_section += "**Excepciones documentadas:**\n"
                for t in manager_javadoc["throws"]:
                    javadoc_section += f"- `{t['type']}`: {t['description']}\n"
                javadoc_section += "\n"
        
        # Build inline comments section if available
        comments_section = ""
        if inline_comments:
            comments_section = "\n## 💬 Comentarios del Código (contexto del desarrollador)\n\n"
            for i, comment in enumerate(inline_comments[:15], 1):
                comments_section += f"{i}. {comment}\n"
            comments_section += "\n"
        
        # Build detailed parameter description
        params_desc_parts = []
        for p in method.parameters:
            param_line = f"  - **{p.name}**: `{p.type_hint}`"
            if p.dto and p.dto.fields:
                fields_str = ", ".join([f"{f.name}({f.type_hint})" for f in p.dto.fields[:10]])
                param_line += f"\n    Campos del DTO: {fields_str}"
            params_desc_parts.append(param_line)
        params_desc = "\n".join(params_desc_parts) if params_desc_parts else "  (sin parámetros)"

        # Build DTO sections with detailed field information
        dto_sections = ""
        if dto_sources:
            dto_parts = []
            for dto_name, dto_info in list(dto_sources.items())[:6]:  # Limit to 6 DTOs
                fields = dto_info.get("fields", [])
                if fields:
                    fields_table = "\n".join([
                        f"    | `{f['name']}` | `{f['type']}` | {f.get('required', False)} | {f.get('description', '')} | {', '.join(f.get('validations', []))} |"
                        for f in fields[:12]  # Limit fields shown
                    ])
                    fields_header = "    | Campo | Tipo | Requerido | Descripción | Validaciones |\n    |-------|------|-----------|-------------|--------------|"
                    fields_section = f"{fields_header}\n{fields_table}"
                else:
                    fields_section = "    (sin campos detectados)"
                
                dto_content = dto_info.get("content", "")[:1200]
                
                dto_parts.append(f"""
### DTO: {dto_name}
**Archivo:** `{dto_info.get('file_path', 'N/A')}`

**Campos:**
{fields_section}

**Código fuente:**
```java
{dto_content}
```
""")
            dto_sections = "\n".join(dto_parts)

        prompt = f"""Eres un experto en Jakarta EE y documentación técnica. Analiza el siguiente método EJB y genera documentación funcional detallada EN ESPAÑOL.

## Información del Método

**Interface:** {interface_name}
**Método:** {method.name}
**Tipo de retorno:** {method.return_type}

### Parámetros:
{params_desc}

{javadoc_section}{comments_section}## Código del Manager (implementación de negocio)
```java
{manager_code if manager_code else "// Código del manager no disponible"}
```

## Definición de DTOs (Transfer Objects)
{dto_sections if dto_sections else "_No se encontraron DTOs adicionales para este método_"}

## Instrucciones de Análisis

Analiza el código del Manager, los DTOs, **el Javadoc y los comentarios del desarrollador** para generar documentación funcional COMPLETA. 

**IMPORTANTE - PRIORIDADES DE INFORMACIÓN:**
1. **JAVADOC del desarrollador** - Es la documentación OFICIAL, úsala como BASE
2. **Comentarios inline** - Contexto adicional del desarrollador sobre la lógica
3. **Análisis del código** - Para complementar y validar la documentación
4. **Estructura de DTOs** - Para documentar campos de entrada/salida

**Sobre los campos de entrada:**
- Documenta TODOS los campos de cada DTO de entrada
- USA las descripciones del @param del Javadoc si existen
- Para cada campo indica su tipo, si es requerido, y su propósito

Genera un JSON con el siguiente formato:

{{
  "functional_description": "Descripción funcional detallada. COMBINA: la descripción del Javadoc (si existe) + los comentarios del código + el análisis del Manager. Explica: QUÉ hace, CUÁNDO se usa, FLUJO de operaciones, y PROPÓSITO de negocio.",
  
  "input_attributes": [
    {{
      "name": "nombre_campo",
      "type": "tipo_java",
      "required": true/false,
      "description": "USA el @param del Javadoc si existe, complementa con análisis",
      "validations": ["validación1", "validación2"],
      "example": "ejemplo de valor válido"
    }}
  ],
  
  "output_attributes": [
    {{
      "name": "nombre_campo", 
      "type": "tipo_java",
      "description": "USA el @return del Javadoc si existe, complementa con análisis",
      "possible_values": ["valor1", "valor2"] 
    }}
  ],
  
  "error_messages": [
    {{
      "code": "código_excepción",
      "message": "mensaje de error típico",
      "cause": "USA @throws del Javadoc para documentar las causas REALES",
      "solution": "cómo resolver o prevenir el error"
    }}
  ],
  
  "consumption_tips": [
    "Tip práctico 1 - basado en comentarios y código",
    "Tip práctico 2 sobre validaciones necesarias",
    "Tip práctico 3 sobre casos especiales o edge cases"
  ],
  
  "business_rules": [
    "Regla de negocio 1 - extraída del Javadoc o comentarios",
    "Regla de negocio 2 - identificada en el código"
  ]
}}

**REGLAS CRÍTICAS:**
1. **PRIORIZA el Javadoc** - Es la documentación oficial del desarrollador
2. **USA los comentarios inline** - Contienen contexto de negocio importante
3. Los @param describen el PROPÓSITO real de cada parámetro
4. Los @throws indican errores REALES que pueden ocurrir
5. Incluye TODOS los campos de los DTOs en input_attributes
6. Los tips deben ser ESPECÍFICOS basados en código Y comentarios
7. Responde SOLO con JSON válido, sin texto adicional ni markdown"""

        return prompt

    async def _call_llm(self, prompt: str) -> str:
        """Call the configured LLM provider."""
        client = self._get_client()
        
        try:
            if self.settings.llm_provider == "openai":
                response = client.chat.completions.create(
                    model=self.settings.get_model(),
                    messages=[
                        {"role": "system", "content": "Eres un experto en Jakarta EE y documentación técnica. Respondes siempre en JSON válido."},
                        {"role": "user", "content": prompt}
                    ],
                    max_completion_tokens=self.settings.max_tokens,
                    temperature=0.3,
                )
                return response.choices[0].message.content or ""
            else:
                response = client.messages.create(
                    model=self.settings.get_model(),
                    max_tokens=self.settings.max_tokens,
                    messages=[{"role": "user", "content": prompt}],
                )
                return response.content[0].text if response.content else ""
        except Exception as e:
            LOGGER.error("LLM call failed: %s", e)
            raise

    def _parse_analysis(
        self,
        analysis: str,
        method: MethodSignature,
        interface_name: str,
        dto_sources: dict[str, dict],
    ) -> MethodDocumentation:
        """Parse LLM response into MethodDocumentation."""
        import json
        
        # Clean up the response - remove markdown code blocks if present
        clean_analysis = analysis.strip()
        if clean_analysis.startswith("```"):
            lines = clean_analysis.split("\n")
            # Find the closing ```
            end_idx = len(lines) - 1
            for i in range(len(lines) - 1, 0, -1):
                if lines[i].strip() == "```":
                    end_idx = i
                    break
            clean_analysis = "\n".join(lines[1:end_idx])
        
        try:
            data = json.loads(clean_analysis)
        except json.JSONDecodeError as e:
            LOGGER.warning("Failed to parse LLM response as JSON: %s", e)
            LOGGER.debug("Raw response: %s", analysis[:500])
            # Create fallback documentation
            data = self._create_fallback_analysis(method, dto_sources)

        params_str = ", ".join([
            f"{p.type_hint} {p.name}" for p in method.parameters
        ])
        raw_signature = f"{method.return_type} {method.name}({params_str})"

        # Build DTO details for the documentation
        dto_details = []
        for dto_name, dto_info in dto_sources.items():
            dto_details.append({
                "name": dto_name,
                "file_path": dto_info.get("file_path", ""),
                "fields": dto_info.get("fields", []),
            })

        return MethodDocumentation(
            method_name=method.name,
            interface_name=interface_name,
            functional_description=data.get("functional_description", "Documentación no disponible"),
            input_attributes=data.get("input_attributes", []),
            output_attributes=data.get("output_attributes", []),
            error_messages=data.get("error_messages", []),
            consumption_tips=data.get("consumption_tips", []),
            raw_signature=raw_signature,
            business_rules=data.get("business_rules", []),
            dto_details=dto_details,
        )

    def _create_fallback_analysis(self, method: MethodSignature, dto_sources: dict[str, dict]) -> dict:
        """Create fallback analysis when LLM parsing fails."""
        input_attrs = []
        
        # Build input attributes from DTOs
        for p in method.parameters:
            dto_info = dto_sources.get(self._clean_type_name(p.type_hint), {})
            fields = dto_info.get("fields", [])
            
            if fields:
                # Add each field from the DTO
                for field in fields:
                    input_attrs.append({
                        "name": f"{p.name}.{field['name']}",
                        "type": field['type'],
                        "required": field.get('required', False),
                        "description": field.get('description', f"Campo del DTO {p.type_hint}"),
                        "validations": field.get('validations', []),
                        "example": ""
                    })
            else:
                input_attrs.append({
                    "name": p.name,
                    "type": p.type_hint,
                    "required": True,
                    "description": f"Parámetro de tipo {p.type_hint}",
                    "validations": [],
                    "example": ""
                })
        
        return {
            "functional_description": f"Método {method.name} que recibe {len(method.parameters)} parámetro(s) y retorna {method.return_type}. Revisar implementación del Manager para detalles de lógica de negocio.",
            "input_attributes": input_attrs,
            "output_attributes": [{"name": "result", "type": method.return_type, "description": f"Resultado de tipo {method.return_type}"}],
            "error_messages": [
                {"code": "ApplicationException", "message": "Error de aplicación", "cause": "Error en la lógica de negocio", "solution": "Verificar parámetros de entrada"},
                {"code": "EJBException", "message": "Error del contenedor EJB", "cause": "Error en la capa de servicios", "solution": "Verificar configuración del servidor"}
            ],
            "consumption_tips": [
                "Verificar que todos los parámetros requeridos estén presentes",
                "Manejar las excepciones ApplicationException apropiadamente",
                "Considerar el uso de transacciones si el método modifica datos"
            ],
            "business_rules": []
        }
