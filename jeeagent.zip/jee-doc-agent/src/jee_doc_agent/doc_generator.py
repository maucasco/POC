"""Documentation generator that produces Markdown output."""
from __future__ import annotations

import logging
import re
from datetime import datetime
from pathlib import Path
from typing import List

from jee_doc_agent.config import Settings
from jee_doc_agent.models import (
    EjbContract,
    InterfaceDocumentation,
    MethodDocumentation,
    MethodSignature,
    ProjectScanResponse,
)
from jee_doc_agent.llm_analyzer import LLMAnalyzer
from jee_doc_agent.mcp_client import MCPClient

LOGGER = logging.getLogger(__name__)


class DocumentationGenerator:
    """Generates functional documentation for JEE projects."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.mcp_client = MCPClient(settings)
        self.llm_analyzer = LLMAnalyzer(settings)

    async def generate_project_documentation(
        self,
        project_path: str,
        output_path: Path | None = None,
        method_filter: str | None = None,
    ) -> List[InterfaceDocumentation]:
        """Generate complete documentation for a JEE project."""
        LOGGER.info("Generating documentation for project: %s", project_path)

        # Step 1: Scan project using MCP server
        scan_result = await self.mcp_client.scan_project(project_path, detailed_scan=False)
        LOGGER.info("Found %d contracts", len(scan_result.contracts))

        # Step 2: Generate documentation for each contract
        docs: List[InterfaceDocumentation] = []
        for contract in scan_result.contracts:
            interface_doc = await self._document_interface(contract, method_filter)
            docs.append(interface_doc)

        # Step 3: Write output files (with merge support)
        output_dir = output_path or self.settings.output_dir
        output_dir.mkdir(parents=True, exist_ok=True)

        for doc in docs:
            filename = f"{doc.interface_name}_documentation.md"
            filepath = output_dir / filename
            
            if filepath.exists():
                # Merge new methods into existing documentation
                existing_content = filepath.read_text(encoding="utf-8")
                merged_content = self._merge_documentation(existing_content, doc)
                filepath.write_text(merged_content, encoding="utf-8")
                LOGGER.info("Merged documentation into: %s", filepath)
            else:
                # Write new file
                markdown = self._render_markdown(doc)
                filepath.write_text(markdown, encoding="utf-8")
                LOGGER.info("Generated documentation: %s", filepath)

        return docs

    async def generate_method_documentation(
        self,
        project_path: str,
        interface_name: str,
        method_name: str,
    ) -> MethodDocumentation | None:
        """Generate documentation for a specific method."""
        LOGGER.info("Generating documentation for %s.%s", interface_name, method_name)

        # Scan project
        scan_result = await self.mcp_client.scan_project(project_path)

        # Find the interface
        contract = next(
            (c for c in scan_result.contracts if c.interface_name == interface_name),
            None,
        )
        if not contract:
            LOGGER.error("Interface not found: %s", interface_name)
            return None

        # Find the method
        method = next(
            (m for m in contract.methods if m.name == method_name),
            None,
        )
        if not method:
            LOGGER.error("Method not found: %s.%s", interface_name, method_name)
            return None

        # Generate documentation
        return await self.llm_analyzer.analyze_method(
            method,
            interface_name,
            contract.related_manager_path,
        )

    async def _document_interface(
        self,
        contract: EjbContract,
        method_filter: str | None = None,
    ) -> InterfaceDocumentation:
        """Generate documentation for a single EJB interface."""
        LOGGER.info("Documenting interface: %s", contract.interface_name)

        methods_to_document = contract.methods
        if method_filter:
            methods_to_document = [
                m for m in contract.methods
                if method_filter.lower() in m.name.lower()
            ]

        method_docs: List[MethodDocumentation] = []
        for method in methods_to_document:
            try:
                doc = await self.llm_analyzer.analyze_method(
                    method,
                    contract.interface_name,
                    contract.related_manager_path,
                )
                method_docs.append(doc)
            except Exception as e:
                LOGGER.error("Failed to document method %s: %s", method.name, e)

        return InterfaceDocumentation(
            interface_name=contract.interface_name,
            annotation=contract.annotation,
            file_path=contract.file_path,
            manager_path=contract.related_manager_path,
            methods=method_docs,
            generated_at=datetime.now().isoformat(),
        )

    def _render_markdown(self, doc: InterfaceDocumentation) -> str:
        """Render InterfaceDocumentation to Markdown format."""
        lines: List[str] = []

        # Header
        lines.append(f"# {doc.interface_name}")
        lines.append("")
        lines.append(f"**Anotación:** `{doc.annotation}`")
        lines.append(f"**Archivo fuente:** `{doc.file_path}`")
        if doc.manager_path:
            lines.append(f"**Manager:** `{doc.manager_path}`")
        lines.append(f"**Generado:** {doc.generated_at}")
        lines.append("")
        lines.append("---")
        lines.append("")

        # Table of contents
        lines.append("## Índice de Métodos")
        lines.append("")
        for method in doc.methods:
            anchor = method.method_name.lower().replace(" ", "-")
            lines.append(f"- [{method.method_name}](#{anchor})")
        lines.append("")
        lines.append("---")
        lines.append("")

        # Method documentation
        for method in doc.methods:
            lines.extend(self._render_method_markdown(method))
            lines.append("")
            lines.append("---")
            lines.append("")

        return "\n".join(lines)

    def _render_method_markdown(self, method: MethodDocumentation) -> List[str]:
        """Render a single method documentation to Markdown."""
        lines: List[str] = []

        # Method header
        lines.append(f"## {method.method_name}")
        lines.append("")
        lines.append("### Firma del Método")
        lines.append("")
        lines.append(f"```java")
        lines.append(method.raw_signature)
        lines.append("```")
        lines.append("")

        # Functional description
        lines.append("### Descripción Funcional")
        lines.append("")
        lines.append(method.functional_description)
        lines.append("")

        # Business rules section
        if method.business_rules:
            lines.append("### Reglas de Negocio")
            lines.append("")
            for i, rule in enumerate(method.business_rules, 1):
                lines.append(f"{i}. {rule}")
            lines.append("")

        # Input attributes table
        if method.input_attributes:
            lines.append("### Atributos de Entrada")
            lines.append("")
            lines.append("| Nombre | Tipo | Requerido | Descripción | Validaciones |")
            lines.append("|--------|------|-----------|-------------|--------------|")
            for attr in method.input_attributes:
                required = "✅" if attr.get("required", True) else "❌"
                name = attr.get("name", "N/A")
                type_hint = attr.get("type", "N/A")
                desc = attr.get("description", "")
                validations = attr.get("validations", [])
                validations_str = ", ".join(validations) if validations else "-"
                lines.append(f"| `{name}` | `{type_hint}` | {required} | {desc} | {validations_str} |")
            lines.append("")

        # DTO Details section
        if method.dto_details:
            lines.append("### Detalle de DTOs")
            lines.append("")
            for dto in method.dto_details:
                dto_name = dto.get("name", "Unknown")
                file_path = dto.get("file_path", "")
                fields = dto.get("fields", [])
                
                lines.append(f"#### {dto_name}")
                if file_path:
                    lines.append(f"*Archivo:* `{file_path}`")
                lines.append("")
                
                if fields:
                    lines.append("| Campo | Tipo | Requerido | Validaciones | Descripción |")
                    lines.append("|-------|------|-----------|--------------|-------------|")
                    for field in fields:
                        f_name = field.get("name", "N/A")
                        f_type = field.get("type", "N/A")
                        f_required = "✅" if field.get("required", False) else "❌"
                        f_validations = ", ".join(field.get("validations", [])) or "-"
                        f_desc = field.get("description", "")
                        lines.append(f"| `{f_name}` | `{f_type}` | {f_required} | {f_validations} | {f_desc} |")
                    lines.append("")
                else:
                    lines.append("_Sin campos identificados_")
                    lines.append("")

        # Output attributes table
        if method.output_attributes:
            lines.append("### Atributos de Salida")
            lines.append("")
            lines.append("| Nombre | Tipo | Descripción |")
            lines.append("|--------|------|-------------|")
            for attr in method.output_attributes:
                name = attr.get("name", "N/A")
                type_hint = attr.get("type", "N/A")
                desc = attr.get("description", "")
                lines.append(f"| `{name}` | `{type_hint}` | {desc} |")
            lines.append("")

        # Error messages table
        if method.error_messages:
            lines.append("### Mapeo de Errores")
            lines.append("")
            lines.append("| Código | Mensaje | Causa | Solución |")
            lines.append("|--------|---------|-------|----------|")
            for err in method.error_messages:
                code = err.get("code", "N/A")
                msg = err.get("message", "")
                cause = err.get("cause", "")
                solution = err.get("solution", "")
                lines.append(f"| `{code}` | {msg} | {cause} | {solution} |")
            lines.append("")

        # Consumption tips
        if method.consumption_tips:
            lines.append("### Tips de Consumo")
            lines.append("")
            for i, tip in enumerate(method.consumption_tips, 1):
                lines.append(f"{i}. {tip}")
            lines.append("")

        return lines

    def _merge_documentation(
        self, existing_content: str, new_doc: InterfaceDocumentation
    ) -> str:
        """Merge new method documentation into existing documentation file.
        
        Args:
            existing_content: Content of the existing markdown file
            new_doc: New documentation with methods to add/update
            
        Returns:
            Merged markdown content
        """
        # Extract existing methods from the markdown
        existing_methods = self._extract_method_names(existing_content)
        
        # Determine which methods need to be added
        methods_to_add = []
        for method in new_doc.methods:
            if method.method_name not in existing_methods:
                methods_to_add.append(method)
                LOGGER.info("Adding new method documentation: %s", method.method_name)
            else:
                LOGGER.info("Method %s already documented, skipping", method.method_name)
        
        if not methods_to_add:
            LOGGER.info("No new methods to add")
            return existing_content
        
        # Find the position to insert new methods (before the last ---)
        # and update the table of contents
        result = self._insert_methods_into_markdown(
            existing_content, methods_to_add, new_doc.interface_name
        )
        
        return result
    
    def _extract_method_names(self, markdown_content: str) -> set[str]:
        """Extract method names from existing markdown documentation.
        
        Args:
            markdown_content: The markdown content to parse
            
        Returns:
            Set of method names found in the documentation
        """
        # Look for ## MethodName patterns (level 2 headers that are method names)
        # Skip headers like "Índice de Métodos", "Descripción Funcional", etc.
        method_headers = re.findall(r'^## ([a-z][a-zA-Z0-9]+)\s*$', markdown_content, re.MULTILINE)
        return set(method_headers)
    
    def _insert_methods_into_markdown(
        self, 
        existing_content: str, 
        methods_to_add: List[MethodDocumentation],
        interface_name: str,
    ) -> str:
        """Insert new method documentation into existing markdown.
        
        Args:
            existing_content: Existing markdown content
            methods_to_add: List of methods to add
            interface_name: Name of the interface
            
        Returns:
            Updated markdown content with new methods
        """
        lines = existing_content.split('\n')
        
        # Find the index of "## Índice de Métodos" section
        toc_start_idx = None
        toc_end_idx = None
        for i, line in enumerate(lines):
            if line.strip() == "## Índice de Métodos":
                toc_start_idx = i
            elif toc_start_idx is not None and line.strip() == "---":
                toc_end_idx = i
                break
        
        # Add new methods to TOC
        if toc_start_idx is not None and toc_end_idx is not None:
            # Insert new TOC entries before the ---
            new_toc_entries = []
            for method in methods_to_add:
                anchor = method.method_name.lower().replace(" ", "-")
                new_toc_entries.append(f"- [{method.method_name}](#{anchor})")
            
            # Insert before the empty line that precedes ---
            insert_idx = toc_end_idx
            # Find last non-empty line in TOC
            for i in range(toc_end_idx - 1, toc_start_idx, -1):
                if lines[i].strip().startswith("- ["):
                    insert_idx = i + 1
                    break
            
            for entry in new_toc_entries:
                lines.insert(insert_idx, entry)
                insert_idx += 1
        
        # Find the last --- in the document to insert new methods before it
        last_separator_idx = None
        for i in range(len(lines) - 1, -1, -1):
            if lines[i].strip() == "---":
                last_separator_idx = i
                break
        
        # Generate markdown for new methods
        new_method_lines = []
        for method in methods_to_add:
            new_method_lines.extend(self._render_method_markdown(method))
            new_method_lines.append("")
            new_method_lines.append("---")
            new_method_lines.append("")
        
        # Insert new methods before the last separator (or at the end)
        if last_separator_idx is not None:
            # Insert before the last ---
            for i, line in enumerate(new_method_lines):
                lines.insert(last_separator_idx + i, line)
        else:
            # Append at the end
            lines.extend(new_method_lines)
        
        # Update the "Generado" timestamp
        result = '\n'.join(lines)
        result = re.sub(
            r'\*\*Generado:\*\* [^\n]+',
            f'**Generado:** {datetime.now().isoformat()}',
            result
        )
        
        return result
