# AdministracionPropuestaFacade

**Anotación:** `@Remote`
**Archivo fuente:** `/data/lucasian/Quickgas/contratacion.negocio/src/main/java/com/gasesdeoccidente/sicg/propuesta/negocio/bean/AdministracionPropuestaFacade.java`
**Manager:** `/data/lucasian/Quickgas/contratacion.negocio/src/main/java/com/gasesdeoccidente/sicg/propuesta/negocio/business/AdministracionPropuestaMngr.java`
**Generado:** 2025-12-29T10:58:35.330079

---

## Índice de Métodos

- [administrarProPlantillaDocumento](#administrarproplantilladocumento)
- [administrarProPlantillaDocumentoVO](#administrarproplantilladocumentovo)
- [administrarProPlantillaParamItem](#administrarproplantillaparamitem)
- [administrarProPlantillaParamItemVO](#administrarproplantillaparamitemvo)
- [administrarProPlantillaTabla](#administrarproplantillatabla)
- [administrarProPlantillaTablaVO](#administrarproplantillatablavo)

---

## administrarProPlantillaDocumento

### Firma del Método

```java
public ArrayList administrarProPlantillaDocumento(ParametrosPlantillaDocumentoTO parametrosPlantillaDocumentoTO, String modo, UserInterfaceTO user)
```

### Descripción Funcional

Método administrarProPlantillaDocumento que recibe 3 parámetro(s) y retorna public ArrayList. Revisar implementación del Manager para detalles de lógica de negocio.

### Atributos de Entrada

| Nombre | Tipo | Requerido | Descripción | Validaciones |
|--------|------|-----------|-------------|--------------|
| `parametrosPlantillaDocumentoTO.proPlantillaDocumentoVO` | `ProPlantillaDocumentoVO` | ❌ | * | - |
| `parametrosPlantillaDocumentoTO.listadoProPlantillaDocumentoVO` | `ArrayList` | ❌ | * | - |
| `parametrosPlantillaDocumentoTO.numeroPagina` | `int` | ❌ |  | - |
| `parametrosPlantillaDocumentoTO.registrosPagina` | `int` | ❌ |  | - |
| `modo` | `String` | ✅ | Parámetro de tipo String | - |
| `user` | `UserInterfaceTO` | ✅ | Parámetro de tipo UserInterfaceTO | - |

### Detalle de DTOs

#### ParametrosPlantillaDocumentoTO
*Archivo:* `/data/lucasian/Quickgas/contratacion.negocio/src/main/java/com/gasesdeoccidente/sicg/propuesta/negocio/transferencia/ParametrosPlantillaDocumentoTO.java`

| Campo | Tipo | Requerido | Validaciones | Descripción |
|-------|------|-----------|--------------|-------------|
| `proPlantillaDocumentoVO` | `ProPlantillaDocumentoVO` | ❌ | - | * |
| `listadoProPlantillaDocumentoVO` | `ArrayList` | ❌ | - | * |
| `numeroPagina` | `int` | ❌ | - |  |
| `registrosPagina` | `int` | ❌ | - |  |

### Atributos de Salida

| Nombre | Tipo | Descripción |
|--------|------|-------------|
| `result` | `public ArrayList` | Resultado de tipo public ArrayList |

### Mapeo de Errores

| Código | Mensaje | Causa | Solución |
|--------|---------|-------|----------|
| `ApplicationException` | Error de aplicación | Error en la lógica de negocio | Verificar parámetros de entrada |
| `EJBException` | Error del contenedor EJB | Error en la capa de servicios | Verificar configuración del servidor |

### Tips de Consumo

1. Verificar que todos los parámetros requeridos estén presentes
2. Manejar las excepciones ApplicationException apropiadamente
3. Considerar el uso de transacciones si el método modifica datos


---

## administrarProPlantillaDocumentoVO

### Firma del Método

```java
public LeafMessageTO administrarProPlantillaDocumentoVO(ProPlantillaDocumentoVO proPlantillaDocumentoVO, UserInterfaceTO user)
```

### Descripción Funcional

El método administrarProPlantillaDocumentoVO gestiona operaciones CRUD (Crear, Actualizar, Eliminar) sobre objetos ProPlantillaDocumentoVO, que representan plantillas de documentos en el sistema de propuestas. Se utiliza para administrar la información de estas plantillas, validando al usuario y los datos de entrada antes de realizar la operación solicitada. El flujo inicia validando el usuario; luego, según el valor del campo instanciaTransaccional del objeto ProPlantillaDocumentoVO, determina si se debe crear, actualizar o eliminar una plantilla. Para crear, valida la plantilla, asigna un nuevo ID y la inserta en la base de datos. Para actualizar, valida la plantilla y actualiza campos específicos en la base de datos. Para eliminar, primero elimina niveles asociados a la plantilla y luego borra la plantilla en la base de datos. En cada caso exitoso, retorna un objeto LeafMessageTO que contiene un mensaje informativo y la entidad afectada. En caso de error, captura la excepción y la controla mediante un método específico, retornando null si falla la operación. El propósito de negocio es mantener la integridad y consistencia de las plantillas de documentos asociadas a propuestas, facilitando su administración segura y validada.

### Reglas de Negocio

1. Solo se permite crear o actualizar una plantilla si pasa las validaciones definidas en ValidacionesPlantillaDocumento.
2. El campo instanciaTransaccional determina la operación a realizar: CREAR, ACTUALIZAR o ELIMINAR.
3. Al crear una plantilla, se asigna un nuevo ID único obtenido desde la base de datos.
4. Al actualizar, solo se modifican campos específicos definidos en el arreglo camposActualizables.
5. Al eliminar, primero se eliminan los niveles asociados a la plantilla antes de eliminar la plantilla en sí.
6. El usuario que realiza la operación debe ser validado para asegurar permisos y autenticidad.
7. Cada operación exitosa genera un mensaje localizado y contextualizado para informar el resultado.

### Atributos de Entrada

| Nombre | Tipo | Requerido | Descripción | Validaciones |
|--------|------|-----------|-------------|--------------|
| `proPlantillaDocumentoVO` | `ProPlantillaDocumentoVO` | ✅ | Objeto que representa la plantilla de documento a administrar. Contiene información detallada de la plantilla, incluyendo su estado, identificación, nombre, descripción, tipo de propuesta, fechas y estado de aprobación. Es el principal objeto sobre el cual se realiza la operación CRUD. | Validación de campos obligatorios para la plantilla, Validación específica de la plantilla mediante ValidacionesPlantillaDocumento.validarPlantillaDocumento, Validación del campo instanciaTransaccional para determinar operación (crear, actualizar, eliminar) |
| `user` | `UserInterfaceTO` | ✅ | Objeto que representa al usuario que realiza la operación. Se utiliza para validar permisos y para generar mensajes localizados y contextualizados en base al usuario. Contiene información de identidad y contexto del usuario. | Validación de existencia y permisos del usuario mediante validarUsuario(user) |
| `connection` | `Connection` | ✅ | Conexión a la base de datos utilizada para realizar las operaciones DAO necesarias para insertar, actualizar o eliminar registros relacionados con la plantilla de documento. | Debe ser una conexión válida y activa a la base de datos |

### Detalle de DTOs

#### LeafMessageTO
*Archivo:* `/data/lucasian/Quickgas/contratacion.negocio/src/main/java/com/gasesdeoccidente/sicg/propuesta/negocio/util/LeafMessageTO.java`

| Campo | Tipo | Requerido | Validaciones | Descripción |
|-------|------|-----------|--------------|-------------|
| `serialVersionUID` | `long` | ❌ | - | * |
| `message` | `LeafMessageVO` | ❌ | - |  |
| `entidad` | `Object` | ❌ | - |  |

### Atributos de Salida

| Nombre | Tipo | Descripción |
|--------|------|-------------|
| `message` | `LeafMessageVO` | Objeto que contiene el mensaje informativo resultante de la operación realizada, incluyendo código, texto localizado y parámetros. Indica éxito en la creación, actualización o eliminación de la plantilla. |
| `entidad` | `Object` | Objeto que contiene la entidad ProPlantillaDocumentoVO que fue creada, actualizada o eliminada, reflejando el estado final tras la operación. |

### Mapeo de Errores

| Código | Mensaje | Causa | Solución |
|--------|---------|-------|----------|
| `ApplicationException` | Error en la aplicación durante la operación con la plantilla de documento. | Puede ser causado por errores en validación, problemas de conexión a base de datos, o errores inesperados en lógica de negocio. | Verificar los datos de entrada, asegurar que la conexión a la base de datos esté activa, y revisar logs para detalles específicos del error. |
| `ValidacionException` | La plantilla de documento no cumple con las validaciones requeridas. | Datos incompletos o incorrectos en ProPlantillaDocumentoVO según reglas de ValidacionesPlantillaDocumento. | Corregir los datos de la plantilla para cumplir con las reglas de validación antes de llamar al método. |
| `UsuarioNoValidoException` | El usuario no está autorizado o no es válido para realizar la operación. | Fallo en la validación del usuario mediante validarUsuario(user). | Asegurar que el usuario esté autenticado y tenga permisos adecuados para la operación. |

### Tips de Consumo

1. Asegurar que el campo instanciaTransaccional en proPlantillaDocumentoVO esté correctamente definido como 'CREAR', 'ACTUALIZAR' o 'ELIMINAR' según la operación deseada.
2. Siempre validar previamente los datos de la plantilla para evitar errores en tiempo de ejecución.
3. Proveer un usuario válido con permisos adecuados para evitar fallos en la validación de usuario.
4. Manejar adecuadamente la conexión a la base de datos, asegurando que esté abierta y en buen estado durante la llamada.
5. Capturar y manejar posibles null retornados en caso de error para evitar fallos en la capa consumidora.


---

## administrarProPlantillaParamItem

### Firma del Método

```java
public ArrayList administrarProPlantillaParamItem(ParametrosParamTO parametrosParamTO, String modo, UserInterfaceTO user)
```

### Descripción Funcional

El método administrarProPlantillaParamItem se encarga de gestionar una lista de objetos ProPlantillaParamItemVO contenidos en el DTO ParametrosParamTO, aplicando operaciones de negocio específicas a cada uno según su estado transaccional. Se utiliza en contextos donde se requiere procesar múltiples elementos de configuración o parámetros asociados a plantillas de propuestas, permitiendo realizar acciones como creación, actualización o eliminación de dichos ítems. El flujo inicia validando la sesión del usuario para garantizar permisos, luego itera sobre la lista de ProPlantillaParamItemVO si esta existe y contiene elementos. Para cada elemento que tenga definida una instancia transaccional (indicando que requiere procesamiento), se invoca el método administrarProPlantillaParamItemVO que ejecuta la lógica de negocio específica para ese ítem, acumulando mensajes de resultado o error. Finalmente, retorna una lista con los mensajes generados durante el procesamiento. El propósito de negocio es centralizar y controlar la administración masiva de parámetros de plantillas, asegurando integridad y trazabilidad en las operaciones realizadas.

### Reglas de Negocio

1. Solo se procesan los ítems ProPlantillaParamItemVO que tienen instanciaTransaccional definida, ignorando los demás.
2. El usuario debe estar validado y autorizado para ejecutar la administración de parámetros de plantilla.
3. El método soporta procesamiento masivo de ítems, iterando y aplicando la lógica de negocio individualmente a cada uno.
4. Los mensajes de resultado se acumulan y retornan para informar sobre el estado de cada operación realizada.
5. No se realiza procesamiento si la lista de ítems está vacía o nula, retornando una lista vacía de mensajes.

### Atributos de Entrada

| Nombre | Tipo | Requerido | Descripción | Validaciones |
|--------|------|-----------|-------------|--------------|
| `parametrosParamTO` | `ParametrosParamTO` | ✅ | Objeto contenedor que agrupa los datos necesarios para administrar los ítems de parámetros de plantilla. Incluye un objeto ProPlantillaParamItemVO individual, una lista de estos objetos para procesamiento masivo, y parámetros para paginación. | Debe contener una lista no nula y no vacía para procesar múltiples ítems, Los objetos ProPlantillaParamItemVO dentro de la lista deben tener instanciaTransaccional definida para ser procesados |
| `parametrosParamTO.proPlantillaParamItemVO` | `ProPlantillaParamItemVO` | ❌ | Objeto que representa un único ítem de parámetro de plantilla con sus atributos específicos. Puede usarse para operaciones individuales o contener información base. | - |
| `parametrosParamTO.listadoProPlantillaParamItemVO` | `ArrayList<ProPlantillaParamItemVO>` | ❌ | Lista de objetos ProPlantillaParamItemVO que serán procesados en lote. Cada objeto debe tener definida su instanciaTransaccional para indicar la operación a realizar. | No debe ser nula ni vacía para que se ejecute el procesamiento, Cada elemento debe tener instanciaTransaccional no nula |
| `parametrosParamTO.numeroPagina` | `int` | ❌ | Número de página para paginación en consultas o listados relacionados, aunque no es utilizado directamente en este método. | Debe ser mayor o igual a 1 si se utiliza en paginación |
| `parametrosParamTO.numRegistrosPagina` | `int` | ❌ | Número de registros por página para paginación en consultas o listados relacionados, no utilizado directamente en este método. | Debe ser mayor a 0 si se utiliza en paginación |
| `modo` | `String` | ✅ | Cadena que indica el modo o tipo de operación a realizar. Aunque no se usa directamente en el método, puede influir en la lógica interna de métodos llamados. | No debe ser nulo ni vacío |
| `user` | `UserInterfaceTO` | ✅ | Objeto que representa al usuario que realiza la operación, utilizado para validar permisos y contexto de seguridad. | Debe ser un usuario válido y autenticado |

### Detalle de DTOs

#### ParametrosParamTO
*Archivo:* `/data/lucasian/Quickgas/contratacion.negocio/src/main/java/com/gasesdeoccidente/sicg/propuesta/negocio/transferencia/ParametrosParamTO.java`

| Campo | Tipo | Requerido | Validaciones | Descripción |
|-------|------|-----------|--------------|-------------|
| `proPlantillaParamItemVO` | `ProPlantillaParamItemVO` | ❌ | - | * |
| `listadoProPlantillaParamItemVO` | `ArrayList` | ❌ | - | * |
| `numeroPagina` | `int` | ❌ | - |  |
| `numRegistrosPagina` | `int` | ❌ | - |  |

### Atributos de Salida

| Nombre | Tipo | Descripción |
|--------|------|-------------|
| `messages` | `ArrayList<String>` | Lista de mensajes generados durante el procesamiento de cada ProPlantillaParamItemVO. Contiene información de éxito, advertencias o errores específicos de cada ítem. |

### Mapeo de Errores

| Código | Mensaje | Causa | Solución |
|--------|---------|-------|----------|
| `ApplicationException` | Error en la aplicación durante la administración de ProPlantillaParamItem | Puede ocurrir por problemas en la validación del usuario, errores en la base de datos o inconsistencias en los datos de entrada | Verificar que el usuario esté autenticado y autorizado, validar los datos de entrada y revisar la conexión a la base de datos |
| `SecurityException` | Usuario no válido o sin permisos para realizar la operación | El objeto user no cumple con los requisitos de validación o no tiene los roles necesarios | Asegurar que el usuario esté autenticado y tenga los permisos adecuados antes de invocar el método |

### Tips de Consumo

1. Asegúrese de que la lista listadoProPlantillaParamItemVO no sea nula ni vacía para que el método procese los ítems correctamente.
2. Cada ProPlantillaParamItemVO debe tener definida la propiedad instanciaTransaccional para indicar la operación a realizar (e.g., INSERT, UPDATE, DELETE).
3. Valide previamente el objeto user para evitar errores de autorización y garantizar que el usuario tiene permisos para administrar los parámetros.
4. El parámetro modo no es utilizado directamente en este método, pero podría afectar la lógica en métodos internos; documente y utilice según el contexto de negocio.
5. Revise los mensajes retornados para identificar operaciones exitosas o errores específicos en cada ítem procesado.


---

## administrarProPlantillaParamItemVO

### Firma del Método

```java
public LeafMessageTO administrarProPlantillaParamItemVO(ProPlantillaParamItemVO proPlantillaParamItemVO, UserInterfaceTO user)
```

### Descripción Funcional

El método administrarProPlantillaParamItemVO gestiona operaciones CRUD (Crear, Actualizar, Eliminar) sobre objetos ProPlantillaParamItemVO que representan parámetros de plantilla en el sistema. Se utiliza para administrar los parámetros asociados a una plantilla de propuesta, permitiendo crear un nuevo parámetro, actualizar campos específicos de uno existente o eliminarlo. El flujo inicia validando el usuario proporcionado. Luego, según el valor de la propiedad instanciaTransaccional de proPlantillaParamItemVO, se determina la operación a realizar: si es 'CREAR', valida el objeto, asigna un nuevo ID, inserta el registro en la base de datos y retorna un mensaje de éxito; si es 'ACTUALIZAR', valida el objeto, actualiza campos específicos (número y tipo de parámetro) y retorna un mensaje de éxito; si es 'ELIMINAR', elimina el registro identificado por el ID y retorna un mensaje de éxito. En caso de excepciones, se controla el error y retorna null. El propósito de negocio es facilitar la gestión de parámetros de plantilla para propuestas, asegurando integridad y control de acceso mediante validación de usuario y validaciones de datos.

### Reglas de Negocio

1. Solo se permite crear un parámetro si el objeto pasa la validación de parámetros y la instanciaTransaccional es CREAR.
2. Para actualizar un parámetro, solo se modifican los campos número de parámetro y tipo de parámetro, y debe pasar la validación de parámetros.
3. La eliminación se realiza únicamente si la instanciaTransaccional es ELIMINAR y se identifica el parámetro por su ID.
4. Se debe validar la existencia y autenticidad del usuario antes de ejecutar cualquier operación.
5. Cada operación retorna un mensaje localizado que indica el resultado exitoso de la acción realizada.
6. En caso de error o excepción, se captura y controla, retornando null para indicar fallo.

### Atributos de Entrada

| Nombre | Tipo | Requerido | Descripción | Validaciones |
|--------|------|-----------|-------------|--------------|
| `proPlantillaParamItemVO` | `ProPlantillaParamItemVO` | ✅ | Objeto que representa un parámetro de plantilla de propuesta con información para crear, actualizar o eliminar. Contiene datos clave para la operación y el estado transaccional. | ValidacionesParam.validarParam(proPlantillaParamItemVO) para creación y actualización, Debe contener instanciaTransaccional con valores CRUD_CREAR, CRUD_ACTUALIZAR o CRUD_ELIMINAR |
| `user` | `UserInterfaceTO` | ✅ | Objeto que representa al usuario que realiza la operación, usado para validar permisos y para la generación de mensajes localizados. | Debe ser un usuario válido y autenticado, Se valida mediante validarUsuario(user) |

### Detalle de DTOs

#### LeafMessageTO
*Archivo:* `/data/lucasian/Quickgas/contratacion.negocio/src/main/java/com/gasesdeoccidente/sicg/propuesta/negocio/util/LeafMessageTO.java`

| Campo | Tipo | Requerido | Validaciones | Descripción |
|-------|------|-----------|--------------|-------------|
| `serialVersionUID` | `long` | ❌ | - | * |
| `message` | `LeafMessageVO` | ❌ | - |  |
| `entidad` | `Object` | ❌ | - |  |

### Atributos de Salida

| Nombre | Tipo | Descripción |
|--------|------|-------------|
| `message` | `LeafMessageVO` | Mensaje que indica el resultado de la operación realizada (creación, actualización o eliminación) con información localizada y contextualizada para el usuario. |
| `entidad` | `Object` | Objeto ProPlantillaParamItemVO que fue procesado en la operación, reflejando el estado final tras la operación realizada. |

### Mapeo de Errores

| Código | Mensaje | Causa | Solución |
|--------|---------|-------|----------|
| `ApplicationException` | Error en la aplicación durante la operación de administración del parámetro de plantilla | Puede ser causado por errores en la validación del usuario, validación de parámetros, errores de conexión o fallos en acceso a datos | Verificar que el usuario esté correctamente autenticado, que los parámetros sean válidos, y que la conexión a base de datos esté activa y correcta |
| `ValidacionException` | Parámetros inválidos para la operación solicitada | Los datos de proPlantillaParamItemVO no cumplen las reglas de validación definidas en ValidacionesParam.validarParam | Corregir los datos de entrada para que cumplan las validaciones requeridas antes de invocar el método |

### Tips de Consumo

1. Asegúrese de establecer correctamente el campo instanciaTransaccional en proPlantillaParamItemVO con uno de los valores: CREAR, ACTUALIZAR o ELIMINAR para que la operación se ejecute correctamente.
2. Valide previamente los datos de proPlantillaParamItemVO para evitar errores en la capa de negocio, especialmente para creación y actualización.
3. Proporcione un objeto user válido y autenticado para que la validación de usuario y generación de mensajes funcione correctamente.
4. Para actualización, solo se modificarán los campos número de parámetro y tipo de parámetro; otros campos serán ignorados.
5. En caso de eliminación, solo es necesario que proPlantillaParamItemVO contenga el ID del parámetro a eliminar.
6. Maneje posibles retornos null que indican que ocurrió una excepción no controlada durante la operación.


---

## administrarProPlantillaTabla

### Firma del Método

```java
public ArrayList administrarProPlantillaTabla(ParametrosTablaTO parametrosTablaTO, String modo, UserInterfaceTO user)
```

### Descripción Funcional

El método administrarProPlantillaTabla es responsable de gestionar operaciones sobre una lista de objetos ProPlantillaTablaVO contenida en el DTO ParametrosTablaTO. Se utiliza para administrar (crear, actualizar o eliminar) registros relacionados con plantillas de tablas en el contexto de propuestas. El método inicia validando la existencia y autenticidad del usuario mediante validarUsuario(user). Luego, verifica si el listado listadoProPlantillaTablaVO dentro de parametrosTablaTO no es nulo ni vacío. Por cada objeto ProPlantillaTablaVO en la lista, si este tiene una instancia transaccional definida (indicando que requiere alguna operación de negocio), se invoca el método administrarProPlantillaTablaVO para procesar dicha instancia, acumulando los mensajes o resultados en una lista que finalmente se retorna. El propósito de negocio es centralizar la administración masiva de plantillas de tabla, permitiendo procesar múltiples registros en una sola llamada, asegurando que solo se actúe sobre aquellos con operaciones transaccionales definidas y bajo un contexto de usuario válido.

### Reglas de Negocio

1. Solo se procesan los objetos ProPlantillaTablaVO que tengan definida una instanciaTransaccional, ignorando el resto.
2. El usuario debe ser validado antes de cualquier operación para garantizar seguridad y permisos.
3. El método permite procesar múltiples plantillas de tabla en lote para optimizar operaciones.
4. La paginación está soportada mediante los campos numeroPagina y numRegistrosPagina, aunque no se utiliza directamente en este método.
5. Los mensajes devueltos deben ser interpretados para conocer el resultado de cada operación individual.

### Atributos de Entrada

| Nombre | Tipo | Requerido | Descripción | Validaciones |
|--------|------|-----------|-------------|--------------|
| `parametrosTablaTO` | `ParametrosTablaTO` | ✅ | Objeto contenedor que agrupa los parámetros necesarios para la gestión de plantillas de tabla. Incluye datos individuales y listados de plantillas, así como información para paginación. | No debe ser nulo, listadoProPlantillaTablaVO puede ser nulo o vacío, numeroPagina y numRegistrosPagina deben ser enteros válidos si se usan para paginación |
| `parametrosTablaTO.proPlantillaTablaVO` | `ProPlantillaTablaVO` | ❌ | Objeto que representa una plantilla de tabla individual con sus atributos y estado para la operación. | Puede ser nulo si se usa listadoProPlantillaTablaVO, Debe contener información válida para la plantilla si se usa |
| `parametrosTablaTO.listadoProPlantillaTablaVO` | `ArrayList<ProPlantillaTablaVO>` | ❌ | Lista de objetos ProPlantillaTablaVO que serán procesados en lote. Cada objeto puede representar una operación distinta según su instanciaTransaccional. | Puede ser nulo o vacío, en cuyo caso no se procesan registros, Cada elemento debe tener instanciaTransaccional definida para ser procesado |
| `parametrosTablaTO.numeroPagina` | `int` | ❌ | Número de página para paginación en consultas o listados relacionados con plantillas de tabla. | Debe ser mayor o igual a 0 si se utiliza |
| `parametrosTablaTO.numRegistrosPagina` | `int` | ❌ | Cantidad de registros por página para paginación. | Debe ser mayor que 0 si se utiliza |
| `modo` | `String` | ✅ | Cadena que indica el modo o tipo de operación a realizar. Aunque no se usa directamente en el método, puede influir en la lógica de negocio en métodos internos. | No debe ser nulo ni vacío |
| `user` | `UserInterfaceTO` | ✅ | Objeto que representa al usuario que realiza la operación, utilizado para validar permisos y contexto de seguridad. | No debe ser nulo, Debe representar un usuario válido y autenticado |

### Detalle de DTOs

#### ParametrosTablaTO
*Archivo:* `/data/lucasian/Quickgas/contratacion.negocio/src/main/java/com/gasesdeoccidente/sicg/propuesta/negocio/transferencia/ParametrosTablaTO.java`

| Campo | Tipo | Requerido | Validaciones | Descripción |
|-------|------|-----------|--------------|-------------|
| `proPlantillaTablaVO` | `ProPlantillaTablaVO` | ❌ | - | * |
| `listadoProPlantillaTablaVO` | `ArrayList` | ❌ | - | * |
| `numeroPagina` | `int` | ❌ | - |  |
| `numRegistrosPagina` | `int` | ❌ | - |  |

### Atributos de Salida

| Nombre | Tipo | Descripción |
|--------|------|-------------|
| `messages` | `ArrayList` | Lista de mensajes o resultados devueltos por el procesamiento de cada objeto ProPlantillaTablaVO. Cada elemento puede contener información sobre éxito, error o estado de la operación realizada. |

### Mapeo de Errores

| Código | Mensaje | Causa | Solución |
|--------|---------|-------|----------|
| `ApplicationException` | Error en la aplicación durante la administración de plantillas de tabla. | Puede ocurrir por problemas en la validación del usuario, errores en la conexión a la base de datos, o fallos en la lógica de negocio al procesar cada ProPlantillaTablaVO. | Verificar que el usuario esté correctamente autenticado y autorizado, revisar la conexión y los datos enviados, y validar que cada ProPlantillaTablaVO tenga una instanciaTransaccional válida. |
| `ValidacionUsuarioException` | Usuario no válido o no autenticado. | El método validarUsuario(user) detectó que el objeto user es nulo o no cumple con los criterios de autenticación. | Asegurar que el objeto user esté correctamente inicializado y que el usuario tenga permisos para ejecutar esta operación. |

### Tips de Consumo

1. Asegurarse de que el objeto user esté correctamente autenticado y autorizado antes de invocar el método.
2. Cuando se envíe listadoProPlantillaTablaVO, cada elemento debe tener la propiedad instanciaTransaccional definida para que sea procesado.
3. El parámetro modo puede influir en la lógica interna; aunque no se usa directamente en este método, debe ser consistente con la operación deseada.
4. Si no se requiere procesar múltiples registros, se puede usar el campo proPlantillaTablaVO individual dentro de parametrosTablaTO.
5. Manejar adecuadamente la lista de mensajes devuelta para identificar operaciones exitosas y errores específicos por registro.


---

## administrarProPlantillaTablaVO

### Firma del Método

```java
public LeafMessageTO administrarProPlantillaTablaVO(ProPlantillaTablaVO proPlantillaTablaVO, UserInterfaceTO user)
```

### Descripción Funcional

El método administrarProPlantillaTablaVO gestiona operaciones CRUD (Crear, Actualizar, Eliminar) sobre la entidad ProPlantillaTablaVO, que representa una plantilla de tabla en el sistema. Se utiliza para administrar registros de plantillas de tabla en el contexto de propuestas, validando al usuario que realiza la operación y la validez de los datos de entrada. El flujo de operaciones es el siguiente: primero valida que el usuario esté autorizado; luego, según el valor del campo instanciaTransaccional de proPlantillaTablaVO, determina la operación a realizar. Para creación, valida la tabla, asigna un nuevo ID, inserta el registro y retorna un mensaje de éxito con la entidad creada. Para actualización, valida la tabla, actualiza campos específicos (VALOR_3, VALOR_2, VALOR_1, ORDEN) y retorna un mensaje de éxito con la entidad actualizada. Para eliminación, construye una condición WHERE con el ID, elimina el registro y retorna un mensaje de éxito. En caso de excepciones, se controla la excepción y retorna null. El propósito de negocio es mantener la integridad y gestión eficiente de las plantillas de tabla asociadas a propuestas, garantizando que solo usuarios válidos puedan modificar los datos y que las operaciones se realicen con datos validados.

### Reglas de Negocio

1. Solo usuarios validados pueden ejecutar operaciones sobre plantillas de tabla.
2. Para crear o actualizar una plantilla de tabla, los datos deben pasar la validación definida en ValidacionesTabla.
3. Al crear una plantilla, se asigna un nuevo ID único obtenido desde la base de datos.
4. En la actualización, únicamente se actualizan los campos VALOR_3, VALOR_2, VALOR_1 y ORDEN de la plantilla.
5. La eliminación se realiza mediante el ID de la plantilla y elimina el registro correspondiente en la base de datos.
6. Se generan mensajes específicos para cada operación exitosa, que incluyen el ID de la plantilla afectada y están personalizados para el usuario.
7. Si ocurre cualquier excepción durante la operación, se controla y no se propaga, retornando null.

### Atributos de Entrada

| Nombre | Tipo | Requerido | Descripción | Validaciones |
|--------|------|-----------|-------------|--------------|
| `proPlantillaTablaVO` | `ProPlantillaTablaVO` | ✅ | Objeto que representa la plantilla de tabla a administrar. Contiene la información necesaria para crear, actualizar o eliminar una plantilla de tabla. | El campo instanciaTransaccional debe ser uno de los valores CRUD: 'CREAR', 'ACTUALIZAR' o 'ELIMINAR'., La tabla debe pasar la validación de ValidacionesTabla.validarTabla para operaciones de creación y actualización. |
| `user` | `UserInterfaceTO` | ✅ | Objeto que representa al usuario que realiza la operación. Se utiliza para validar permisos y para personalizar mensajes de respuesta. | Debe ser un usuario válido y autenticado para que la operación proceda. |

### Detalle de DTOs

#### LeafMessageTO
*Archivo:* `/data/lucasian/Quickgas/contratacion.negocio/src/main/java/com/gasesdeoccidente/sicg/propuesta/negocio/util/LeafMessageTO.java`

| Campo | Tipo | Requerido | Validaciones | Descripción |
|-------|------|-----------|--------------|-------------|
| `serialVersionUID` | `long` | ❌ | - | * |
| `message` | `LeafMessageVO` | ❌ | - |  |
| `entidad` | `Object` | ❌ | - |  |

### Atributos de Salida

| Nombre | Tipo | Descripción |
|--------|------|-------------|
| `message` | `LeafMessageVO` | Mensaje que contiene información sobre el resultado de la operación (creación, actualización o eliminación), incluyendo códigos y textos localizados para el usuario. |
| `entidad` | `Object (ProPlantillaTablaVO)` | La entidad ProPlantillaTablaVO que fue creada, actualizada o eliminada, reflejando el estado final tras la operación. |

### Mapeo de Errores

| Código | Mensaje | Causa | Solución |
|--------|---------|-------|----------|
| `ApplicationException` | Error al validar usuario o durante la operación CRUD sobre ProPlantillaTablaVO. | Usuario no válido, datos inválidos en proPlantillaTablaVO, error en conexión o en acceso a la base de datos. | Verificar que el usuario esté autenticado y autorizado, validar que los datos de entrada cumplan con las reglas de negocio y que la conexión a base de datos esté activa. |
| `ValidacionTablaException` | La validación de la tabla proPlantillaTablaVO falló. | Datos incompletos o incorrectos en los campos de la tabla que no cumplen con las reglas definidas en ValidacionesTabla. | Corregir los datos de la plantilla de tabla para que cumplan con las validaciones antes de intentar crear o actualizar. |

### Tips de Consumo

1. Antes de llamar al método, asegúrese de que el campo instanciaTransaccional en proPlantillaTablaVO esté correctamente definido como 'CREAR', 'ACTUALIZAR' o 'ELIMINAR'.
2. Valide que el usuario proporcionado esté autenticado y tenga los permisos necesarios para realizar operaciones sobre plantillas de tabla.
3. Para operaciones de creación y actualización, asegúrese de que proPlantillaTablaVO pase las validaciones de ValidacionesTabla para evitar errores.
4. En operaciones de actualización, solo se modificarán los campos VALOR_3, VALOR_2, VALOR_1 y ORDEN; otros campos no serán afectados.
5. En la operación de eliminación, solo se requiere que el campo plantillaTablaId esté definido para identificar el registro a eliminar.
6. Maneje posibles excepciones ApplicationException para capturar errores de negocio o de validación.
7. Considere que el método retorna null en caso de error no controlado; implemente lógica para manejar este caso.


---
